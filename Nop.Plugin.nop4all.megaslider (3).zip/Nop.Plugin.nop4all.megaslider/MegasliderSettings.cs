﻿using Nop.Core.Configuration;

namespace Nop.Plugin.nop4all.megaslider
{
    /// <summary>
    /// Represents Mega Slider plugin settings
    /// </summary>
    public class MegasliderSettings : ISettings
    {
        /// <summary>
        /// Gets or sets the widget zone where the slider will be displayed.
        /// </summary>
        public string WidgetZone { get; set; }

        /// <summary>
        /// Gets or sets the color theme for the slider.
        /// </summary>
        public string Color { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the slider should be displayed on the left side.
        /// </summary>
        public bool LeftSide { get; set; }

        /// <summary>
        /// Get or sets Autoplay
        /// </summary>
        public int Autoplay { get; set; } 
        /// <summary>
        /// Gets or sets a value indicating whether the slider is enabled.
        /// </summary>
        public bool Enable { get; set; } 

        /// <summary>
        /// Gets or sets a MainSliderDots
        /// </summary>
        public bool MainSliderDots { get; set; }

        /// <summary>
        /// Gets or sets a MainSliderArrows
        /// </summary>
        public bool MainSliderArrows { get; set; }

        /// <summary>
        /// Gets or sets a SliderHeight
        /// </summary>
        public int SliderHeight { get; set; }

        /// <summary>
        /// Gets or sets a SliderHeight
        /// </summary>
        public int AnimationRepeat { get; set; }

        /// <summary>
        /// Gets or sets a Newproductdropdown position
        /// </summary>
        public string Newproductdropdown { get; set; }
    }
}