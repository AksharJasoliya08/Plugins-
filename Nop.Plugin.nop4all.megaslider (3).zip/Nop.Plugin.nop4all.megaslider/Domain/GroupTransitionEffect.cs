﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    public enum GroupTransitionEffect
    {
        Slide = 0,          // Default slide transition
        Fade = 1,           // Fade animation
        Flip = 2,           // 3D Flip animation
        Coverflow = 3,      // Coverflow effect
        Cube = 4,           // Cube rotation effect
    }
}
