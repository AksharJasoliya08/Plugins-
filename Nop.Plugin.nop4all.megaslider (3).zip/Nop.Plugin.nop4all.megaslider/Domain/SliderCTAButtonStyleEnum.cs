﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represent Slider CTAButton Style Enum
    /// </summary>
    public enum SliderCTAButtonStyleEnum
    {
        /// <summary>
        /// Text Link
        /// </summary>
        TextLink = 0,

        /// <summary>
        /// Square Button
        /// </summary>
        SquareButton = 1,

        /// <summary>
        /// Rounded Button
        /// </summary>
        RoundedButton = 2
    }
}
