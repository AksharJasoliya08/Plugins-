﻿using System.ComponentModel.DataAnnotations;

namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represent Text Block Position enum
    /// </summary>
    public enum TextBlockPositionenum
    {
        /// <summary>
        /// Top Left
        /// </summary>
        [Display(Name = "Top Left")]
        TopLeft = 1,

        /// <summary>
        /// Top Center 
        /// </summary>
        [Display(Name = "Top Center")]
        TopCenter = 2,

        /// <summary>
        /// Top Right
        /// </summary>
        [Display(Name = "Top Right")]
        TopRight = 3,

        /// <summary>
        /// Middle Left
        /// </summary>
        [Display(Name = "Middle Left")]
        MiddleLeft = 4,

        /// <summary>
        /// Middle Center
        /// </summary>
        [Display(Name = "Middle Center")]
        MiddleCenter = 5,

        /// <summary>
        /// Middle Right
        /// </summary>
        [Display(Name = "Middle Right")]
        MiddleRight = 6,

        /// <summary>
        /// Bottom Left
        /// </summary>
        [Display(Name = "Bottem Left")]
        BottomLeft = 7,

        /// <summary>
        /// Bottom Center
        /// </summary>
        [Display(Name = "Bottem Center")]
        BottomCenter = 8,

        /// <summary>
        /// Bottom Right
        /// </summary>
        [Display(Name = "Bottem Right")]
        BottomRight = 9
    }
}
