﻿namespace Nop.Plugin.nop4all.megaslider.Domain;

    /// <summary>
    /// Represents category condition property enumeration
    /// </summary>
    public enum CategoryConditionProperty
    {
        /// <summary>
        /// Default
        /// </summary>
        Default,

        /// <summary>
        /// Name
        /// </summary>
        Name,
    }