﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represents condition property value type enumeration
    /// </summary>
    public enum ConditionPropertyValueType
    {
        /// <summary>
        /// Default
        /// </summary>
        Default,

        /// <summary>
        /// ComboBox
        /// </summary>
        ComboBox,

        /// <summary>
        /// Dropdown
        /// </summary>
        Dropdown,

        /// <summary>
        /// NumericTextbox
        /// </summary>
        NumericTextbox,

        /// <summary>
        /// Textbox
        /// </summary>
        Textbox,
    }
}