﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represents the type of background type 
    /// </summary>
    public enum BackgroundTypeEnum
    {
        /// <summary>
        /// None 
        /// </summary>
        None = 0,

        /// <summary>
        /// Color
        /// </summary>
        Color = 1,

        /// <summary>
        /// Image 
        /// </summary>
        Image = 2,

        /// <summary>
        /// Image 
        /// </summary>
        Video = 3,
    }
}
