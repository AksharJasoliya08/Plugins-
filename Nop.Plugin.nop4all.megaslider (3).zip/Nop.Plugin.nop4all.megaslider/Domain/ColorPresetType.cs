﻿using System.ComponentModel.DataAnnotations;

namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represents predefined color preset options used for styling elements in the slider.
    /// </summary>
    public enum ColorPresetType
    {
        /// <summary>
        /// Brand
        /// </summary>
        [Display(Name = "Brand")]
        Brand = 1,

        /// <summary>
        /// Dark
        /// </summary>
        [Display(Name = "Dark")]
        Dark = 2,

        /// <summary>
        /// Light
        /// </summary>
        [Display(Name = "Light")]
        Light = 3,

        /// <summary>
        /// White
        /// </summary>
        [Display(Name = "White")]
        White = 4,

        /// <summary>
        /// Black
        /// </summary>
        [Display(Name = "Black")]
        Black = 5,

        /// <summary>
        /// Custom
        /// </summary>
        [Display(Name = "Custom")]
        Custom = 6,

        
    }
}
