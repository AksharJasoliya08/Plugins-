﻿using Nop.Core;

namespace Nop.Plugin.nop4all.megaslider.Domain;

/// <summary>
/// Represents slider mapping
/// </summary>
public class SliderMapping : BaseEntity
{
    /// <summary>
    /// Gets or sets the slider identifier.
    /// </summary>
    public int  SliderId { get; set; }
    /// <summary>
    /// Gets or sets the Groupslider identifier.
    /// </summary>
    public int  GroupSliderId { get; set; }
}