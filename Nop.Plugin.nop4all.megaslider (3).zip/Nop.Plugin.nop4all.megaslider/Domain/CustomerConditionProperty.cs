﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represents customer condition property enumeration
    /// </summary>
    public enum CustomerConditionProperty
    {
        /// <summary>
        /// Default
        /// </summary>
        Default,

        /// <summary>
        /// UserName
        /// </summary>
        UserName,

        /// <summary>
        /// Email
        /// </summary>
        Email,

        /// <summary>
        /// IsLoggedIn
        /// </summary>
        IsLoggedIn,

        /// <summary>
        /// IsInRole
        /// </summary>
        IsInRole,

        /// <summary>
        /// IsNotInRole
        /// </summary>
        IsNotInRole,
    }
}