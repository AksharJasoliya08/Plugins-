﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represents operator type enumeration
    /// </summary>
    public enum OperatorType
    {
        /// <summary>
        /// EqualTo
        /// </summary>
        EqualTo,

        /// <summary>
        /// NotEqualTo
        /// </summary>
        NotEqualTo,

        /// <summary>
        /// Contains
        /// </summary>
        Contains,

        /// <summary>
        /// DoesNotContain
        /// </summary>
        DoesNotContain,

        /// <summary>
        /// LessThan
        /// </summary>
        LessThan,

        /// <summary>
        /// GreaterThan
        /// </summary>
        GreaterThan,

        /// <summary>
        /// LessThanOrEqualTo
        /// </summary>
        LessThanOrEqualTo,

        /// <summary>
        /// GreaterThanOrEqualTo
        /// </summary>
        GreaterThanOrEqualTo,
    }
}