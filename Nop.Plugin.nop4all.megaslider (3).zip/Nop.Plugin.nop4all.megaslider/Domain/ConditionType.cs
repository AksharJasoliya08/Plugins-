﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represents condition type enumeration
    /// </summary>
    public enum ConditionType
    {
        /// <summary>
        /// Default
        /// </summary>
        Default,

        /// <summary>
        /// Manufacturer
        /// </summary>
        Manufacturer,

        /// <summary>
        /// Category
        /// </summary>
        Category,

        /// <summary>
        /// Product
        /// </summary>
        Product,

        /// <summary>
        /// Topic
        /// </summary>
        Topic,

        /// <summary>
        /// Blog
        /// </summary>
        Blog,

        /// <summary>
        /// CaseStudy
        /// </summary>
        Casestudy
    }
}