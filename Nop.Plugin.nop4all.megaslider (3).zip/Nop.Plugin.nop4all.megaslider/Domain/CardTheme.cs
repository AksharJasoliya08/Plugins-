﻿using System.ComponentModel.DataAnnotations;

namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represents predefined theme styles for card layout in the slider.
    /// </summary>
    public enum CardTheme
    {
        /// <summary>
        /// White
        /// </summary>
        [Display(Name = "White")]
        White = 0,

        /// <summary>
        /// Dark
        /// </summary>
        [Display(Name = "Dark")]
        Dark = 2,

        /// <summary>
        /// Brand
        /// </summary>
        [Display(Name = "Brand")]
        Brand = 3,

        /// <summary>
        /// Custom
        /// </summary>
        [Display(Name = "Custom")]
        Custom = 4
    }
}