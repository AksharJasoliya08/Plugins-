﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represents condition property enumeration
    /// </summary>
    public enum ConditionProperty
    {
        /// <summary>
        /// Default
        /// </summary>
        Default,

        /// <summary>
        /// Name
        /// </summary>
        Name,
    }
}