﻿using System.ComponentModel.DataAnnotations;

namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represent Content Layer Positions
    /// </summary>
    public enum ContentLayerPositions
    {
        /// <summary>
        /// Select
        /// </summary>
        [Display(Name = "--Select--")]
        Select = 0,

        /// <summary>
        /// Left
        /// </summary>
        [Display(Name = "Left")]
        Left = 1,

        /// <summary>
        /// Center
        /// </summary>
        [Display(Name = "Center")]
        Center = 2,

        /// <summary>
        /// Right
        /// </summary>
        [Display(Name = "Right")]
        Right = 3,

        /// <summary>
        /// Full
        /// </summary>
        [Display(Name = "Full")]
        Full = 4,
    }
}