﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represent Zone Type
    /// </summary>
    public enum ZoneTypeEnum
    {
        /// <summary>
        /// Image
        /// </summary>
        Image = 1,

        /// <summary>
        /// Color
        /// </summary>
        Color = 2,

        /// <summary>
        /// Empty
        /// </summary>
        Empty = 3,
    }
}