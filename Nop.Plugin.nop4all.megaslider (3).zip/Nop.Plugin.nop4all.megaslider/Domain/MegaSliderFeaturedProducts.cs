﻿using Nop.Core;

namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represents a mapping between a Mega Slider and featured products.
    /// </summary>
    public class MegaSliderFeaturedProducts : BaseEntity
    {
        /// <summary>
        /// Gets or sets the slider identifier.
        /// </summary>
        public int SliderId { get; set; }

        /// <summary>
        /// Gets or sets the product identifier.
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        /// Gets or sets the display order of the product within the slider.
        /// </summary>
        public int DisplayOrder { get; set; }

        /// <summary>
        /// Gets or sets the Picture id.
        /// </summary>
        public int PictureId { get; set; }
    }
}