﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represent ContentType
    /// </summary>
    public enum ContentTypeEnum
    {
        /// <summary>
        /// Product
        /// </summary>
        Product = 1,

        /// <summary>
        /// Text
        /// </summary>
        Text = 2,

        /// <summary>
        /// Html
        /// </summary>
        Html = 3
    }
}