﻿using Nop.Core;
using Nop.Core.Domain.Localization;
using Nop.Core.Domain.Seo;
using Nop.Core.Domain.Stores;
using Nop.Web.Framework.Models.ArtificialIntelligence;

namespace Nop.Plugin.nop4all.megaslider.Domain
{
    public partial class CaseStudy : BaseEntity, ILocalizedEntity, IStoreMappingSupported, ISlugSupported, IMetaTagsSupportedModel
    {
        /// <summary>
        /// Gets or sets the title
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets the short description
        /// </summary>
        public string ShortDescription { get; set; }

        /// <summary>
        ///  Gets or sets the Content
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        /// Gets or sets the logo identifier
        /// </summary>
        public int LogoId { get; set; }

        /// <summary>
        /// Gets or sets the thumb identifier
        /// </summary>
        public int ThumbId { get; set; }

        /// <summary>
        /// Gets or sets the display order
        /// </summary>
        public int DisplayOrder { get; set; }

        /// <summary>
        /// Gets or sets the visible
        /// </summary>
        public bool Visible { get; set; }

        /// <summary>
        /// Gets or sets the visible
        /// </summary>
        public bool IsFeatured { get; set; }

        /// <summary>
        /// Gets or sets the visible
        /// </summary>
        public bool VisibleHomePage { get; set; }

        /// <summary>
        /// Gets or sets the template bGColor
        /// </summary>
        public string TemplateBGColor { get; set; }

        /// <summary>
        /// Gets or sets the limited to stores
        /// </summary>
        public bool LimitedToStores { get; set; }

        /// <summary>
        /// Gets or sets the news widget zone
        /// </summary>
        public string NewsWidgetZone { get; set; }

        /// <summary>
        /// Gets or sets the blog widget zone
        /// </summary>
        public string BlogWidgetZone { get; set; }

        /// <summary>
        /// Gets or sets the product widget zone
        /// </summary>
        public string ProductWidgetZone { get; set; }

        /// <summary>
        /// Gets or sets the home page widget zone
        /// </summary>
        public string HomePageWidgetZone { get; set; }

        /// <summary>
        /// Gets or sets the category widget zone
        /// </summary>
        public string CategoryWidgetZone { get; set; }

        /// <summary>
        /// Gets or sets the caseStudys widget zone
        /// </summary>
        public string CaseStudysWidgetZone { get; set; }

        /// <summary>
        /// Gets or sets the megamenu topic widget zone
        /// </summary>
        public string MegamenuTopicWidgetZones { get; set; }

        /// <summary>
        /// Gets or sets the megamenu news widget zone
        /// </summary>
        public string MegamenuNewsWidgetZones { get; set; }

        /// <summary>
        /// Gets or sets the megamenu blog widget zone
        /// </summary>
        public string MegamenuBlogWidgetZones { get; set; }

        /// <summary>
        /// Gets or sets the include in megamenu topic pages
        /// </summary>
        public bool IncludeInMegamenuTopicPages { get; set; }

        /// <summary>
        /// Gets or sets the include in megamenu news pages
        /// </summary>
        public bool IncludeInMegamenuNewsPages { get; set; }

        /// <summary>
        /// Gets or sets the include in megamenu blog pages
        /// </summary>
        public bool IncludeInMegamenuBlogPages { get; set; }

        /// <summary>
        /// Gets or sets the sename
        /// </summary>
        public string SeName { get; set; }

        /// <summary>
        /// Gets or sets the metakeywords
        /// </summary>
        public string MetaKeywords { get; set; }

        /// <summary>
        /// Gets or sets the metadescription
        /// </summary>
        public string MetaDescription { get; set; }

        /// <summary>
        /// Gets or sets the metatitle
        /// </summary>
        public string MetaTitle { get; set; }
    }
}
