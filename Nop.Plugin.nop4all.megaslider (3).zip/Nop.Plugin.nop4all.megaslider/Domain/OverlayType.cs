﻿using System.ComponentModel.DataAnnotations;

namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Defines overlay type enum
    /// </summary>
    public enum OverlayType
    {
        /// <summary>
        /// None
        /// </summary>
        [Display(Name = "None")]
        None = 0,

        /// <summary>
        /// Light
        /// </summary>
        [Display(Name = "Light (~20%)")]
        Light = 20,

        /// <summary>
        /// Medium
        /// </summary>
        [Display(Name = "Medium (~45%)")]
        Medium = 45,

        /// <summary>
        /// Dark
        /// </summary>
        [Display(Name = "Dark (~70%)")]
        Dark = 70
    }
}
