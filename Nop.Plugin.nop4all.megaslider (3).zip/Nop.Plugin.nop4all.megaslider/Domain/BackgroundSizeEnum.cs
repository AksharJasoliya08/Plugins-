﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represents background size options for slider.
    /// </summary>
    public enum BackgroundSizeEnum
    {
        /// <summary>
        /// Cover 
        /// </summary>
        Cover = 0,

        /// <summary>
        /// Contain
        /// </summary>
        Contain = 1,

        /// <summary>
        /// Repeat
        /// </summary>
        Repeat = 2
    }
}
