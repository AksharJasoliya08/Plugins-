﻿using System.ComponentModel.DataAnnotations;

namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represents the type of video used for the background.
    /// </summary>
    public enum BackgroundVideoType
    {
        /// <summary>
        /// Uploaded Video file
        /// </summary>
        [Display(Name = "Upload Video")]
        UploadVideo = 1,

        /// <summary>
        /// YouTube Link
        /// </summary>
        [Display(Name = "YouTube Video Link")]
        YouTubeLink = 2
    }
}
