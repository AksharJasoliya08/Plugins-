﻿using System.ComponentModel.DataAnnotations;

namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represent Positioning
    /// </summary>
    public enum Positioning
    {
        /// <summary>
        /// Top Center
        /// </summary>
        [Display(Name = "Top Center")]
        TopCenter = 1,

        /// <summary>
        /// Middle Center
        /// </summary>
        [Display(Name = "Middle Center")]
        MiddleCenter = 2,

        /// <summary>
        /// Bottom Center
        /// </summary>
        [Display(Name = "Bottom Center")]
        BottomCenter = 3,

        /// <summary>
        /// Middle Left
        /// </summary>
        [Display(Name = "Middle Left")]
        MiddleLeft = 4,

        /// <summary>
        /// Middle Right
        /// </summary>
        [Display(Name = "Middle Right")]
        MiddleRight = 5,

        /// <summary>
        /// Bottom Right
        /// </summary>
        [Display(Name = "Bottom Right")]
        BottomRight = 6,

        /// <summary>
        /// Bottom Left
        /// </summary>
        [Display(Name = "Bottom Left")]
        BottomLeft = 7,
    }
}