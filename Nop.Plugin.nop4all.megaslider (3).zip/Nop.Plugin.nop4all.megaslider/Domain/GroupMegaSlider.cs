﻿using Nop.Core;
using Nop.Core.Domain.Stores;

namespace Nop.Plugin.nop4all.megaslider.Domain;

/// <summary>
/// Represents a Group Mega Slider entity.
/// </summary>
public class GroupMegaSlider : BaseEntity, IStoreMappingSupported
{
    /// <summary>
    /// Gets or sets the Enable
    /// </summary>
    public bool Enable { get; set; }
    /// <summary>
    /// Gets or sets the name of the slider.
    /// </summary>
    public string  Name { get; set; }
    /// <summary>
    /// Gets or sets the display order of the slider.
    /// </summary>
    public int DisplayOrder { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether the slider is limited to specific stores.
    /// </summary>
    public bool LimitedToStores { get; set; }
    /// <summary>
    /// Gets or Widgetzone 
    /// </summary>
    public string Widgetzone { get; set; }
    /// <summary>
    /// Gets or show content
    /// </summary>
    public bool Show { get; set; }
    /// <summary>
    /// Gets or Hide content 
    /// </summary>
    public bool Hide { get; set; }
    /// <summary>
    /// Gets or Left side menu  
    /// </summary>
    public bool LeftSide { get; set; }
    /// <summary>
    /// Gets or right side menu  
    /// </summary>
    public bool RightSide { get; set; }
    /// <summary>
    /// Gets or dot & arrow 
    /// </summary>
    public bool DotArrrow { get; set; }
    /// <summary>
    /// Gets or Menu item 
    /// </summary>
    public bool Menu { get; set; }

    public int AnimationEffectId { get; set; }

    /// <summary>
    /// Gets or sets slider height 
    /// </summary>
    public int GroupSliderHeight { get; set; }

    public int TransitionAnimationEffectId { get; set; }
}
