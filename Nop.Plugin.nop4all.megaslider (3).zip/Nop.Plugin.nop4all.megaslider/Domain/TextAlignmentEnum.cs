﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represent Text Alignment enum
    /// </summary>
    public enum TextAlignmentEnum
    {
        /// <summary>
        /// Left
        /// </summary>
        Left = 0,

        /// <summary>
        /// Center
        /// </summary>
        Center = 1,

        /// <summary>
        /// Right
        /// </summary>
        Right = 2
    }
}
