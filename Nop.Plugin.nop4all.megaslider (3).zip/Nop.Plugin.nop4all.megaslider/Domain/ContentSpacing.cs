﻿using System.ComponentModel.DataAnnotations;

namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Defines spacing levels for content inside the slider (padding/margins between elements).
    /// </summary>
    public enum ContentSpacingenum
    {
        /// <summary>
        /// Compact
        /// </summary>
        [Display(Name = "Compact")]
        Compact = 1,

        /// <summary>
        /// Normal
        /// </summary>
        [Display(Name = "Normal")]
        Normal = 2,

        /// <summary>
        /// Relaxed
        /// </summary>
        [Display(Name = "Relaxed")]
        Relaxed = 3
    }
}
