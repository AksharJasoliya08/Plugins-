﻿using Nop.Core;
using Nop.Core.Domain.Localization;
using Nop.Core.Domain.Stores;

namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represents a Mega Slider entity.
    /// </summary>
    public class MegaSlider : BaseEntity, IStoreMappingSupported, ILocalizedEntity
    {
        /// <summary>
        /// Gets or sets the name of the slider.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the content (HTML or text) displayed in the slider.
        /// </summary>
        public int ContentType { get; set; }

        /// <summary>
        /// Gets or sets the ProductType
        /// </summary>
        public bool ProductType { get; set; }

        /// <summary>
        /// Gets or sets the raw HTML content for the slider.
        /// </summary>
        public string HtmlContent { get; set; }

        /// <summary>
        /// Gets or sets the ProductAutoplay
        /// </summary>
        public int ProductAutoplay { get; set; }

        /// <summary>
        /// Gets or sets the Title
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets the ShortDescription
        /// </summary>
        public string ShortDescription { get; set; }

        /// <summary>
        /// set or get position on title
        /// </summary>
        public int Positioning { get; set; }
        
        /// <summary>
        /// Gets or Widgetzone 
        /// </summary>
        public string WidgetZone { get; set; }

        /// <summary>
        /// Get or Set IncludeTop
        /// </summary>
        public bool IncludeTop { get; set; }

        /// <summary>
        /// Gets or sets the display order of the slider.
        /// </summary>
        public int DisplayOrder { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the slider is limited to specific stores.
        /// </summary>
        public bool LimitedToStores { get; set; }

        /// <summary>
        /// Gets or sets the NewProductseffect
        /// </summary>
        public string NewProductseffect { get; set; }

        /// <summary>
        /// Gets or sets the FeaturedProductEffect
        /// </summary>
        public string FeaturedProductEffect { get; set; }

        /// <summary>
        /// Gets or sets the FeaturedProductEffect
        /// </summary>
        public string SellProductModelEffect { get; set; }

        /// <summary>
        /// Gets or sets the Enable
        /// </summary>
        public bool Enable { get; set; }

        /// <summary>
        /// Gets or sets a ProductSliderDots
        /// </summary>
        public bool ProductSliderDots { get; set; }

        /// <summary>
        /// Gets or sets a ProductSliderArrows
        /// </summary>
        public bool ProductSliderArrows { get; set; }
        
        /// <summary>
        /// Gets or sets the SliderDelay delay in milliseconds 
        /// between slider animations.
        /// </summary>
        public int SliderDelay { get; set; }

        /// <summary>
        /// Gets or sets whether YouTube video should autoplay
        /// </summary>
        public bool IsAutoPlay { get; set; }
        /// <summary>
        /// Gets or sets whether YouTube video should use natural video size on mobile
        /// </summary>
        public bool UseNaturalVideoSizeOnMobile { get; set; }

        #region New Tab

        #region Content

        /// <summary>
        /// Gets or sets the badge text displayed on the slider.
        /// </summary>
        public string BadgeText { get; set; }

        /// <summary>
        /// Gets or sets the ID of the badge image associated with the slider.
        /// </summary>
        public int BadgeImageId { get; set; }

        /// <summary>
        /// Gets or sets the price-related text displayed on the slider.
        /// </summary>
        public string PriceText { get; set; }

        /// <summary>
        /// Gets or sets the alternative text description for the slide image.
        /// </summary>
        public string SlideAltDescription { get; set; }
        #endregion

        #region Zone

        /// <summary>
        /// Gets or sets the zone type 
        /// </summary>
        public int ZoneType { get; set; }

        #region Left Zone

        /// <summary>
        /// Gets or sets the ID of the image displayed on the left side.
        /// </summary>
        public int LeftImageId { get; set; }

        /// <summary>
        /// Gets or sets the URL link associated with the left image.
        /// </summary>
        public string LeftImageLink { get; set; }

        /// <summary>
        /// Gets or sets the background color applied to the left section.
        /// </summary>
        public string LeftColor { get; set; }

        /// <summary>
        /// Gets or sets empty content for the left section.
        /// </summary>
        public string LeftEmpty { get; set; }

        /// <summary>
        /// Gets or sets a left image link should open in a new browser tab.
        /// </summary>
        public bool LeftOpenInNewTab { get; set; }

        /// <summary>
        /// Gets or sets a left section should be hidden on desktop devices.
        /// </summary>
        public bool LeftHideOnDesktop { get; set; }

        /// <summary>
        /// Gets or sets a left section should be hidden on mobile devices.
        /// </summary>
        public bool LeftHideOnMobile { get; set; }

        /// <summary>
        /// Gets or sets the left image (used for accessibility and SEO).
        /// </summary>
        public string LeftImageAlt { get; set; }

        /// <summary>
        /// Gets or sets the overlay intensity applied on the left side.
        /// </summary>
        public int LeftOverlay { get; set; }

        /// <summary>
        /// Gets or sets the color preset applied to the left section.
        /// </summary>
        public int LeftColorpreset { get; set; }

        /// <summary>
        /// Gets or sets the zone type that determines the layout or placement of the left section.
        /// </summary>
        public int LeftZoneType { get; set; }
        #endregion

        #region Right Zone
        /// <summary>
        /// Gets or sets the ID of the image displayed on the right side.
        /// </summary>
        public int RightImageId { get; set; }

        /// <summary>
        /// Gets or sets the URL link associated with the right image.
        /// </summary>
        public string RightImageLink { get; set; }

        /// <summary>
        /// Gets or sets the background color applied to the right section.
        /// </summary>
        public string RightColor { get; set; }

        /// <summary>
        /// Gets or sets empty content for the right section.
        /// </summary>
        public string RightEmpty { get; set; }

        /// <summary>
        /// Gets or sets a right image link should open in a new browser tab.
        /// </summary>
        public bool RightOpenInNewTab { get; set; }

        /// <summary>
        /// Gets or sets a right section should be hidden on desktop devices.
        /// </summary>
        public bool RightHideOnDesktop { get; set; }

        /// <summary>
        /// Gets or sets a right section should be hidden on mobile devices.
        /// </summary>
        public bool RightHideOnMobile { get; set; }

        /// <summary>
        /// Gets or sets the right image (used for accessibility and SEO).
        /// </summary>
        public string RightImageAlt { get; set; }

        /// <summary>
        /// Gets or sets the overlay intensity applied on the right side (e.g., light, medium, dark).
        /// </summary>
        public int RightOverlay { get; set; }

        /// <summary>
        /// Gets or sets the predefined color preset applied to the right section.
        /// </summary>
        public int RightColorpreset { get; set; }

        /// <summary>
        /// Gets or sets the zone type that determines the layout or placement of the right section.
        /// </summary>
        public int RightZoneType { get; set; }
        #endregion
        #endregion

        #region Layout & Style

        /// <summary>
        /// Gets or sets a value indicating whether the text block should be offset (custom positioned).
        /// </summary>
        public bool TextBlockOffset { get; set; }

        //change
        /// <summary>
        /// Gets or sets the top offset value (in pixels) for positioning the text block.
        /// </summary>
        public int? Top {  get; set; }

        /// <summary>
        /// Gets or sets the right offset value (in pixels) for positioning the text block.
        /// </summary>
        public int? Right { get; set; }

        /// <summary>
        /// Gets or sets the bottom offset value (in pixels) for positioning the text block.
        /// </summary>
        public int? Bottom { get; set; }

        /// <summary>
        /// Gets or sets the left offset value (in pixels) for positioning the text block.
        /// </summary>
        public int? Left { get; set; }

        /// <summary>
        /// Gets or sets the predefined position of the text block (e.g., top-left, center, bottom-right).
        /// </summary>
        public int TextBlockPosition { get; set; }

        /// <summary>
        /// Gets or sets the spacing level between content elements inside the text block.
        /// </summary>
        public int ContentSpacing { get; set; }

        /// <summary>
        /// Gets or sets the card theme applied to the text block (e.g., light, dark, brand, custom).
        /// </summary>
        public int Cardtheme { get; set; }

        /// <summary>
        /// Gets or sets the custom background color of the card when a custom theme is selected.
        /// </summary>
        public string Cardbackgroundcolor { get; set; }

        #region Layout & Style - Slide Background

        /// <summary>
        /// Gets or sets the background type (0 = None, 1 = Color, 2 = Image)
        /// </summary>
        public int BackgroundType { get; set; }

        /// <summary>
        /// Gets or sets the background color (hex value)
        /// </summary>
        public string BackgroundColor { get; set; }

        /// <summary>
        /// Gets or sets the background image identifier
        /// </summary>
        public int BackgroundImageId { get; set; }

        /// <summary>
        /// Gets or sets the background size (0 = Cover, 1 = Contain, 2 = Auto)
        /// </summary>
        public int BackgroundSize { get; set; }

        /// <summary>
        /// Gets or sets the background overlay type (0 = None, 1 = Dark, 2 = Light)
        /// </summary>
        public int BackgroundOverlay { get; set; }

        // new
        /// <summary>
        /// Gets or sets the URL of the background video (either uploaded file path or external link).
        /// </summary>
        public string BackgroundVideoUrl { get; set; }

        /// <summary>
        /// Gets or sets the type of background video source (e.g., upload or YouTube link).
        /// </summary>
        public int BackgroundVideoTypeId { get; set; }

        #endregion

        #region Layout & Style - Text Block Appearance

        /// <summary>
        /// Gets or sets the text alignment (0 = Left, 1 = Center, 2 = Right)
        /// </summary>
        public int TextAlignment { get; set; }

        /// <summary>
        /// Gets or sets the block style (0 = Inline, 1 = Card)
        /// </summary>
        public int BlockStyle { get; set; }

        /// <summary>
        /// Gets or sets the text theme (0 = LightOnDark, 1 = DarkOnLight, 2 = Accent)
        /// </summary>
        public int TextTheme { get; set; }

        /// <summary>
        /// Gets or sets the font size of the title text.
        /// </summary>
        public int TitleFontSize { get; set; }

        #endregion
        #endregion


        #endregion

        #region CTA Button 1

        /// <summary>
        /// Gets or sets a value indicating whether CTA Button 1 is visible on the slider.
        /// </summary>
        public bool CTAButton1IsVisible { get; set; }

        /// <summary>
        /// Gets or sets the display text of CTA Button 1.
        /// This field supports localization.
        /// </summary>
        public string CTAButton1Text { get; set; }

        /// <summary>
        /// Gets or sets the selected style identifier for CTA Button 1.
        /// </summary>
        public int CTAButton1StyleId { get; set; }

        /// <summary>
        /// Gets or sets the background color of CTA Button 1.
        /// </summary>
        public string CTAButton1BackgroundColor { get; set; }

        /// <summary>
        /// Gets or sets the text color of CTA Button 1.
        /// </summary>
        public string CTAButton1TextColor { get; set; }

        /// <summary>
        /// Gets or sets the redirect URL for CTA Button 1.
        /// This field supports localization.
        /// </summary>
        public string CTAButton1RedirectUrl { get; set; }

        /// <summary>
        /// Gets or sets the font size of CTA Button 1.
        /// </summary>
        public int CTAButton1FontSize { get; set; }

        //add new
        /// <summary>
        /// Gets or sets a value indicating whether the first call-to-action (CTA1) link should open in a new browser tab.
        /// </summary>
        public bool Cta1OpenInNewTab { get; set; }

        #endregion

        #region CTA Button 2

        /// <summary>
        /// Gets or sets a value indicating whether CTA Button 2 is visible on the slider.
        /// </summary>
        public bool CTAButton2IsVisible { get; set; }

        /// <summary>
        /// Gets or sets the display text of CTA Button 2.
        /// This field supports localization.
        /// </summary>
        public string CTAButton2Text { get; set; }

        /// <summary>
        /// Gets or sets the selected style identifier for CTA Button 2.
        /// </summary>
        public int CTAButton2StyleId { get; set; }

        /// <summary>
        /// Gets or sets the background color of CTA Button 2.
        /// </summary>
        public string CTAButton2BackgroundColor { get; set; }

        /// <summary>
        /// Gets or sets the text color of CTA Button 2.
        /// </summary>
        public string CTAButton2TextColor { get; set; }

        /// <summary>
        /// Gets or sets the redirect URL for CTA Button 2.
        /// This field supports localization.
        /// </summary>
        public string CTAButton2RedirectUrl { get; set; }

        /// <summary>
        /// Gets or sets the font size of CTA Button 2.
        /// </summary>
        public int CTAButton2FontSize { get; set; }

        //add new
        /// <summary>
        /// Gets or sets a value indicating whether the second call-to-action (CTA2) link should open in a new browser tab.
        /// </summary>
        public bool Cta2OpenInNewTab { get; set; }

        #endregion

        #region Remove code 

        /// <summary>
        /// Gets or sets the transition effect delay in milliseconds 
        /// between slider animations.
        /// </summary>
        //public int TransitionEffectDelay { get; set; }

        /// <summary>
        /// Gets or sets the Text transitions
        /// </summary>
        //public string Texttransitions { get; set; }

        /// <summary>
        /// set or get ContentLayerPositions
        /// </summary>
        //public int ContentLayerPositions { get; set; }
        /// <summary>
        /// set or get ContentLayerPositionsSecond
        /// </summary>
        //public int ContentLayerPositionsSecond { get; set; }

        /// <summary>
        /// set or get ContentLayerPositionsThird
        /// </summary>
        //public int ContentLayerPositionsThird { get; set; }

        /// <summary>
        /// Set title font size
        /// </summary>
        //public int TitleFontSize { get; set; }

        /// <summary>
        /// set description font sixe
        /// </summary>
        //public int DescriptionFontSize { get; set; }

        /// <summary>
        /// Gets or sets the ContentLayer
        /// </summary>
        //public string ContentLayer { get; set; }

        /// <summary>
        /// Gets or sets the ContentLayer3
        /// </summary>
        //public string ContentLayer3 { get; set; }

        /// <summary>
        /// Gets or sets the Content
        /// </summary>
        //public string Content { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the animation should repeat continuously.
        /// </summary>
        //public bool AllowRepeatAnimation { get; set; } 
        #endregion


        #region EnumType 
        public Positioning Positioningg
        {
            get => (Positioning)Positioning;
            set => Positioning = (int)value;
        }

        public ContentTypeEnum ContentTypeEnum
        {
            get => (ContentTypeEnum)ContentType;
            set => ContentType = (int)value;
        }

        public TextBlockPositionenum TextBlockPositionenum 
        {  
            get => (TextBlockPositionenum)TextBlockPosition;  
            set => TextBlockPosition = (int)value; 
        }

        public ContentSpacingenum ContentSpacingenum
        {
            get => (ContentSpacingenum)ContentSpacing;
            set => ContentSpacing = (int)value;
        }

        public ZoneTypeEnum LeftZoneTypes
        {
            get => (ZoneTypeEnum)LeftZoneType;
            set => LeftZoneType = (int)value;
        }
        public ZoneTypeEnum RightZoneTypes
        {
            get => (ZoneTypeEnum)RightZoneType;
            set => RightZoneType = (int)value;
        }

        public OverlayType LeftOverlays
        {
            get => (OverlayType)LeftOverlay;
            set => LeftOverlay = (int)value;
        }
        public OverlayType RightOverlays
        {
            get => (OverlayType)RightOverlay;
            set => RightOverlay = (int)value;
        }

        public ColorPresetType LeftColorpresets
        {
            get => (ColorPresetType)LeftColorpreset;
            set => LeftColorpreset = (int)value;
        }
        public ColorPresetType RightColorpresets
        {
            get => (ColorPresetType)RightColorpreset;
            set => RightColorpreset = (int)value;
        }

        // New enum properties for layout & style
        public BackgroundTypeEnum BackgroundTypeEnum
        {
            get => (BackgroundTypeEnum)BackgroundType;
            set => BackgroundType = (int)value;
        }

        public BackgroundSizeEnum BackgroundSizeEnum
        {
            get => (BackgroundSizeEnum)BackgroundSize;
            set => BackgroundSize = (int)value;
        }

        public OverlayType BackgroundOverlayEnum
        {
            get => (OverlayType)BackgroundOverlay;
            set => BackgroundOverlay = (int)value;
        }

        public TextAlignmentEnum TextAlignmentEnum
        {
            get => (TextAlignmentEnum)TextAlignment;
            set => TextAlignment = (int)value;
        }
        public BlockStyleEnum BlockStyleEnum
        {
            get => (BlockStyleEnum)BlockStyle;
            set => BlockStyle = (int)value;
        }

        public TextThemeEnum TextThemeEnum
        {
            get => (TextThemeEnum)TextTheme;
            set => TextTheme = (int)value;
        }

        public CardTheme CardThemes
        {
            get => (CardTheme)Cardtheme;
            set => Cardtheme = (int)value;
        }

        public TitleFontSizeEnum TitleFontSizeEnum
        {
            get => (TitleFontSizeEnum)TitleFontSize;
            set => TitleFontSize = (int)value;
        }

        //remove code 
        //public ContentLayerPositions ContentLayerPositionsSecondd
        //{
        //    get => (ContentLayerPositions)ContentLayerPositionsSecond;
        //    set => ContentLayerPositionsSecond = (int)value;
        //}
        //public ContentLayerPositions ContentLayerPositionsThirdd
        //{
        //    get => (ContentLayerPositions)ContentLayerPositionsThird;
        //    set => ContentLayerPositionsThird = (int)value;
        //}

        #endregion
    }
}