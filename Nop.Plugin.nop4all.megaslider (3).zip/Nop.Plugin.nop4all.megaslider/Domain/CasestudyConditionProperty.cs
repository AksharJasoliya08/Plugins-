﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    public enum CasestudyConditionProperty
    {
        /// <summary>
        /// Default
        /// </summary>
        Default,

        /// <summary>
        /// SystemName
        /// </summary>
        SystemName,
    }
}
