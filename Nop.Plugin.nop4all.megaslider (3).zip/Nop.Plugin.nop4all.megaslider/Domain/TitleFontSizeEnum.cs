﻿using System.ComponentModel.DataAnnotations;

namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represent Title Font Size Enum
    /// </summary>
    public enum TitleFontSizeEnum
    {
        /// <summary>
        /// Small font size.
        /// </summary>
        [Display(Name = "Small")]
        Small = 1,

        /// <summary>
        /// Normal font size.
        /// </summary>
        [Display(Name = "Normal")]
        Normal = 2,

        /// <summary>
        /// Large font size.
        /// </summary>
        [Display(Name = "Large")]
        Large = 3,

        /// <summary>
        /// XL font size.
        /// </summary>
        [Display(Name = "XL")]
        XL = 4,

        /// <summary>
        /// XXL font size.
        /// </summary>
        [Display(Name = "XXL")]
        XXL = 5,
    }
}
