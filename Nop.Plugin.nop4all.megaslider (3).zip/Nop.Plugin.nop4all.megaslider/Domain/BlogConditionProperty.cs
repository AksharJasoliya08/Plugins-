﻿namespace Nop.Plugin.nop4all.megaslider.Domain;

    /// <summary>
    /// Represents condition property enumeration
    /// </summary>
    public enum BlogConditionProperty
    {
        /// <summary>
        /// Default
        /// </summary>
        Default,

        /// <summary>
        /// SystemName
        /// </summary>
        SystemName,
    }