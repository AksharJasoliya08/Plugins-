﻿using Nop.Core;

namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represents a Group condition
    /// </summary>
    public partial class MegaSliderGroupCondition : BaseEntity
    {
        /// <summary>
        /// Gets or sets the type identifier Group Id.
        /// </summary>
        public int GroupId { get; set; }

        /// <summary>
        /// Gets or sets the type identifier Condition Type .
        /// </summary>
        public string ConditionType { get; set; }

        /// <summary>
        /// Gets or sets the type identifier Property.
        /// </summary>
        public int Property { get; set; }

        /// <summary>
        /// Gets or sets the type identifier Oprater.
        /// </summary>
        public int Oprater { get; set; }

        /// <summary>
        /// Gets or sets the type identifier Value.
        /// </summary>
        public string Value { get; set; }

        /// <summary>
        /// Get or sets WidgetZone
        /// </summary>
        public string WidgetZone { get; set; }

    }
}