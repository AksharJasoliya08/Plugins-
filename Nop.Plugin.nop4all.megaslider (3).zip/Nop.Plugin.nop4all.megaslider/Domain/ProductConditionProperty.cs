﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represents product condition property enumeration
    /// </summary>
    public enum ProductConditionProperty
    {
        /// <summary>
        /// EqualTo
        /// </summary>
        Default,

        /// <summary>
        /// Category
        /// </summary>
        Category,

        /// <summary>
        /// Manufacturer
        /// </summary>
        Manufacturer,

        /// <summary>
        /// ProductAgeHours
        /// </summary>
        ProductAgeHours,

        /// <summary>
        /// DiscountAmmount
        /// </summary>
        DiscountAmmount,

        /// <summary>
        /// DiscountPercentage
        /// </summary>
        DiscountPercentage,

        /// <summary>
        /// PriceDifferenceAmmount
        /// </summary>
        PriceDifferenceAmmount,

        /// <summary>
        /// PriceDifferencePercentage
        /// </summary>
        PriceDifferencePercentage,

        /// <summary>
        /// MinPrice
        /// </summary>
        MinPrice,

        /// <summary>
        /// Quantity
        /// </summary>
        Quantity,

        /// <summary>
        /// PreOrder
        /// </summary>
        PreOrder,

        /// <summary>
        /// FreeShipping
        /// </summary>
        FreeShipping,

        /// <summary>
        /// HasSpecialPrice
        /// </summary>
        HasSpecialPrice,

        /// <summary>
        /// MarkedAsNew
        /// </summary>
        MarkedAsNew,

        /// <summary>
        /// Vendor
        /// </summary>
        Vendor,

        /// <summary>
        /// Name
        /// </summary>
        Name,
    }
}