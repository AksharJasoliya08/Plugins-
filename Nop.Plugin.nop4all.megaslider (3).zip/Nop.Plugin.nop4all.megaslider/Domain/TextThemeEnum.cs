﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represent Text Theme Enum
    /// </summary>
    public enum TextThemeEnum
    {
        /// <summary>
        /// Light On Dark
        /// </summary>
        LightOnDark = 0,

        /// <summary>
        /// Dark On Light
        /// </summary>
        DarkOnLight = 1,

        /// <summary>
        /// Accent 
        /// </summary>
        Accent = 2
    }
}
