﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represents manufacturer condition property enumeration
    /// </summary>
    public enum ManufacturerConditionProperty
    {
        /// <summary>
        /// Default
        /// </summary>
        Default,

        /// <summary>
        /// Name
        /// </summary>
        Name,
    }
}