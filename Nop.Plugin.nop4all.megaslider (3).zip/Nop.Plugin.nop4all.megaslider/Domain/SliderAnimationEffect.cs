﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    public enum SliderAnimationEffect
    {
        None = 0,
        swing = 1,
        headShake = 2,
        fadeIn = 3,
        bounceInDown = 4,
        zoomIn = 5,
        zoomInDown = 6,
        rotateIn = 7,
        rollIn = 8,
        slideInUp = 9,
        jello = 10,
        pulse = 11,
        flash = 12
    }
}
