﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Defines the layout style of the content block in the slider.
    /// </summary>
    public enum BlockStyleEnum
    {
        /// <summary>
        /// Inline
        /// </summary>
        Inline = 0,

        /// <summary>
        /// Card
        /// </summary>
        Card = 1
    }
}
