﻿namespace Nop.Plugin.nop4all.megaslider.Domain
{
    /// <summary>
    /// Represents topic condition property enumeration
    /// </summary>
    public enum TopicConditionProperty
    {
        /// <summary>
        /// Default
        /// </summary>
        Default,

        /// <summary>
        /// SystemName
        /// </summary>
        SystemName,
    }
}