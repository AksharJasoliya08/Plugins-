﻿using FluentValidation;
using Nop.Plugin.nop4all.megaslider.Model.Slider;
using Nop.Services.Localization;
using Nop.Web.Framework.Validators;

public class SliderValidator : BaseNopValidator<SliderModel>
{
    public SliderValidator(ILocalizationService localizationService)
    {
        //CTA Button
        RuleFor(x => x.CTAButton1Text)
            .NotEmpty()
            .When(x => x.CTAButton1IsVisible)
            .WithMessageAwait(localizationService.GetResourceAsync("Plugin.nop4all.megamenu4all.Fields.CTAButton1TextErrorMsg"));

        RuleFor(x => x.CTAButton1RedirectUrl)
            .NotEmpty()
            .When(x => x.CTAButton1IsVisible)
            .WithMessageAwait(localizationService.GetResourceAsync("Plugin.nop4all.megamenu4all.Fields.CTAButton1RedirectUrlErrorMsg"));

       RuleFor(x => x.CTAButton2Text)
            .NotEmpty()
            .When(x => x.CTAButton2IsVisible)
            .WithMessageAwait(localizationService.GetResourceAsync("Plugin.nop4all.megamenu4all.Fields.CTAButton2TextErrorMsg"));

        RuleFor(x => x.CTAButton2RedirectUrl)
            .NotEmpty()
            .When(x => x.CTAButton2IsVisible)
            .WithMessageAwait(localizationService.GetResourceAsync("Plugin.nop4all.megamenu4all.Fields.CTAButton2RedirectUrlErrorMsg"));

        //Content Tab
        RuleFor(x => x.BadgeImageId)
            .NotEmpty()
            .WithMessageAwait(localizationService.GetResourceAsync("Plugin.nop4all.megamenu4all.Fields.BadgeImageIdErrorMsg"));

        // LEFT SIDE VALIDATION
        RuleFor(x => x)
            .Must(x => !(x.LeftHideOnMobile && x.LeftHideOnDesktop))
            .WithMessageAwait(localizationService.GetResourceAsync("Plugin.nop4all.megaslider.Fields.LeftHideErrorMsg"));

        // RIGHT SIDE VALIDATION
        RuleFor(x => x)
            .Must(x => !(x.RightHideOnMobile && x.RightHideOnDesktop))
            .WithMessageAwait(localizationService.GetResourceAsync("Plugin.nop4all.megaslider.Fields.RightHideErrorMsg"));


    }
}