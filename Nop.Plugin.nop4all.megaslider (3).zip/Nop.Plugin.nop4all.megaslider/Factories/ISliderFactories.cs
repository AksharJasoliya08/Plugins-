﻿using Nop.Plugin.nop4all.megaslider.Domain;
using Nop.Plugin.nop4all.megaslider.Model;
using Nop.Plugin.nop4all.megaslider.Model.FeatureProduct;
using Nop.Plugin.nop4all.megaslider.Model.MSLanguageResource;
using Nop.Plugin.nop4all.megaslider.Model.NewProduct;
using Nop.Plugin.nop4all.megaslider.Model.SellProduct;
using Nop.Plugin.nop4all.megaslider.Model.Slider;

namespace Nop.Plugin.nop4all.megaslider.Factories
{
    /// <summary>
    /// Represents the Mega Slider model factory interface.
    /// </summary>
    public interface ISliderFactories
    {
        /// <summary>
        /// Prepares the group mega slider model.
        /// </summary>
        /// <param name="model">The slider model.</param>
        /// <param name="mega_Slider">The Group Mega Slider entity.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the prepared slider model.</returns>

        Task<GroupSliderModel> PrepareGroupSliderModelAsync(GroupSliderModel model, GroupMegaSlider groupmegaslider, bool excludeProperties = false);

        /// <summary>
        /// Prepares the group mega slider model list.
        /// </summary>
        /// <param name="model">The slider model.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the prepared slider model.</returns>
        Task<GroupSliderListModel> PrepareGroupSliderListModelAsync(GroupSliderSearchModel model);

        /// <summary>
        /// Prepares the slider model.
        /// </summary>
        /// <param name="model">The slider model.</param>
        /// <param name="mega_Slider">The Mega Slider entity.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the prepared slider model.</returns>
        Task<SliderModel> PrepareSliderModelAsync(SliderModel model, MegaSlider mega_Slider, bool excludeProperties = false);

        /// <summary>
        /// Prepares the featured product list model for a specific slider.
        /// </summary>
        /// <param name="searchModel">The featured product search model.</param>
        /// <param name="mega_Slider">The Mega Slider entity.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the featured product list model.</returns>
        Task<FeatureProductListModel> PrepareCategoryProductListModelAsync(FeatureProductSearchModel searchModel, MegaSlider mega_Slider);

        /// <summary>
        /// Prepares the search model used to add products to the featured product list.
        /// </summary>
        /// <param name="searchModel">The add product to feature search model.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the prepared search model.</returns>
        Task<AddProductToFeatureSearchModel> PrepareAddProductToFeatureSearchModelAsync(AddProductToFeatureSearchModel searchModel);

        /// <summary>
        /// Prepares the model for displaying a list of products that can be added as featured products to the slider.
        /// </summary>
        /// <param name="searchModel">The add product to feature search model.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the add feature product to slider list model.</returns>
        Task<AddFeatureProductToSliderListModel> PrepareAddFeatureProductToSliderListModelAsync(AddProductToFeatureSearchModel searchModel);

        /// <summary>
        /// Prepares the new product list model for a specific slider.
        /// </summary>
        /// <param name="searchModel">The new product search model.</param>
        /// <param name="mega_Slider">The Mega Slider entity.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the new product list model.</returns>
        Task<NewProductListModel> PrepareNewProductListModelAsync(NewProductSearchModel searchModel, MegaSlider mega_Slider);

        /// <summary>
        /// Prepares the search model used to add new products to the slider.
        /// </summary>
        /// <param name="searchModel">The add product to new search model.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the prepared search model.</returns>
        Task<AddProductToNewSearchModel> PrepareAddProductToNewSearchModelAsync(AddProductToNewSearchModel searchModel);

        /// <summary>
        /// Prepares the model for displaying a list of products that can be added as new products to the slider.
        /// </summary>
        /// <param name="searchModel">The add product to new search model.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the add new product to slider list model.</returns>
        Task<AddNewProductToSliderListModel> PrepareAddNewProductToSliderListModelAsync(AddProductToNewSearchModel searchModel);

        /// <summary>
        /// Prepares the new product list model for a specific slider.
        /// </summary>
        /// <param name="searchModel">The new product search model.</param>
        /// <param name="mega_Slider">The Mega Slider entity.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the new product list model.</returns>
        Task<SellProductListModel> PrepareSellProductListModelAsync(SellProductSearchModel searchModel, MegaSlider mega_Slider);

        /// <summary>
        /// Prepares the search model used to add new products to the slider.
        /// </summary>
        /// <param name="searchModel">The add product to new search model.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the prepared search model.</returns>
        Task<AddProductToSellSearchModel> PrepareAddProductToSellSearchModelAsync(AddProductToSellSearchModel searchModel);

        /// <summary>
        /// Prepares the model for displaying a list of products that can be added as new products to the slider.
        /// </summary>
        /// <param name="searchModel">The add product to new search model.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the add new product to slider list model.</returns>
        Task<AddSellProductToSliderListModel> PrepareAddSellProductToSliderListModelAsync(AddProductToSellSearchModel searchModel);

        /// <summary>
        /// Prepares the language resource search model for Mega Slider.
        /// </summary>
        /// <param name="searchModel">The language resource search model.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the prepared language resource search model.</returns>
        Task<MSLanguageResourceSearchModel> PrepareMSLanguageResourceSearchModelAsync(MSLanguageResourceSearchModel searchModel);

        /// <summary>
        /// Prepares the language resource list model for Mega Slider.
        /// </summary>
        /// <param name="searchModel">The language resource search model.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the prepared language resource list model.</returns>
        Task<MSLanguageResourceListModel> PrepareMSLanguageResourceListModelAsync(MSLanguageResourceSearchModel searchModel);
    }
}
