﻿using ExCSS;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.Routing;
using Nop.Core.Domain.Catalog;
using Nop.Plugin.nop4all.megaslider.Domain;
using Nop.Plugin.nop4all.megaslider.Model;
using Nop.Plugin.nop4all.megaslider.Model.FeatureProduct;
using Nop.Plugin.nop4all.megaslider.Model.MSLanguageResource;
using Nop.Plugin.nop4all.megaslider.Model.NewProduct;
using Nop.Plugin.nop4all.megaslider.Model.SellProduct;
using Nop.Plugin.nop4all.megaslider.Model.Slider;
using Nop.Plugin.nop4all.megaslider.Models;
using Nop.Plugin.nop4all.megaslider.Services;
using Nop.Services.Catalog;
using Nop.Services.Localization;
using Nop.Services.Media;
using Nop.Web.Areas.Admin.Factories;
using Nop.Web.Framework.Factories;
using Nop.Web.Framework.Models.Extensions;

namespace Nop.Plugin.nop4all.megaslider.Factories
{
    public class SliderFactories : ISliderFactories
    {
        #region Fields
        protected readonly IMegasliderServices _megaService;
        protected readonly ILocalizationService _localizationService;
        protected readonly IProductService _productService;
        protected readonly IBaseAdminModelFactory _baseAdminModelFactory;
        protected readonly ILanguageService _languageService;
        protected readonly IMegasliderServices _megasliderServices;
        protected readonly IStoreMappingSupportedModelFactory _storeMappingSupportedModelFactory;
        protected readonly ILocalizedModelFactory _localizedModelFactory;
        protected readonly IPictureService _pictureService;
        protected readonly IUrlHelperFactory _urlHelperFactory;
        protected readonly IActionContextAccessor _actionContextAccessor;

        #endregion

        #region Ctor
        public SliderFactories(IMegasliderServices megaService,
           ILocalizationService localizationService,
           IProductService productService,
           IBaseAdminModelFactory baseAdminModelFactory,
           ILanguageService languageService,
           IMegasliderServices megasliderServices,
           IStoreMappingSupportedModelFactory storeMappingSupportedModelFactory,
           ILocalizedModelFactory localizedModelFactory,
           IPictureService pictureService,
           IUrlHelperFactory urlHelperFactory,
           IActionContextAccessor actionContextAccessor)
        {
            _megaService = megaService;
            _localizationService = localizationService;
            _productService = productService;
            _baseAdminModelFactory = baseAdminModelFactory;
            _languageService = languageService;
            _megasliderServices = megasliderServices;
            _storeMappingSupportedModelFactory = storeMappingSupportedModelFactory;
            _localizedModelFactory = localizedModelFactory;
            _pictureService = pictureService;
            _urlHelperFactory = urlHelperFactory;
            _actionContextAccessor = actionContextAccessor;
        }
        #endregion

        #region Methods

        /// <summary>
        /// Prepares the slider model.
        /// </summary>
        /// <param name="model">The slider model.</param>
        /// <param name="megaSlider">The Mega Slider entity.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the prepared slider model.</returns>
        public async Task<SliderModel> PrepareSliderModelAsync(SliderModel model, MegaSlider megaSlider,bool excludeProperties = false)
        {
            if (model == null)
                model = new SliderModel();

            model.Locales = await _localizedModelFactory.PrepareLocalizedModelsAsync<SliderLocalizedModel>(async (locale, languageId) =>
            {
                if (megaSlider != null)
                {
                    locale.Title = await _localizationService.GetLocalizedAsync(
                        megaSlider,
                        x => x.Title,
                        languageId,
                        false,
                        false);
                    locale.ShortDescription = await _localizationService.GetLocalizedAsync(
                        megaSlider,
                        x => x.ShortDescription,
                        languageId,
                        false,
                        false);
                    locale.CTAButton2Text = await _localizationService.GetLocalizedAsync(
                        megaSlider,
                        x => x.CTAButton2Text,
                        languageId,
                        false,
                        false);
                    locale.CTAButton1Text = await _localizationService.GetLocalizedAsync(
                        megaSlider,
                        x => x.CTAButton1Text,
                        languageId,
                        false,
                        false);
                    locale.CTAButton1RedirectUrl = await _localizationService.GetLocalizedAsync(
                        megaSlider,
                        x => x.CTAButton1RedirectUrl,
                        languageId,
                        false,
                        false);
                    locale.CTAButton2RedirectUrl = await _localizationService.GetLocalizedAsync(
                        megaSlider,
                        x => x.CTAButton2RedirectUrl,
                        languageId,
                        false,
                        false);
                    locale.HtmlContent = await _localizationService.GetLocalizedAsync(
                        megaSlider,
                        x => x.HtmlContent,
                        languageId,
                        false,
                        false);
                    locale.BadgeText = await _localizationService.GetLocalizedAsync(
                        megaSlider,
                        x => x.BadgeText,
                        languageId,
                        false,
                        false);
                    locale.PriceText = await _localizationService.GetLocalizedAsync(
                        megaSlider,
                        x => x.PriceText,
                        languageId,
                        false,
                        false);
                    locale.BackgroundVideoUrl = await _localizationService.GetLocalizedAsync(
                        megaSlider,
                        x => x.BackgroundVideoUrl,
                        languageId,
                        false,
                        false);

                    //Remove Code
                    //locale.Content = await _localizationService.GetLocalizedAsync(
                    //    megaSlider,
                    //    x => x.Content,
                    //    languageId,
                    //    false,
                    //    false);
                    //locale.ContentLayer = await _localizationService.GetLocalizedAsync(
                    //    megaSlider,
                    //    x => x.ContentLayer,
                    //    languageId,
                    //    false,
                    //    false);
                }
            });

            if (megaSlider != null && !excludeProperties)
            {
                model.FeatureProductSearchModel.MegaSliderId = megaSlider.Id;
                model.NewProductSearchModel.MegaSliderId = megaSlider.Id;
                model.SellProductSearchModel.MegaSliderId = megaSlider.Id;

                model.Id = megaSlider.Id;
                model.DisplayOrder = megaSlider.DisplayOrder;
                model.Title = megaSlider.Title;
                model.ShortDescription = megaSlider.ShortDescription;

                model.HtmlContent = megaSlider.HtmlContent;
                model.ContentType = megaSlider.ContentType;
                model.ProductType = megaSlider.ProductType;
                model.WidgetZone = megaSlider.WidgetZone;
                model.Name = megaSlider.Name;
                model.Enable = megaSlider.Enable;
                model.IncludeTop = megaSlider.IncludeTop;
                model.NewProductseffect = megaSlider.NewProductseffect;
                model.FeaturedProductEffect = megaSlider.FeaturedProductEffect;
                model.SellProductModelEffect = megaSlider.SellProductModelEffect;
                model.ProductSliderDots = megaSlider.ProductSliderDots;
                model.ProductSliderArrows = megaSlider.ProductSliderArrows;
                model.SliderDelay = megaSlider.SliderDelay;
                model.Positioning = megaSlider.Positioning;

                // CTA Button 1
                model.CTAButton1IsVisible = megaSlider.CTAButton1IsVisible;
                model.CTAButton1Text = megaSlider.CTAButton1Text;
                model.CTAButton1StyleId = megaSlider.CTAButton1StyleId;
                model.CTAButton1BackgroundColor = megaSlider.CTAButton1BackgroundColor;
                model.CTAButton1TextColor = megaSlider.CTAButton1TextColor;
                model.CTAButton1RedirectUrl = megaSlider.CTAButton1RedirectUrl;
                model.CTAButton1FontSize = megaSlider.CTAButton1FontSize;

                // CTA Button 2
                model.CTAButton2IsVisible = megaSlider.CTAButton2IsVisible;
                model.CTAButton2Text = megaSlider.CTAButton2Text;
                model.CTAButton2StyleId = megaSlider.CTAButton2StyleId;
                model.CTAButton2BackgroundColor = megaSlider.CTAButton2BackgroundColor;
                model.CTAButton2TextColor = megaSlider.CTAButton2TextColor;
                model.CTAButton2RedirectUrl = megaSlider.CTAButton2RedirectUrl;
                model.CTAButton2FontSize = megaSlider.CTAButton2FontSize;
                
                //Content model 
                model.BadgeText = megaSlider.BadgeText;
                model.BadgeImageId = megaSlider.BadgeImageId;
                model.PriceText = megaSlider.PriceText;
                model.SlideAltDescription = megaSlider.SlideAltDescription;
                model.Cta1OpenInNewTab = megaSlider.Cta1OpenInNewTab;
                model.Cta2OpenInNewTab = megaSlider.Cta2OpenInNewTab;

                //Zone model
                model.ZoneType = megaSlider.ZoneType;

                // Left Zone
                model.LeftImageId = megaSlider.LeftImageId;
                model.LeftImageLink = megaSlider.LeftImageLink;
                model.LeftColor = megaSlider.LeftColor;
                model.LeftEmpty = megaSlider.LeftEmpty;
                model.LeftOpenInNewTab = megaSlider.LeftOpenInNewTab;
                model.LeftHideOnDesktop = megaSlider.LeftHideOnDesktop;
                model.LeftHideOnMobile = megaSlider.LeftHideOnMobile;
                model.LeftImageAlt = megaSlider.LeftImageAlt;
                model.LeftOverlay = megaSlider.LeftOverlay;
                model.LeftColorpreset = megaSlider.LeftColorpreset;
                model.LeftZoneType = megaSlider.LeftZoneType;

                // Right Zone
                model.RightImageId = megaSlider.RightImageId;
                model.RightImageLink = megaSlider.RightImageLink;
                model.RightColor = megaSlider.RightColor;
                model.RightEmpty = megaSlider.RightEmpty;
                model.RightOpenInNewTab = megaSlider.RightOpenInNewTab;
                model.RightHideOnDesktop = megaSlider.RightHideOnDesktop;
                model.RightHideOnMobile = megaSlider.RightHideOnMobile;
                model.RightImageAlt = megaSlider.RightImageAlt;
                model.RightOverlay = megaSlider.RightOverlay;
                model.RightColorpreset = megaSlider.RightColorpreset;
                model.RightZoneType = megaSlider.RightZoneType;

                //layout model
                model.TextBlockOffset = megaSlider.TextBlockOffset;
                model.Top = megaSlider.Top;
                model.Right = megaSlider.Right;
                model.Bottom = megaSlider.Bottom;
                model.Left = megaSlider.Left;
                model.TextBlockPosition = megaSlider.TextBlockPosition;
                model.ContentSpacing = megaSlider.ContentSpacing;
                model.Cardtheme = megaSlider.Cardtheme;
                model.Cardbackgroundcolor = megaSlider.Cardbackgroundcolor;
                model.BackgroundColor = megaSlider.BackgroundColor;
                model.BackgroundImageId = megaSlider.BackgroundImageId;
                model.BackgroundType = megaSlider.BackgroundType;
                model.BackgroundSize = megaSlider.BackgroundSize;
                model.BackgroundOverlay = megaSlider.BackgroundOverlay;
                model.TitleFontSize = megaSlider.TitleFontSize;
                model.TextTheme = megaSlider.TextTheme;
                model.TextAlignment = megaSlider.TextAlignment;
                model.BackgroundType = megaSlider.BackgroundType;
                model.BlockStyle = megaSlider.BlockStyle;
                model.BackgroundVideoUrl = megaSlider.BackgroundVideoUrl;
                model.BackgroundVideoTypeId = megaSlider.BackgroundVideoTypeId;
                model.IsAutoPlay = megaSlider.IsAutoPlay;
                model.UseNaturalVideoSizeOnMobile = megaSlider.UseNaturalVideoSizeOnMobile;

                //Remove Code
                //model.Content = megaSlider.Content;
                //model.ContentLayer = megaSlider.ContentLayer;
                //model.TitleFontSize = megaSlider.TitleFontSize;
                //model.DescriptionFontSize = megaSlider.DescriptionFontSize;
                //model.Texttransitions = megaSlider.Texttransitions;
                //model.TransitionEffectDelay = megaSlider.TransitionEffectDelay;
                //model.ContentLayer3 = megaSlider.ContentLayer3;
                //model.AllowRepeatAnimation = megaSlider.AllowRepeatAnimation; 


            }

            //Remove code
            //model.ContentLayerPositions = model.ContentLayerPositions == 0 ? 4 : model.ContentLayerPositions;
            //model.ContentLayerPositionsSecond = model.ContentLayerPositionsSecond == 0 ? 1 : model.ContentLayerPositionsSecond;
            //model.ContentLayerPositionsThird = model.ContentLayerPositionsThird == 0 ? 3 : model.ContentLayerPositionsThird;

            foreach (SliderCTAButtonStyleEnum style in Enum.GetValues(typeof(SliderCTAButtonStyleEnum)))
            {
                model.AvailableCTAButtonStyles.Add(new SelectListItem
                {
                    Text = await _localizationService.GetLocalizedEnumAsync(style),
                    Value = ((int)style).ToString(),
                    Selected = ((int)style == model.CTAButton1StyleId ||
                                (int)style == model.CTAButton2StyleId)
                });
            }

            foreach (Positioning templateType in Enum.GetValues(typeof(Positioning)))
            {
                model.Availablepositioning ??= new List<SelectListItem>();

                model.Availablepositioning.Add(new SelectListItem
                {
                    Text = await _localizationService.GetLocalizedEnumAsync(templateType),
                    Value = ((int)templateType).ToString(),
                    Selected = (int)templateType == model.Positioning
                });
            }

            //Remove Code 
            //foreach (ContentLayerPositions templateType in Enum.GetValues(typeof(ContentLayerPositions)))
            //{
            //    model.AvailableContentLayerPositions ??= new List<SelectListItem>();

            //    model.AvailableContentLayerPositions.Add(new SelectListItem
            //    {
            //        Text = await _localizationService.GetLocalizedEnumAsync(templateType),
            //        Value = ((int)templateType).ToString(),
            //        Selected = (int)templateType == model.ContentLayerPositions
            //    });

            //    model.AvailableContentLayerPositionsSecond ??= new List<SelectListItem>();

            //    model.AvailableContentLayerPositionsSecond.Add(new SelectListItem
            //    {
            //        Text = await _localizationService.GetLocalizedEnumAsync(templateType),
            //        Value = ((int)templateType).ToString(),
            //        Selected = (int)templateType == model.ContentLayerPositionsSecond
            //    });

            //    model.AvailableContentLayerPositionsThird ??= new List<SelectListItem>();

            //    model.AvailableContentLayerPositionsThird.Add(new SelectListItem
            //    {
            //        Text = await _localizationService.GetLocalizedEnumAsync(templateType),
            //        Value = ((int)templateType).ToString(),
            //        Selected = (int)templateType == model.ContentLayerPositionsThird
            //    });

            //}

            // TextBlockPosition enum dropdown
            model.AvailableTextBlockPosition = new List<SelectListItem>();

            foreach (TextBlockPositionenum item in Enum.GetValues(typeof(TextBlockPositionenum)))
            {
                model.AvailableTextBlockPosition.Add(new SelectListItem
                {
                    Text = await _localizationService.GetLocalizedEnumAsync(item),
                    Value = ((int)item).ToString(),
                    Selected = (int)item == model.TextBlockPosition
                });
            }

            // ContentSpacing enum dropdown
            model.AvailableContentSpacing = new List<SelectListItem>();

            foreach (ContentSpacingenum item in Enum.GetValues(typeof(ContentSpacingenum)))
            {
                model.AvailableContentSpacing.Add(new SelectListItem
                {
                    Text = await _localizationService.GetLocalizedEnumAsync(item),
                    Value = ((int)item).ToString(),
                    Selected = (int)item == model.ContentSpacing
                });
            }

            model.AvailableBackgroundSizes = new List<SelectListItem>();
            foreach (BackgroundSizeEnum item in Enum.GetValues(typeof(BackgroundSizeEnum)))
            {
                model.AvailableBackgroundSizes.Add(new SelectListItem
                {
                    Text = await _localizationService.GetLocalizedEnumAsync(item),
                    Value = ((int)item).ToString(),
                    Selected = (int)item == model.BackgroundSize
                });
            }

            // Background Overlay enum
            model.AvailableBackgroundOverlays = new List<SelectListItem>();
            foreach (OverlayType item in Enum.GetValues(typeof(OverlayType)))
            {
                model.AvailableBackgroundOverlays.Add(new SelectListItem
                {
                    Text = await _localizationService.GetLocalizedEnumAsync(item),
                    Value = ((int)item).ToString(),
                    Selected = (int)item == model.BackgroundOverlay
                });
            }

            // Title Font Sizes
            model.AvailableTitleFontSizes = new List<SelectListItem>();
            foreach (TitleFontSizeEnum titleFontSize in Enum.GetValues(typeof(TitleFontSizeEnum)))
            {
                model.AvailableTitleFontSizes.Add(new SelectListItem
                {
                    Text = await _localizationService.GetLocalizedEnumAsync(titleFontSize),
                    Value = ((int)titleFontSize).ToString(),
                    Selected = (int)titleFontSize == model.TitleFontSize
                });
            }


            //Zone Type enum dropdown
            model.AvilableOverlayType = new List<SelectListItem>();

            foreach (OverlayType overlay in Enum.GetValues(typeof(OverlayType)))
            {
                model.AvilableOverlayType.Add(new SelectListItem
                {
                    Text = await _localizationService.GetLocalizedEnumAsync(overlay),
                    Value = ((int)overlay).ToString(),
                    Selected = ((int)overlay == model.LeftOverlay ||
                                (int)overlay == model.RightOverlay)
                });
            }

            model.AvilableColorPresetType = new List<SelectListItem>();

            foreach (ColorPresetType colorPreset in Enum.GetValues(typeof(ColorPresetType)))
            {
                model.AvilableColorPresetType.Add(new SelectListItem
                {
                    Text = await _localizationService.GetLocalizedEnumAsync(colorPreset),
                    Value = ((int)colorPreset).ToString(),
                    Selected = ((int)colorPreset == model.LeftColorpreset ||
                                (int)colorPreset == model.RightColorpreset)
                });
            }

            // Layout 
            model.AvilableCardTheme = new List<SelectListItem>();
            foreach (CardTheme cardTheme in Enum.GetValues(typeof(CardTheme)))
            {
                model.AvilableCardTheme.Add(new SelectListItem
                {
                    Text = await _localizationService.GetLocalizedEnumAsync(cardTheme),
                    Value = ((int)cardTheme).ToString(),
                    Selected = ((int)cardTheme == model.Cardtheme)
                });
            }
            model.AvilableTextAlignment = new List<SelectListItem>();
            foreach (TextAlignmentEnum textAlignment in Enum.GetValues(typeof(TextAlignmentEnum)))
            {
                model.AvilableTextAlignment.Add(new SelectListItem
                {
                    Text = await _localizationService.GetLocalizedEnumAsync(textAlignment),
                    Value = ((int)textAlignment).ToString(),
                    Selected = ((int)textAlignment == model.TextAlignment)
                });
            }
            model.AvailableBackgroundVideoTypes = new List<SelectListItem>();
            foreach (BackgroundVideoType backgroundVideo in Enum.GetValues(typeof(BackgroundVideoType)))
            {
                model.AvailableBackgroundVideoTypes.Add(new SelectListItem
                {
                    Text = await _localizationService.GetLocalizedEnumAsync(backgroundVideo),
                    Value = ((int)backgroundVideo).ToString(),
                    Selected = ((int)backgroundVideo == model.BackgroundVideoTypeId)
                });
            }

            var widgetZones = await _megaService.GetAllWidgetZone();

            model.Availablewidgetzone = widgetZones.Select(widget => new SelectListItem
            {
                Text = widget,
                Value = widget,
                Selected = widget.Equals(model.WidgetZone, StringComparison.InvariantCultureIgnoreCase)
            }).ToList();

            model.Availablewidgetzone.Insert(0, new SelectListItem
            {
                Value = "",
                Text = await _localizationService.GetResourceAsync(
                    "Nop.Plugin.nop4all.gallerypro.Configuration.Fields.SelectWidgetZone"),
                Selected = string.IsNullOrEmpty(model.WidgetZone)
            });

            var effects = await _megaService.GetAllEffect();

            model.AvailableEffects = effects.Select(effect => new SelectListItem
            {
                Text = effect,
                Value = effect,
                Selected = effect.Equals(model.NewProductseffect, StringComparison.InvariantCultureIgnoreCase)
            }).ToList();

            model.AvailableEffects.Insert(0, new SelectListItem
            {
                Value = "",
                Text = await _localizationService.GetResourceAsync(
                    "Nop.Plugin.nop4all.megaslider.Fields.SelectEffect")
            });

            await _storeMappingSupportedModelFactory.PrepareModelStoresAsync(
                model,
                megaSlider,
                excludeProperties
            );

            return model;
        }

        /// <summary>
        /// Prepares the featured product list model for a specific slider.
        /// </summary>
        /// <param name="searchModel">The featured product search model.</param>
        /// <param name="mega_Slider">The Mega Slider entity.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the featured product list model.</returns>
        public virtual async Task<FeatureProductListModel> PrepareCategoryProductListModelAsync(FeatureProductSearchModel searchModel, MegaSlider mega_Slider)
        {
            if (searchModel == null)
                throw new ArgumentNullException(nameof(searchModel));

            if (mega_Slider == null)
                throw new ArgumentNullException(nameof(mega_Slider));

            //get product categories
            var productCategories = await _megaService.GetProductCategoriesBySliderIdAsync(mega_Slider.Id,

                pageIndex: searchModel.Page - 1, pageSize: searchModel.PageSize);

            //prepare grid model
            var model = await new FeatureProductListModel().PrepareToGridAsync(searchModel, productCategories, () =>
            {
                return productCategories.SelectAwait(async productCategory =>
                {
                    //fill in model values from the entity
                    var categoryProductModel = new FeatureProductModel();
                    var urlHelper = _urlHelperFactory.GetUrlHelper(_actionContextAccessor.ActionContext);
                    categoryProductModel.Id = productCategory.Id;
                    categoryProductModel.SliderId = productCategory.SliderId;

                    //fill in additional values (not existing in the entity)
                    categoryProductModel.ProductName = (await _productService.GetProductByIdAsync(productCategory.ProductId))?.Name;
                    categoryProductModel.DisplayOrder = productCategory.DisplayOrder;
                    categoryProductModel.ProductId = productCategory.ProductId;

                    categoryProductModel.PictureId = productCategory.PictureId;
                    categoryProductModel.PictureUrl = await _pictureService.GetPictureUrlAsync(categoryProductModel.PictureId,75,true);

                    categoryProductModel.EditUrl = urlHelper.Action(
                        "FeatureProductEditPopup",
                        "Megaslider",
                        new
                        {
                            id = productCategory.Id,
                            btnId = "btnRefreshProducts",
                            formId = "category-form"
                        }
                    );
                    return categoryProductModel;
                });
            });

            return model;
        }

        /// <summary>
        /// Prepares the search model used to add products to the featured product list.
        /// </summary>
        /// <param name="searchModel">The add product to feature search model.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the prepared search model.</returns>
        public virtual async Task<AddProductToFeatureSearchModel> PrepareAddProductToFeatureSearchModelAsync(AddProductToFeatureSearchModel searchModel)
        {
            if (searchModel == null)
                throw new ArgumentNullException(nameof(searchModel));

            //prepare available categories
            await _baseAdminModelFactory.PrepareCategoriesAsync(searchModel.AvailableCategories);

            //prepare available manufacturers
            await _baseAdminModelFactory.PrepareManufacturersAsync(searchModel.AvailableManufacturers);

            //prepare available stores
            await _baseAdminModelFactory.PrepareStoresAsync(searchModel.AvailableStores);

            //prepare available vendors
            await _baseAdminModelFactory.PrepareVendorsAsync(searchModel.AvailableVendors);

            //prepare available product types
            await _baseAdminModelFactory.PrepareProductTypesAsync(searchModel.AvailableProductTypes);

            //prepare page parameters
            searchModel.SetPopupGridPageSize();

            return searchModel;
        }

        /// <summary>
        /// Prepares the model for displaying a list of products that can be added as featured products to the slider.
        /// </summary>
        /// <param name="searchModel">The add product to feature search model.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the add feature product to slider list model.</returns>
        public virtual async Task<AddFeatureProductToSliderListModel> PrepareAddFeatureProductToSliderListModelAsync(AddProductToFeatureSearchModel searchModel)
        {
            if (searchModel == null)
                throw new ArgumentNullException(nameof(searchModel));

            //get products
            var products = await _productService.SearchProductsAsync(showHidden: true,
                categoryIds: new List<int> { searchModel.SearchCategoryId },
                manufacturerIds: new List<int> { searchModel.SearchManufacturerId },
                storeId: searchModel.SearchStoreId,
                vendorId: searchModel.SearchVendorId,
                productType: searchModel.SearchProductTypeId > 0 ? (ProductType?)searchModel.SearchProductTypeId : null,
                keywords: searchModel.SearchProductName,
                pageIndex: searchModel.Page - 1, pageSize: searchModel.PageSize);

            //prepare grid model
            var model = await new AddFeatureProductToSliderListModel().PrepareToGridAsync(searchModel, products, () =>
            {
                return products.SelectAwait(async product =>
                {
                    var productModel = new AddFeatureProductToSliderModel();

                    productModel.Id = product.Id;
                    productModel.ProductName = product.Name;
                    productModel.Publish = product.Published;

                    return productModel;
                });
            });

            return model;
        }

        /// <summary>
        /// Prepares the new product list model for a specific slider.
        /// </summary>
        /// <param name="searchModel">The new product search model.</param>
        /// <param name="mega_Slider">The Mega Slider entity.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the new product list model.</returns>
        public virtual async Task<NewProductListModel> PrepareNewProductListModelAsync(NewProductSearchModel searchModel, MegaSlider mega_Slider)
        {
            if (searchModel == null)
                throw new ArgumentNullException(nameof(searchModel));

            if (mega_Slider == null)
                throw new ArgumentNullException(nameof(mega_Slider));

            //get product categories
            var productCategories = await _megaService.GetNewProductBySliderIdAsync(mega_Slider.Id,

                pageIndex: searchModel.Page - 1, pageSize: searchModel.PageSize);

            //prepare grid model
            var model = await new NewProductListModel().PrepareToGridAsync(searchModel, productCategories, () =>
            {
                return productCategories.SelectAwait(async productCategory =>
                {
                    //fill in model values from the entity
                    var categoryProductModel = new NewProductModel();
                    var urlHelper = _urlHelperFactory.GetUrlHelper(_actionContextAccessor.ActionContext);

                    categoryProductModel.Id = productCategory.Id;
                    categoryProductModel.SliderId = productCategory.SliderId;

                    //fill in additional values (not existing in the entity)
                    categoryProductModel.ProductName = (await _productService.GetProductByIdAsync(productCategory.ProductId))?.Name;
                    categoryProductModel.DisplayOrder = productCategory.DisplayOrder;
                    categoryProductModel.ProductId = productCategory.ProductId;
                    categoryProductModel.PictureId = productCategory.PictureId;
                    categoryProductModel.PictureUrl = await _pictureService.GetPictureUrlAsync(
                        categoryProductModel.PictureId,
                        75,
                        true
                    );

                    categoryProductModel.EditUrl = urlHelper.Action(
                        "NewProductEditPopup",
                        "Megaslider",
                        new
                        {
                            id = productCategory.Id,
                            btnId = "btnRefreshProducts",
                            formId = "category-form"
                        }
                    );

                    return categoryProductModel;
                });
            });
            return model;
        }

        /// <summary>
        /// Prepares the search model used to add new products to the slider.
        /// </summary>
        /// <param name="searchModel">The add product to new search model.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the prepared search model.</returns>
        public virtual async Task<AddProductToNewSearchModel> PrepareAddProductToNewSearchModelAsync(AddProductToNewSearchModel searchModel)
        {
            if (searchModel == null)
                throw new ArgumentNullException(nameof(searchModel));

            //prepare available categories
            await _baseAdminModelFactory.PrepareCategoriesAsync(searchModel.AvailableCategories);

            //prepare available manufacturers
            await _baseAdminModelFactory.PrepareManufacturersAsync(searchModel.AvailableManufacturers);

            //prepare available stores
            await _baseAdminModelFactory.PrepareStoresAsync(searchModel.AvailableStores);

            //prepare available vendors
            await _baseAdminModelFactory.PrepareVendorsAsync(searchModel.AvailableVendors);

            //prepare available product types
            await _baseAdminModelFactory.PrepareProductTypesAsync(searchModel.AvailableProductTypes);

            //prepare page parameters
            searchModel.SetPopupGridPageSize();

            return searchModel;
        }

        /// <summary>
        /// Prepares the model for displaying a list of products that can be added as new products to the slider.
        /// </summary>
        /// <param name="searchModel">The add product to new search model.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the add new product to slider list model.</returns>
        public virtual async Task<AddNewProductToSliderListModel> PrepareAddNewProductToSliderListModelAsync(AddProductToNewSearchModel searchModel)
        {
            if (searchModel == null)
                throw new ArgumentNullException(nameof(searchModel));

            //get products
            var products = await _productService.SearchProductsAsync(showHidden: true,
                categoryIds: new List<int> { searchModel.SearchCategoryId },
                manufacturerIds: new List<int> { searchModel.SearchManufacturerId },
                storeId: searchModel.SearchStoreId,
                vendorId: searchModel.SearchVendorId,
                productType: searchModel.SearchProductTypeId > 0 ? (ProductType?)searchModel.SearchProductTypeId : null,
                keywords: searchModel.SearchProductName,
                pageIndex: searchModel.Page - 1, pageSize: searchModel.PageSize);

            //prepare grid model
            var model = await new AddNewProductToSliderListModel().PrepareToGridAsync(searchModel, products, () =>
            {
                return products.SelectAwait(async product =>
                {
                    var productModel = new AddNewProductToSliderModel();

                    productModel.Id = product.Id;
                    productModel.ProductName = product.Name;
                    productModel.Publish = product.Published;

                    return productModel;
                });
            });
            return model;
        }

        /// <summary>
        /// Prepares the sell product list model for a specific slider.
        /// </summary>
        /// <param name="searchModel">The sell product search model.</param>
        /// <param name="mega_Slider">The Mega Slider entity.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the new product list model.</returns>
        public virtual async Task<SellProductListModel> PrepareSellProductListModelAsync(SellProductSearchModel searchModel, MegaSlider mega_Slider)
        {
            if (searchModel == null)
                throw new ArgumentNullException(nameof(searchModel));

            if (mega_Slider == null)
                throw new ArgumentNullException(nameof(mega_Slider));

            //get product categories
            var productCategories = await _megaService.GetSellProductBySliderIdAsync(mega_Slider.Id,

                pageIndex: searchModel.Page - 1, pageSize: searchModel.PageSize);

            //prepare grid model
            var model = await new SellProductListModel().PrepareToGridAsync(searchModel, productCategories, () =>
            {
                return productCategories.SelectAwait(async productCategory =>
                {
                    var categoryProductModel = new SellProductModel();
                    var urlHelper = _urlHelperFactory.GetUrlHelper(_actionContextAccessor.ActionContext);
                    categoryProductModel.Id = productCategory.Id;
                    categoryProductModel.SliderId = productCategory.SliderId;
                    categoryProductModel.ProductName = (await _productService.GetProductByIdAsync(productCategory.ProductId))?.Name;
                    categoryProductModel.DisplayOrder = productCategory.DisplayOrder;
                    categoryProductModel.ProductId = productCategory.ProductId;
                    categoryProductModel.PictureId = productCategory.PictureId;
                    categoryProductModel.PictureUrl = await _pictureService.GetPictureUrlAsync(
                        categoryProductModel.PictureId,
                        75,
                        true
                    );
                    categoryProductModel.EditUrl = urlHelper.Action(
                        "SellProductEditPopup",
                        "Megaslider",
                        new
                        {
                            id = productCategory.Id,
                            btnId = "btnRefreshProducts",
                            formId = "category-form"
                        }
                    );
                    return categoryProductModel;
                });
            });
            return model;
        }

        /// <summary>
        /// Prepares the search model used to add sell products to the slider.
        /// </summary>
        /// <param name="searchModel">The add product to sell search model.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the prepared search model.</returns>
        public virtual async Task<AddProductToSellSearchModel> PrepareAddProductToSellSearchModelAsync(AddProductToSellSearchModel searchModel)
        {
            if (searchModel == null)
                throw new ArgumentNullException(nameof(searchModel));

            //prepare available categories
            await _baseAdminModelFactory.PrepareCategoriesAsync(searchModel.AvailableCategories);

            //prepare available manufacturers
            await _baseAdminModelFactory.PrepareManufacturersAsync(searchModel.AvailableManufacturers);

            //prepare available stores
            await _baseAdminModelFactory.PrepareStoresAsync(searchModel.AvailableStores);

            //prepare available vendors
            await _baseAdminModelFactory.PrepareVendorsAsync(searchModel.AvailableVendors);

            //prepare available product types
            await _baseAdminModelFactory.PrepareProductTypesAsync(searchModel.AvailableProductTypes);

            //prepare page parameters
            searchModel.SetPopupGridPageSize();

            return searchModel;
        }

        /// <summary>
        /// Prepares the model for displaying a list of products that can be added as sell products to the slider.
        /// </summary>
        /// <param name="searchModel">The add product to sell search model.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the add new product to slider list model.</returns>
        public virtual async Task<AddSellProductToSliderListModel> PrepareAddSellProductToSliderListModelAsync(AddProductToSellSearchModel searchModel)
        {
            if (searchModel == null)
                throw new ArgumentNullException(nameof(searchModel));

            //get products
            var products = await _productService.SearchProductsAsync(showHidden: true,
                categoryIds: new List<int> { searchModel.SearchCategoryId },
                manufacturerIds: new List<int> { searchModel.SearchManufacturerId },
                storeId: searchModel.SearchStoreId,
                vendorId: searchModel.SearchVendorId,
                productType: searchModel.SearchProductTypeId > 0 ? (ProductType?)searchModel.SearchProductTypeId : null,
                keywords: searchModel.SearchProductName,
                pageIndex: searchModel.Page - 1, pageSize: searchModel.PageSize);

            //prepare grid model
            var model = await new AddSellProductToSliderListModel().PrepareToGridAsync(searchModel, products, () =>
            {
                return products.SelectAwait(async product =>
                {
                    var productModel = new AddSellProductToSliderModel();
                    productModel.Id = product.Id;
                    productModel.ProductName = product.Name;
                    productModel.Publish = product.Published;

                    return productModel;
                });
            });
            return model;
        }

        /// <summary>
        /// Prepares the language resource search model for Mega Slider.
        /// </summary>
        /// <param name="searchModel">The language resource search model.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the prepared language resource search model.</returns>
        public virtual async Task<MSLanguageResourceSearchModel> PrepareMSLanguageResourceSearchModelAsync(MSLanguageResourceSearchModel searchModel)
        {
            if (searchModel == null)
                throw new ArgumentNullException(nameof(searchModel));

            var language = await _languageService.GetAllLanguagesAsync();

            searchModel.AvailableLanguages = await language.SelectAwait(async lang => new SelectListItem
            {
                Text = lang.UniqueSeoCode,
                Value = lang.Id.ToString(),
            }).ToListAsync();
            //prepare page parameters
            searchModel.SetGridPageSize();

            return (searchModel);
        }

        /// <summary>
        /// Prepares the language resource list model for Mega Slider.
        /// </summary>
        /// <param name="searchModel">The language resource search model.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the prepared language resource list model.</returns>
        public virtual async Task<MSLanguageResourceListModel> PrepareMSLanguageResourceListModelAsync(MSLanguageResourceSearchModel searchModel)
        {
            if (searchModel == null)
                throw new ArgumentNullException(nameof(searchModel));

            //get languages
            var languages = (await _megasliderServices
                .GetLocaleStringResourcesByLocaleStringResourcePrefixAsync(MegasliderDefaults.LocaleStringResourcePrefix, searchModel.SelectedLanguage))
                .ToPagedList(searchModel);

            //prepare list model
            var model = await new MSLanguageResourceListModel().PrepareToGridAsync(searchModel, languages, () =>
            {
                //fill in model values from the configuration
                return languages.SelectAwait(async language =>
                {
                    var mSLanguageResourceModel = new MSLanguageResourceModel
                    {
                        Id = language.Id,
                        ResourceName = language.ResourceName,
                        Value = language.ResourceValue
                    };

                    return mSLanguageResourceModel;
                });
            });
            return model;
        }

        /// <summary>
        /// Prepares the Group Slider model for Mega Slider.
        /// </summary>
        /// <param name="model">The GroupSlider model.</param>
        /// <param name="groupmegaslider">The groupegaslider Domain.</param>
        /// <param name="excludeProperties">The exclude Properties.</param>
        /// <returns>A task that represents the asynchronous operation. 
        /// The task result contains the prepared Group Slider model.
        /// </returns>
        public async Task<GroupSliderModel> PrepareGroupSliderModelAsync(GroupSliderModel model, GroupMegaSlider groupmegaslider, bool excludeProperties = false)
        {
            model ??= new GroupSliderModel();

            if (groupmegaslider != null && !excludeProperties)
            {
                model.Id = groupmegaslider.Id;
                model.GroupId = groupmegaslider.Id;
                model.Name = groupmegaslider.Name;
                model.Enable = groupmegaslider.Enable;
                model.DisplayOrder = groupmegaslider.DisplayOrder;
                model.Widgetzone = groupmegaslider.Widgetzone;
                model.Show = groupmegaslider.Show;
                model.Hide = groupmegaslider.Hide;
                model.LeftSide = groupmegaslider.LeftSide;
                model.RightSide = groupmegaslider.RightSide;
                model.DotArrrow = groupmegaslider.DotArrrow;
                model.Menu = groupmegaslider.Menu;
                model.AnimationEffectId = groupmegaslider.AnimationEffectId;
                model.TransitionAnimationEffectId = groupmegaslider.TransitionAnimationEffectId;
                model.GroupSliderHeight = (groupmegaslider.GroupSliderHeight > 0 ? groupmegaslider.GroupSliderHeight :750);
            }

            // REQUIRED: Condition Search Model
            model.ConditionSearchModel ??= new ConditionSearchModel
            {
                GroupId = model.GroupId,
                AvailablePageSizes = "10,20,50"
            };

            // Widget zones dropdown
            var widgetZones = await _megaService.GetAllWidgetZone();

            model.Availablewidgetzone = widgetZones.Select(widget => new SelectListItem
            {
                Text = widget,
                Value = widget,
                Selected = widget.Equals(model.Widgetzone, StringComparison.InvariantCultureIgnoreCase)
            }).ToList();

            model.Availablewidgetzone.Insert(0, new SelectListItem
            {
                Value = "",
                Text = await _localizationService.GetResourceAsync(
                   "Nop.Plugin.nop4all.gallerypro.Configuration.Fields.SelectWidgetZone"),
                Selected = string.IsNullOrEmpty(model.Widgetzone)
            });

            model.AvailableAnimationEffects = Enum.GetValues(typeof(SliderAnimationEffect))
            .Cast<SliderAnimationEffect>()
            .Select(x => new SelectListItem
            {
                Value = ((int)x).ToString(),
                Text = x.ToString(),
                Selected = model.AnimationEffectId == (int)x
            })
            .ToList();
            //Transition Animation Effect
            model.AvailableTransitionAnimationEffect = Enum.GetValues(typeof(GroupTransitionEffect))
            .Cast<GroupTransitionEffect>()
            .Select(x => new SelectListItem
            {
                Value = ((int)x).ToString(),
                Text = x.ToString(),
                Selected = model.TransitionAnimationEffectId == (int)x
            })
            .ToList();

            await _storeMappingSupportedModelFactory
                .PrepareModelStoresAsync(model, groupmegaslider, excludeProperties);

            return model;
        }

        /// <summary>
        /// Prepares the Group Slider List model for Mega Slider.
        /// </summary>
        /// <param name="model">The GroupSliderList model.</param>
        /// <returns>
        /// A task that represents the asynchronous operation. 
        /// The task result contains the prepared Group Slider List model.
        /// </returns>
        public async Task<GroupSliderListModel> PrepareGroupSliderListModelAsync(GroupSliderSearchModel model)
        {
            var groupsliders = (await _megaService.GetAllGroupSliderAsync()).ToPagedList(model);

            var gridModel = await new GroupSliderListModel().PrepareToGridAsync(model, groupsliders, () =>
            {
                return groupsliders.SelectAwait(async x =>
                {
                    var model = new GroupSliderModel();

                    model.Id = x.Id;
                    model.Name = x.Name;
                    model.Enable = x.Enable;
                    model.DisplayOrder = x.DisplayOrder;

                    return model;
                });
            });
            model.SetGridPageSize();
            return gridModel;
        }
        #endregion
    }
}
