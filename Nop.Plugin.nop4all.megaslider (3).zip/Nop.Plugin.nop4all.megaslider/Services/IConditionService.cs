﻿using Nop.Core;
using Nop.Plugin.nop4all.megaslider.Domain; 

namespace Nop.Plugin.nop4all.megaslider.Services
{
    /// <summary>
    /// Condition service interface
    /// </summary>
    public interface IConditionService
    {
        ///<summary>
        /// Get Menu Condition By GroupId.
        /// </summary>
        /// <param name="GroupId">The ID of the menu to retrieve conditions for.</param>
        /// <param name="pageIndex">The index of the page to retrieve. Default is 0.</param>
        /// <param name="pageSize">The size of each page. Default is int.MaxValue.</param>
        /// <returns>A task representing the asynchronous operation, returning a paged list of menu conditions.</returns>
        Task<IPagedList<MegaSliderGroupCondition>> GetMenuConditionByMenuIdAsync(int groupId, int pageIndex = 0, int pageSize = int.MaxValue);

        /// <summary>
        /// Get Menu Condition By Id.
        /// </summary>
        /// <param name="Id">The unique ID of the menu condition to retrieve.</param>
        /// <returns>A task representing the asynchronous operation, returning the menu condition.</returns>
        Task<MegaSliderGroupCondition> GetMenuConditionByIdAsync(int id);

        /// <summary>
        /// Insert Condition. 
        /// </summary>
        /// <param name="condition">The menu condition to insert.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        Task InsertConditionAsync(MegaSliderGroupCondition condition);

        /// <summary>
        /// Update Condition.
        /// </summary>
        /// <param name="condition">The menu condition to update.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        Task UpdateConditionAsync(MegaSliderGroupCondition condition);

        /// <summary>
        /// Delete Condition.
        /// </summary>
        /// <param name="condition">The menu condition to delete.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        Task DeleteConditionAsync(MegaSliderGroupCondition condition); 

        /// <summary>
        /// Is Widget Zone Has Condition
        /// </summary>
        /// <param name="widgetZone">Widget zone name</param>
        /// <returns>A Task representing the asynchronous operation.</returns>
        Task<bool> IsWidgetZoneHasConditionAsync(string widgetZone);

        /// <summary>
        /// Get by Al lConditions
        /// </summary>
        /// <returns>A Task representing the asynchronous operation.</returns>
        Task<IList<MegaSliderGroupCondition>> GetAllConditionsAsync();

    }
}
