﻿using Nop.Core;
using Nop.Core.Domain.Localization;
using Nop.Plugin.nop4all.megaslider.Domain;

namespace Nop.Plugin.nop4all.megaslider.Services
{
    /// <summary>
    /// Represents a service for managing Mega Sliders and their associated products.
    /// </summary>
    public partial interface IMegasliderServices
    {
        /// <summary>
        /// Gets all available widget zones.
        /// </summary>
        /// <returns>A list of widget zone names.</returns>
        Task<IList<string>> GetAllWidgetZone();

        /// <summary>
        /// Get All Effect
        /// </summary>
        /// <returns>A list of Effects</returns>
        Task<IList<string>> GetAllEffect();

        /// <summary>
        /// Gets all new product positions from XML file
        /// </summary>
        /// <returns>A list of position strings</returns>
        Task<IList<string>> GetAllNewProductPositionsAsync();

        /// <summary>
        /// Gets all sliders by group id.
        /// </summary>
        /// <param name="groupId">Group slider identifier.</param>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="pageSize">Page size.</param>
        /// <returns>Paged list of sliders.</returns>
        Task<IPagedList<MegaSlider>> GetAllSliderByGroupIdAsync(
            int groupId,
            int pageIndex,
            int pageSize);

        /// <summary>
        /// Gets all sliders.
        /// </summary>
        /// <param name="groupSliderId">Group slider identifier.</param>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="pageSize">Page size.</param>
        /// <returns>Paged list of sliders.</returns>
        Task<IPagedList<MegaSlider>> GetAllSliderAsync(
       int groupSliderId,
       int pageIndex = 0,
       int pageSize = int.MaxValue);

        /// <summary>
        /// Inserts a new slider.
        /// </summary>
        /// <param name="mega_Slider">Slider entity.</param>
        Task InsertSliderAsync(MegaSlider mega_Slider);

        /// <summary>
        /// Updates an existing slider.
        /// </summary>
        /// <param name="mega_Slider">Slider entity.</param>
        Task UpdateSliderAsync(MegaSlider mega_Slider);

        /// <summary>
        /// Update mega slider
        /// </summary>
        /// <param name="MegaSlider"></param>
        /// <returns>Update mega slider</returns>
        Task UpdateMegaSliderAsync(MegaSlider slider);

        /// <summary>
        /// Deletes a slider.
        /// </summary>
        /// <param name="mega_Slider">Slider entity.</param>
        Task DeleteSliderAsync(MegaSlider mega_Slider);

        /// <summary>
        /// Gets a slider by its identifier.
        /// </summary>
        /// <param name="sliderId">Slider identifier.</param>
        /// <returns>The slider entity.</returns>
        Task<MegaSlider> GetSliderByIdAsync(int sliderId);

        /// <summary>
        /// Gets featured products associated with a specific slider.
        /// </summary>
        /// <param name="sliderid">Slider identifier.</param>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="pageSize">Page size.</param>
        /// <returns>Paged list of featured products.</returns>
        Task<IPagedList<MegaSliderFeaturedProducts>> GetProductCategoriesBySliderIdAsync(int sliderid, int pageIndex = 0, int pageSize = int.MaxValue);

        /// <summary>
        /// Gets featured products by slider.
        /// </summary>
        /// <param name="sliderid">Slider identifier.</param>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="pageSize">Page size.</param>
        /// <param name="showHidden">A value indicating whether to show hidden products.</param>
        /// <returns>Paged list of featured products.</returns>
        Task<IPagedList<MegaSliderFeaturedProducts>> GetFeatureProductBySliderAsync(int sliderid, int pageIndex = 0, int pageSize = int.MaxValue, bool showHidden = false);

        /// <summary>
        /// Finds a featured product in the given list.
        /// </summary>
        /// <param name="source">List of featured products.</param>
        /// <param name="productId">Product identifier.</param>
        /// <param name="sliderid">Slider identifier.</param>
        /// <returns>Featured product mapping if found.</returns>
        MegaSliderFeaturedProducts FindFeatureProduct(IList<MegaSliderFeaturedProducts> source, int productId, int sliderid);

        /// <summary>
        /// Inserts a featured product into a slider.
        /// </summary>
        /// <param name="megaSliderFeaturedProducts">Featured product mapping entity.</param>
        Task InsertMegaSliderFeatureProductAsync(MegaSliderFeaturedProducts megaSliderFeaturedProducts);

        /// <summary>
        /// Updates a featured product in a slider.
        /// </summary>
        /// <param name="megaSliderFeaturedProducts">Featured product mapping entity.</param>
        Task UpdateMegaSliderFeatureProductAsync(MegaSliderFeaturedProducts megaSliderFeaturedProducts);

        /// <summary>
        /// Deletes a featured product from a slider.
        /// </summary>
        /// <param name="megaSliderFeaturedProducts">Featured product mapping entity.</param>
        Task DeleteMegaSliderFeatureProductAsync(MegaSliderFeaturedProducts megaSliderFeaturedProducts);

        /// <summary>
        /// Gets a featured product mapping by slider identifier.
        /// </summary>
        /// <param name="sliderId">Slider identifier.</param>
        /// <returns>Featured product mapping entity.</returns>
        Task<MegaSliderFeaturedProducts> GetFeatureproductSliderByIdAsync(int sliderId);

        /// <summary>
        /// Gets a new product mapping by slider identifier.
        /// </summary>
        /// <param name="sliderId">Slider identifier.</param>
        /// <returns>New product mapping entity.</returns>
        Task<MegaSliderNewProducts> GetNewproductSliderByIdAsync(int sliderId);

        /// <summary>
        /// Gets new products by slider identifier.
        /// </summary>
        /// <param name="sliderid">Slider identifier.</param>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="pageSize">Page size.</param>
        /// <returns>Paged list of new products.</returns>
        Task<IPagedList<MegaSliderNewProducts>> GetNewProductBySliderIdAsync(int sliderid, int pageIndex = 0, int pageSize = int.MaxValue);

        /// <summary>
        /// Inserts a new product into a slider.
        /// </summary>
        /// <param name="megaSliderNewProducts">New product mapping entity.</param>
        Task InserMegaSliderNewProductAsync(MegaSliderNewProducts megaSliderNewProducts);

        /// <summary>
        /// Updates a new product in a slider.
        /// </summary>
        /// <param name="megaSliderNewProducts">New product mapping entity.</param>
        Task UpdateMegaSliderNewProductAsync(MegaSliderNewProducts megaSliderNewProducts);

        /// <summary>
        /// Deletes a new product from a slider.
        /// </summary>
        /// <param name="megaSliderNewProducts">New product mapping entity.</param>
        Task DeleteMegaSliderNewProductAsync(MegaSliderNewProducts megaSliderNewProducts);

        /// <summary>
        /// Gets new products by slider.
        /// </summary>
        /// <param name="sliderid">Slider identifier.</param>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="pageSize">Page size.</param>
        /// <param name="showHidden">A value indicating whether to show hidden products.</param>
        /// <returns>Paged list of new products.</returns>
        Task<IPagedList<MegaSliderNewProducts>> GetNewProductBySliderAsync(int sliderid, int pageIndex = 0, int pageSize = int.MaxValue, bool showHidden = false);

        /// <summary>
        /// Finds a new product in the given list.
        /// </summary>
        /// <param name="source">List of new products.</param>
        /// <param name="productId">Product identifier.</param>
        /// <param name="sliderid">Slider identifier.</param>
        /// <returns>New product mapping if found.</returns>
        MegaSliderNewProducts FindNewProduct(IList<MegaSliderNewProducts> source, int productId, int sliderid);

        /// <summary>
        /// Gets all sliders.
        /// </summary>
        /// <param name="sliderid">slider Id</param>
        /// <param name="pageIndex">page Index</param>
        /// <param name="pageSize">page Size</param>
        /// <returns>List of sliders.</returns>
        Task<IPagedList<MegaSliderSellProducts>> GetSellProductBySliderIdAsync(int sliderid,
          int pageIndex = 0, int pageSize = int.MaxValue);

        /// <summary>
        /// Get by All Sliders
        /// </summary>
        /// <param name="widgetZone">widgetZone</param>
        /// <param name="enabled">enabled</param>
        /// <returns>
        /// A task that represents the asynchronous operation.
        /// </returns>
        Task<IList<MegaSlider>> GetAllSlidersAsync(string widgetZone = null, bool enabled = false);

        /// <summary>
        /// Gets all featured products by slider identifier.
        /// </summary>
        /// <param name="sliderid">Slider identifier.</param>
        /// <returns>List of featured product mappings.</returns>
        Task<IList<MegaSliderFeaturedProducts>> GetAllFeturechedProductBySliderIdAsync(int sliderid);

        /// <summary>
        /// Gets all new products by slider identifier.
        /// </summary>
        /// <param name="sliderid">Slider identifier.</param>
        /// <returns>List of new product mappings.</returns>
        Task<IList<MegaSliderNewProducts>> GetAllNewProductBySliderIdAsync(int sliderid);

        /// <summary>
        /// Gets locale string resources by resource prefix and language.
        /// </summary>
        /// <param name="localeStringResourcePrefix">The locale string resource prefix.</param>
        /// <param name="languageId">Language identifier.</param>
        /// <returns>List of locale string resources.</returns>
        Task<IList<LocaleStringResource>> GetLocaleStringResourcesByLocaleStringResourcePrefixAsync(string localeStringResourcePrefix, int languageId = 0);

        /// <summary>
        /// Gets all sliders.
        /// </summary>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="pageSize">Page size.</param>
        /// <param name="showHidden">A value indicating whether to show hidden records.</param>
        /// <returns>Paged list of sliders.</returns>
        Task<IPagedList<GroupMegaSlider>> GetAllGroupSliderAsync(int pageIndex = 0, int pageSize = int.MaxValue, bool showHidden = false);

        /// <summary>
        /// Inserts a new slider.
        /// </summary>
        /// <param name="mega_Slider">Slider entity.</param>
        Task InsertGroupSliderAsync(GroupMegaSlider groupslider);

        /// <summary>
        /// Updates an existing slider.
        /// </summary>
        /// <param name="mega_Slider">Slider entity.</param>
        Task UpdateGroupSliderAsync(GroupMegaSlider groupslider);

        /// <summary>
        /// Deletes a slider.
        /// </summary>
        /// <param name="mega_Slider">Slider entity.</param>
        Task DeleteGroupSliderAsync(GroupMegaSlider groupslider);

        /// <summary>
        /// Gets a slider by its identifier.
        /// </summary>
        /// <param name="sliderId">Slider identifier.</param>
        /// <returns>The slider entity.</returns>
        Task<GroupMegaSlider> GetSliderGroupByIdAsync(int groupsliderId);

        /// <summary>
        /// Gets a Group by slider by its identifier.
        /// </summary>
        /// <param name="sliderId">Slider identifier.</param>
        /// <returns>
        /// The slider entity.
        /// </returns>
        Task<SliderMapping> GetGroupBySliderIdAsync(int sliderId);

        /// <summary>
        /// Delete a Group Slider Mapping
        /// </summary>
        /// <param name="sliderId">Slider identifier.</param>
        /// <returns>
        /// A task that represents the asynchronous operation.
        /// </returns>
        Task DeleteGroupSliderMappingAsync(int sliderId);

        /// <summary>
        /// Insert Slider Mapping
        /// </summary>
        /// <param name="sliderId">Slider identifier.</param>
        /// <param name="groupSliderId">GroupSlider identifier.</param>
        /// <returns>
        /// A task that represents the asynchronous operation.
        /// </returns>
        Task InsertSliderMappingAsync(int sliderId, int groupSliderId);

        /// <summary>
        /// Get All Group Sliders
        /// </summary>
        /// <param name="widgetZone">widgetZone</param>
        /// <param name="enabled">enabled</param>
        /// <returns>
        /// A task that represents the asynchronous operation.
        /// </returns>
        Task<IList<GroupMegaSlider>> GetAllGroupSlidersAsync(string widgetZone = null, bool enabled = false);

        /// <summary>
        /// Get slider product by id
        /// </summary>
        /// <param name="id">Get by New Products Ids</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        Task<MegaSliderNewProducts> GetNewProductByIdAsync(int id);

        /// <summary>
        /// Update slider product
        /// </summary>
        /// <param name="entity">Entity</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        Task UpdateNewProductAsync(MegaSliderNewProducts entity);

        /// <summary>
        /// Gets a new product mapping by slider identifier.
        /// </summary>
        /// <param name="sliderId">Slider identifier.</param>
        /// <returns>New product mapping entity.</returns>
        Task<MegaSliderSellProducts> GetSellproductSliderByIdAsync(int sliderId);

        /// <summary>
        /// Updates a new product in a slider.
        /// </summary>
        /// <param name="megaSliderSellProducts">New product mapping entity.</param>
        Task UpdateMegaSliderSellProductAsync(MegaSliderSellProducts megaSliderSellProducts);

        /// <summary>
        /// Deletes a new product from a slider.
        /// </summary>
        /// <param name="megaSliderSellProducts">New product mapping entity.</param>
        Task DeleteMegaSliderSellProductAsync(MegaSliderSellProducts megaSliderSellProducts);

        /// <summary>
        /// Gets new products by slider.
        /// </summary>
        /// <param name="sliderid">Slider identifier.</param>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="pageSize">Page size.</param>
        /// <param name="showHidden">A value indicating whether to show hidden products.</param>
        /// <returns>Paged list of new products.</returns>
      Task<IPagedList<MegaSliderSellProducts>> GetSellProductBySliderAsync(int sliderid,
           int pageIndex = 0, int pageSize = int.MaxValue, bool showHidden = false);

        /// <summary>
        /// Finds a new product in the given list.
        /// </summary>
        /// <param name="source">List of new products.</param>
        /// <param name="productId">Product identifier.</param>
        /// <param name="sliderid">Slider identifier.</param>
        /// <returns>New product mapping if found.</returns>
        MegaSliderSellProducts FindSellProduct(IList<MegaSliderSellProducts> source, int productId, int sliderid);

        /// <summary>
        /// Inserts a new product into a slider.
        /// </summary>
        /// <param name="megaSliderNewProducts">New product mapping entity.</param>
        Task InserMegaSliderSellProductAsync(MegaSliderSellProducts megaSliderSellProducts);

        /// <summary>
        /// Get slider product by id
        /// </summary>
        Task<MegaSliderSellProducts> GetSellProductByIdAsync(int id);
        /// <summary>
        /// Update slider product
        /// </summary>
        Task UpdateSellProductAsync(MegaSliderSellProducts entity);

        /// <summary>
        /// Gets all Sell products by slider identifier.
        /// </summary>
        /// <param name="sliderid">Slider identifier.</param>
        /// <returns>List of Sell product mappings.</returns>
        Task<IList<MegaSliderSellProducts>> GetAllSellProductBySliderIdAsync(int sliderid);
    }
}