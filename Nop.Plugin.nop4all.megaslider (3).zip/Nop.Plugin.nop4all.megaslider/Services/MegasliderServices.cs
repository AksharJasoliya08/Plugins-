﻿using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Localization;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Plugin.nop4all.megaslider.Domain;
using Nop.Services.Customers;
using Nop.Services.Stores;
using System.Text;
using System.Xml;

namespace Nop.Plugin.nop4all.megaslider.Services
{
    /// <summary>
    /// Represents a service for managing Mega Sliders and their associated products.
    /// </summary>
    public class MegasliderServices : IMegasliderServices
    {
        #region Fields
        protected readonly IRepository<MegaSlider> _megasliderRepository;
        protected readonly IRepository<MegaSliderFeaturedProducts> _megasliderFetaureRepository;
        protected readonly IRepository<MegaSliderNewProducts> _megaslidernewproductrepository;
        protected readonly IRepository<Product> _productRepository;
        protected readonly INopFileProvider _fileProvider;
        protected readonly IRepository<LocaleStringResource> _localeStringResourceRepository;
        protected readonly IRepository<GroupMegaSlider> _groupMegaSliderRepository;
        protected readonly IWorkContext _workContext;
        protected readonly ICustomerService _customerService;
        protected readonly IStoreMappingService _storeMappingService;
        protected readonly IStoreContext _storeContext;
        protected readonly IRepository<SliderMapping> _sliderMappingRepository;
        protected readonly IRepository<MegaSliderSellProducts> _megasliderSellProductRepository;
        #endregion

        #region Ctor
        public MegasliderServices(INopFileProvider fileProvider,
            IRepository<MegaSlider> megasliderRepository,
            IRepository<MegaSliderFeaturedProducts> megasliderFetaureRepository,
            IRepository<Product> productRepository,
            IRepository<MegaSliderNewProducts> megaslidernewproductrepository,
            IRepository<LocaleStringResource> localeStringResourceRepository,
            IRepository<GroupMegaSlider> groupMegaSliderRepository,
            IWorkContext workContext,
            ICustomerService customerService,
            IStoreMappingService storeMappingService,
            IStoreContext storeContext,
            IRepository<SliderMapping> sliderMappingRepository,
            IRepository<MegaSliderSellProducts> megasliderSellProductRepository)
        {
            _fileProvider = fileProvider;
            _megasliderRepository = megasliderRepository;
            _megasliderFetaureRepository = megasliderFetaureRepository;
            _productRepository = productRepository;
            _megaslidernewproductrepository = megaslidernewproductrepository;
            _localeStringResourceRepository = localeStringResourceRepository;
            _groupMegaSliderRepository = groupMegaSliderRepository;
            _workContext = workContext;
            _customerService = customerService;
            _storeMappingService = storeMappingService;
            _storeContext = storeContext;
            _sliderMappingRepository = sliderMappingRepository;
            _megasliderSellProductRepository = megasliderSellProductRepository;
        }
        #endregion

        #region Methods

        /// <summary>
        /// Gets all available widget zones.
        /// </summary>
        /// <returns>A list of widget zone names.</returns>
        public virtual async Task<IList<string>> GetAllWidgetZone()
        {
            var widgetZones = new List<string>();
            var filePath = _fileProvider.MapPath("~/Plugins/nop4all.megaslider/SupportedWidgetZones.xml");
            var content = await _fileProvider.ReadAllTextAsync(filePath, Encoding.UTF8);

            if (!string.IsNullOrEmpty(content))
            {
                var doc = new XmlDocument();
                using (var sr = new StringReader(content))
                {
                    using var xr = XmlReader.Create(sr,
                        new XmlReaderSettings
                        {
                            CloseInput = true,
                            IgnoreWhitespace = true,
                            IgnoreComments = true,
                            IgnoreProcessingInstructions = true
                        });

                    doc.Load(xr);
                }
                if ((doc.DocumentElement != null) && doc.HasChildNodes)
                {
                    var xmlRootNode = doc.DocumentElement;

                    foreach (XmlNode xmlChildNode in xmlRootNode.ChildNodes)
                        if (xmlChildNode.LocalName.Equals("WidgetZone", StringComparison.InvariantCultureIgnoreCase))
                        {
                            var value = xmlChildNode.InnerText;

                            if (!string.IsNullOrEmpty(value))
                                widgetZones.Add(value);
                        }
                }
            }
            return widgetZones;
        }

        /// <summary>
        /// Gets all new product positions from XML file
        /// </summary>
        /// <returns>A list of position strings</returns>
        public virtual async Task<IList<string>> GetAllNewProductPositionsAsync()
        {
            var positions = new List<string>();
            var filePath = _fileProvider.MapPath("~/Plugins/nop4all.megaslider/NewProductPositions.xml");
            var content = await _fileProvider.ReadAllTextAsync(filePath, Encoding.UTF8);

            if (!string.IsNullOrEmpty(content))
            {
                var doc = new XmlDocument();
                using (var sr = new StringReader(content))
                {
                    using var xr = XmlReader.Create(sr,
                        new XmlReaderSettings
                        {
                            CloseInput = true,
                            IgnoreWhitespace = true,
                            IgnoreComments = true,
                            IgnoreProcessingInstructions = true
                        });

                    doc.Load(xr);
                }
                if ((doc.DocumentElement != null) && doc.HasChildNodes)
                {
                    var xmlRootNode = doc.DocumentElement;

                    foreach (XmlNode xmlChildNode in xmlRootNode.ChildNodes)
                        if (xmlChildNode.LocalName.Equals("Position", StringComparison.InvariantCultureIgnoreCase))
                        {
                            var value = xmlChildNode.InnerText;

                            if (!string.IsNullOrEmpty(value))
                                positions.Add(value);
                        }
                }
            }
            return positions;
        }

        /// <summary>
        /// Gets all sliders by group id.
        /// </summary>
        /// <param name="groupId">Group slider identifier.</param>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="pageSize">Page size.</param>
        /// <returns>Paged list of sliders.</returns>
        public async Task<IPagedList<MegaSlider>> GetAllSliderByGroupIdAsync(
            int groupId,
            int pageIndex,
            int pageSize)
        {
            var query =
                from s in _megasliderRepository.Table
                join sm in _sliderMappingRepository.Table
                    on s.Id equals sm.SliderId
                where sm.GroupSliderId == groupId
                orderby s.DisplayOrder
                select s;

            return await query.ToPagedListAsync(pageIndex, pageSize);
        }

        /// <summary>
        /// Gets all sliders.
        /// </summary>
        /// <param name="groupSliderId">Group slider identifier.</param>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="pageSize">Page size.</param>
        /// <returns>Paged list of sliders.</returns>
        public virtual async Task<IPagedList<MegaSlider>> GetAllSliderAsync(
            int groupSliderId,
            int pageIndex = 0,
            int pageSize = int.MaxValue)
        {
            var query =
                from slider in _megasliderRepository.Table
                join mapping in _sliderMappingRepository.Table
                    on slider.Id equals mapping.SliderId
                where mapping.GroupSliderId == groupSliderId
                select slider;

            return await query.ToPagedListAsync(pageIndex, pageSize);
        }

        /// <summary>
        /// Get by All Sliders
        /// </summary>
        /// <param name="widgetZone">widgetZone</param>
        /// <param name="enabled">enabled</param>
        /// <returns>
        /// A task that represents the asynchronous operation.
        /// </returns>
        public virtual async Task<IList<MegaSlider>> GetAllSlidersAsync(
            string widgetZone = null,
            bool enabled = false)
        {
            var query = from co in _megasliderRepository.Table
                        where _sliderMappingRepository.Table.Any(sm =>
                              sm.SliderId == co.Id &&
                              _groupMegaSliderRepository.Table.Any(g =>
                                  g.Id == sm.GroupSliderId && g.Enable))
                        select co;

            if (!string.IsNullOrEmpty(widgetZone))
            {
                query = from c in query
                        where c.WidgetZone == widgetZone
                        select c;
            }

            if (enabled)
            {
                query = from c in query
                        where c.Enable
                        select c;
            }

            return await query.ToListAsync();
        }

        /// <summary>
        /// Inserts a new slider.
        /// </summary>
        /// <param name="megaSlider">Slider entity.</param>
        public virtual async Task InsertSliderAsync(MegaSlider megaSlider)
        {
            await _megasliderRepository.InsertAsync(megaSlider);
        }

        /// <summary>
        /// Update a slider.
        /// </summary>
        /// <param name="megaSlider">Slider entity.</param>
        public virtual async Task UpdateSliderAsync(MegaSlider megaSlider)
        {
            await _megasliderRepository.UpdateAsync(megaSlider);
        }

        /// <summary>
        /// Delete a slider.
        /// </summary>
        /// <param name="megaSlider">Slider entity.</param>
        public virtual async Task DeleteSliderAsync(MegaSlider megaSlider)
        {
            await _megasliderRepository.DeleteAsync(megaSlider);
        }

        /// <summary>
        /// Get slider by id
        /// </summary>
        /// <param name="sliderId">Slider entity.</param>
        public virtual async Task<MegaSlider> GetSliderByIdAsync(int sliderId)
        {
            return await _megasliderRepository.GetByIdAsync(sliderId);
        }

        /// <summary>
        /// Gets a featured product mapping by slider identifier.
        /// </summary>
        /// <param name="sliderId">Slider identifier.</param>
        /// <returns>Featured product mapping entity.</returns>
        public virtual async Task<MegaSliderFeaturedProducts> GetFeatureproductSliderByIdAsync(int sliderId)
        {
            return await _megasliderFetaureRepository.GetByIdAsync(sliderId);
        }

        /// <summary>
        /// Gets a new product mapping by slider identifier.
        /// </summary>
        /// <param name="sliderId">Slider identifier.</param>
        /// <returns>New product mapping entity.</returns>
        public virtual async Task<MegaSliderNewProducts> GetNewproductSliderByIdAsync(int sliderId)
        {
            return await _megaslidernewproductrepository.GetByIdAsync(sliderId);
        }

        /// <summary>
        /// Gets featured products associated with a specific slider.
        /// </summary>
        /// <param name="sliderid">Slider identifier.</param>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="pageSize">Page size.</param>
        /// <returns>Paged list of featured products.</returns>
        public virtual async Task<IPagedList<MegaSliderFeaturedProducts>> GetProductCategoriesBySliderIdAsync(int sliderid,
            int pageIndex = 0, int pageSize = int.MaxValue)
        {
            if (sliderid == 0)
                return new PagedList<MegaSliderFeaturedProducts>(new List<MegaSliderFeaturedProducts>(), pageIndex, pageSize);

            var query = from pc in _megasliderFetaureRepository.Table
                        join p in _productRepository.Table on pc.ProductId equals p.Id
                        where pc.SliderId == sliderid && !p.Deleted
                        orderby pc.DisplayOrder, pc.Id
                        select pc;

            return await query.ToPagedListAsync(pageIndex, pageSize);
        }

        /// <summary>
        /// Gets featured products by slider.
        /// </summary>
        /// <param name="sliderid">Slider identifier.</param>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="pageSize">Page size.</param>
        /// <param name="showHidden">A value indicating whether to show hidden products.</param>
        /// <returns>Paged list of featured products.</returns>
        public virtual async Task<IPagedList<MegaSliderFeaturedProducts>> GetFeatureProductBySliderAsync(int sliderid,
            int pageIndex = 0, int pageSize = int.MaxValue, bool showHidden = false)
        {
            if (sliderid == 0)
                return new PagedList<MegaSliderFeaturedProducts>(new List<MegaSliderFeaturedProducts>(), pageIndex, pageSize);

            var query = from pc in _megasliderFetaureRepository.Table
                        join p in _productRepository.Table on pc.ProductId equals p.Id
                        where pc.SliderId == sliderid && !p.Deleted
                        orderby pc.DisplayOrder, pc.Id
                        select pc;

            return await query.ToPagedListAsync(pageIndex, pageSize);
        }

        /// <summary>
        /// Finds a featured product in the given list.
        /// </summary>
        /// <param name="source">List of featured products.</param>
        /// <param name="productId">Product identifier.</param>
        /// <param name="sliderid">Slider identifier.</param>
        /// <returns>Featured product mapping if found.</returns>
        public virtual MegaSliderFeaturedProducts FindFeatureProduct(IList<MegaSliderFeaturedProducts> source, int productId, int sliderid)
        {
            foreach (var productCategory in source)
                if (productCategory.ProductId == productId && productCategory.Id == sliderid)
                    return productCategory;

            return null;
        }

        /// <summary>
        /// Inserts a featured product into a slider.
        /// </summary>
        /// <param name="megaSliderFeaturedProducts">Featured product mapping entity.</param>
        public virtual async Task InsertMegaSliderFeatureProductAsync(MegaSliderFeaturedProducts megaSliderFeaturedProducts)
        {
            await _megasliderFetaureRepository.InsertAsync(megaSliderFeaturedProducts);
        }

        /// <summary>
        /// Updates a featured product in a slider.
        /// </summary>
        /// <param name="megaSliderFeaturedProducts">Featured product mapping entity.</param>
        public virtual async Task UpdateMegaSliderFeatureProductAsync(MegaSliderFeaturedProducts megaSliderFeaturedProducts)
        {
            await _megasliderFetaureRepository.UpdateAsync(megaSliderFeaturedProducts);
        }

        /// <summary>
        /// Deletes a featured product from a slider.
        /// </summary>
        /// <param name="megaSliderFeaturedProducts">Featured product mapping entity.</param>
        public virtual async Task DeleteMegaSliderFeatureProductAsync(MegaSliderFeaturedProducts megaSliderFeaturedProducts)
        {
            await _megasliderFetaureRepository.DeleteAsync(megaSliderFeaturedProducts);
        }

        /// <summary>
        /// Inserts a new product into a slider.
        /// </summary>
        /// <param name="megaSliderNewProducts">New product mapping entity.</param>
        public virtual async Task InserMegaSliderNewProductAsync(MegaSliderNewProducts megaSliderNewProducts)
        {
            await _megaslidernewproductrepository.InsertAsync(megaSliderNewProducts);
        }

        /// <summary>
        /// Updates a new product in a slider.
        /// </summary>
        /// <param name="megaSliderNewProducts">New product mapping entity.</param>
        public virtual async Task UpdateMegaSliderNewProductAsync(MegaSliderNewProducts megaSliderNewProducts)
        {
            await _megaslidernewproductrepository.UpdateAsync(megaSliderNewProducts);
        }

        /// <summary>
        /// Deletes a new product from a slider.
        /// </summary>
        /// <param name="megaSliderNewProducts">New product mapping entity.</param>
        public virtual async Task DeleteMegaSliderNewProductAsync(MegaSliderNewProducts megaSliderNewProducts)
        {
            await _megaslidernewproductrepository.DeleteAsync(megaSliderNewProducts);
        }

        /// <summary>
        /// Gets new products by slider identifier.
        /// </summary>
        /// <param name="sliderid">Slider identifier.</param>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="pageSize">Page size.</param>
        /// <returns>Paged list of new products.</returns>
        public virtual async Task<IPagedList<MegaSliderNewProducts>> GetNewProductBySliderIdAsync(int sliderid,
           int pageIndex = 0, int pageSize = int.MaxValue)
        {
            if (sliderid == 0)
                return new PagedList<MegaSliderNewProducts>(new List<MegaSliderNewProducts>(), pageIndex, pageSize);

            var query = from pc in _megaslidernewproductrepository.Table
                        join p in _productRepository.Table on pc.ProductId equals p.Id
                        where pc.SliderId == sliderid && !p.Deleted
                        orderby pc.DisplayOrder, pc.Id
                        select pc;

            return await query.ToPagedListAsync(pageIndex, pageSize);
        }

        /// <summary>
        /// Gets new products by slider.
        /// </summary>
        /// <param name="sliderid">Slider identifier.</param>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="pageSize">Page size.</param>
        /// <param name="showHidden">A value indicating whether to show hidden products.</param>
        /// <returns>Paged list of new products.</returns>
        public virtual async Task<IPagedList<MegaSliderNewProducts>> GetNewProductBySliderAsync(int sliderid,
           int pageIndex = 0, int pageSize = int.MaxValue, bool showHidden = false)
        {
            if (sliderid == 0)
                return new PagedList<MegaSliderNewProducts>(new List<MegaSliderNewProducts>(), pageIndex, pageSize);

            var query = from pc in _megaslidernewproductrepository.Table
                        join p in _productRepository.Table on pc.ProductId equals p.Id
                        where pc.SliderId == sliderid && !p.Deleted
                        orderby pc.DisplayOrder, pc.Id
                        select pc;

            return await query.ToPagedListAsync(pageIndex, pageSize);
        }

        /// <summary>
        /// Finds a new product in the given list.
        /// </summary>
        /// <param name="source">List of new products.</param>
        /// <param name="productId">Product identifier.</param>
        /// <param name="sliderid">Slider identifier.</param>
        /// <returns>New product mapping if found.</returns>
        public virtual MegaSliderNewProducts FindNewProduct(IList<MegaSliderNewProducts> source, int productId, int sliderid)
        {
            foreach (var productCategory in source)
                if (productCategory.ProductId == productId && productCategory.Id == sliderid)
                    return productCategory;

            return null;
        }

        /// <summary>
        /// Gets all sliders.
        /// </summary>
        /// <param name="sliderid">slider Id</param>
        /// <param name="pageIndex">page Index</param>
        /// <param name="pageSize">page Size</param>
        /// <returns>List of sliders.</returns>
        public virtual async Task<IPagedList<MegaSliderSellProducts>> GetSellProductBySliderIdAsync(int sliderid,
          int pageIndex = 0, int pageSize = int.MaxValue)
        {
            if (sliderid == 0)
                return new PagedList<MegaSliderSellProducts>(new List<MegaSliderSellProducts>(), pageIndex, pageSize);

            var query = from pc in _megasliderSellProductRepository.Table
                        join p in _productRepository.Table on pc.ProductId equals p.Id
                        where pc.SliderId == sliderid && !p.Deleted
                        orderby pc.DisplayOrder, pc.Id
                        select pc;

            return await query.ToPagedListAsync(pageIndex, pageSize);
        }
        /// <summary>
        /// Gets all featured products by slider identifier.
        /// </summary>
        /// <param name="sliderid">Slider identifier.</param>
        /// <returns>List of featured product mappings.</returns>
        public virtual async Task<IList<MegaSliderFeaturedProducts>> GetAllFeturechedProductBySliderIdAsync(int sliderid)
        {
            var query = from pc in _megasliderFetaureRepository.Table
                        join p in _productRepository.Table on pc.ProductId equals p.Id
                        where pc.SliderId == sliderid && !p.Deleted
                        orderby pc.DisplayOrder, pc.Id
                        select pc;

            return await query.ToListAsync();
        }

        /// <summary>
        /// Gets all new products by slider identifier.
        /// </summary>
        /// <param name="sliderid">Slider identifier.</param>
        /// <returns>List of new product mappings.</returns>
        public virtual async Task<IList<MegaSliderNewProducts>> GetAllNewProductBySliderIdAsync(int sliderid)
        {
            var query = from pc in _megaslidernewproductrepository.Table
                        join p in _productRepository.Table on pc.ProductId equals p.Id
                        where pc.SliderId == sliderid && !p.Deleted
                        orderby pc.DisplayOrder, pc.Id
                        select pc;

            return await query.ToListAsync();
        }

        /// <summary>
        /// Gets locale string resources by resource prefix and language.
        /// </summary>
        /// <param name="localeStringResourcePrefix">The locale string resource prefix.</param>
        /// <param name="languageId">Language identifier.</param>
        /// <returns>List of locale string resources.</returns>
        public virtual async Task<IList<LocaleStringResource>> GetLocaleStringResourcesByLocaleStringResourcePrefixAsync(string localeStringResourcePrefix, int languageId = 0)
        {
            var query = from ls in _localeStringResourceRepository.Table
                        where ls.ResourceName.Contains(localeStringResourcePrefix) &&
                        ls.LanguageId == languageId
                        select ls;

            var localeStringResource = await query.ToListAsync();

            return localeStringResource;
        }
        /// <summary>
        /// Update mega slider
        /// </summary>
        /// <param name="MegaSlider"></param>
        /// <returns>Update mega slider</returns>
        public virtual async Task UpdateMegaSliderAsync(MegaSlider slider)
        {
            await _megasliderRepository.UpdateAsync(slider);
        }

        /// <summary>
        /// Gets all group sliders.
        /// </summary>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="pageSize">Page size.</param>
        /// <param name="showHidden">A value indicating whether to show hidden records.</param>
        /// <returns>Paged list of sliders.</returns>
        public async Task<IPagedList<GroupMegaSlider>> GetAllGroupSliderAsync(int pageIndex = 0, int pageSize = int.MaxValue, bool showHidden = false)
        {
            var query = from co in _groupMegaSliderRepository.Table
                        select co;

            return await query.ToPagedListAsync(pageIndex, pageSize);
        }

        /// <summary>
        /// Get All Group Sliders
        /// </summary>
        /// <param name="widgetZone">widgetZone</param>
        /// <param name="enabled">enabled</param>
        /// <returns>
        /// A task that represents the asynchronous operation.
        /// </returns>
        public virtual async Task<IList<GroupMegaSlider>> GetAllGroupSlidersAsync(
            string widgetZone,
            bool enabled)
        {
            var query = _groupMegaSliderRepository.Table.AsQueryable();

            if (!string.IsNullOrEmpty(widgetZone))
            {
                query = query.Where(x => x.Widgetzone == widgetZone);
            }

            if (enabled)
            {
                query = query.Where(x => x.Enable);
            }

            var groups = await query.ToListAsync();

           
            foreach (var group in groups)
            {
                var sliders = await _megasliderRepository.Table
                    .Where(s => s.WidgetZone == group.Widgetzone && s.Enable)
                    .ToListAsync();

                foreach (var slider in sliders)
                {
                    var exists = await _sliderMappingRepository.Table.AnyAsync(m =>
                        m.SliderId == slider.Id &&
                        m.GroupSliderId == group.Id);
                }
            }

            return groups;
        }

        /// <summary>
        /// Inserts a new group slider.
        /// </summary>
        /// <param name="groupslider">Slider entity.</param>
        public async Task InsertGroupSliderAsync(GroupMegaSlider groupslider)
        {
            await _groupMegaSliderRepository.InsertAsync(groupslider);
        }

        /// <summary>
        /// Update a  group slider.
        /// </summary>
        /// <param name="groupslider">Slider entity.</param>
        public async Task UpdateGroupSliderAsync(GroupMegaSlider groupslider)
        {
            await _groupMegaSliderRepository.UpdateAsync(groupslider);

        }

        /// <summary>
        /// Delete a group slider.
        /// </summary>
        /// <param name="groupslider">Slider entity.</param>
        public async Task DeleteGroupSliderAsync(GroupMegaSlider groupslider)
        {
            await _groupMegaSliderRepository.DeleteAsync(groupslider);

        }

        /// <summary>
        /// Get  group slider by id
        /// </summary>
        /// <param name="groupsliderId">Group Slider entity.</param>
        public async Task<GroupMegaSlider> GetSliderGroupByIdAsync(int groupsliderId)
        {
            return await _groupMegaSliderRepository.GetByIdAsync(groupsliderId);

        }

        /// <summary>
        /// Gets a Group by slider by its identifier.
        /// </summary>
        /// <param name="sliderId">Slider identifier.</param>
        /// <returns>
        /// The slider entity.
        /// </returns>
        public async Task<SliderMapping> GetGroupBySliderIdAsync(int sliderId)
        {
            
            return await _sliderMappingRepository.Table
               .FirstOrDefaultAsync(x => x.SliderId == sliderId);

        }

        /// <summary>
        /// Delete a Group Slider Mapping
        /// </summary>
        /// <param name="sliderId">Slider identifier.</param>
        /// <returns>
        /// A task that represents the asynchronous operation.
        /// </returns>
        public async Task DeleteGroupSliderMappingAsync(int sliderId)
        {
            var mapping = await _sliderMappingRepository.Table
                .FirstOrDefaultAsync(x => x.SliderId == sliderId);

            if (mapping != null)
            {
                await _sliderMappingRepository.DeleteAsync(mapping);
            }
        }

        /// <summary>
        /// Insert Slider Mapping
        /// </summary>
        /// <param name="sliderId">Slider identifier.</param>
        /// <param name="groupSliderId">GroupSlider identifier.</param>
        /// <returns>
        /// A task that represents the asynchronous operation.
        /// </returns>
        public async Task InsertSliderMappingAsync(int sliderId, int groupSliderId)
        {
            if (sliderId <= 0)
                throw new ArgumentException("SliderId is invalid");

            if (groupSliderId <= 0)
                throw new ArgumentException("GroupSliderId is invalid");

            var mapping = new SliderMapping
            {
                SliderId = sliderId,
                GroupSliderId = groupSliderId
            };

            await _sliderMappingRepository.InsertAsync(mapping);
        }

        /// <summary>
        /// Get All Effect
        /// </summary>
        /// <returns>A list of Effects</returns>
        public virtual async Task<IList<string>> GetAllEffect()
        {
            var effects = new List<string>();

            var filePath = _fileProvider.MapPath("~/Plugins/nop4all.megaslider/Effects.xml");

            if (!_fileProvider.FileExists(filePath))
                return effects;

            var content = await _fileProvider.ReadAllTextAsync(filePath, Encoding.UTF8);

            if (string.IsNullOrWhiteSpace(content))
                return effects;

            var doc = new XmlDocument();
            doc.LoadXml(content);

            var nodes = doc.SelectNodes("//Effect");

            if (nodes != null)
            {
                foreach (XmlNode node in nodes)
                {
                    if (!string.IsNullOrWhiteSpace(node.InnerText))
                        effects.Add(node.InnerText.Trim());
                } 
            }

            return effects;
        }

        /// <summary>
        /// Get slider product by id
        /// </summary>
        /// <param name="id">Get by New Products Ids</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        public async Task<MegaSliderNewProducts> GetNewProductByIdAsync(int id)
        {
            if (id <= 0)
                return null;

            return await _megaslidernewproductrepository.GetByIdAsync(id);
        }

        /// <summary>
        /// Update slider product
        /// </summary>
        /// <param name="entity">Entity</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        public async Task UpdateNewProductAsync(MegaSliderNewProducts entity)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));

            await _megaslidernewproductrepository.UpdateAsync(entity);
        }

        /// <summary>
        /// Gets a sell product mapping by slider identifier.
        /// </summary>
        /// <param name="sliderId">Slider identifier.</param>
        /// <returns>Sell product mapping entity.</returns>
        public virtual async Task<MegaSliderSellProducts> GetSellproductSliderByIdAsync(int sliderId)
        {
            return await _megasliderSellProductRepository.GetByIdAsync(sliderId);
        }

        /// <summary>
        /// Updates a sell product in a slider.
        /// </summary>
        /// <param name="megaSliderNewProducts">sell product mapping entity.</param>
        public virtual async Task UpdateMegaSliderSellProductAsync(MegaSliderSellProducts megaSliderSellProducts)
        {
            await _megasliderSellProductRepository.UpdateAsync(megaSliderSellProducts);
        }

        /// <summary>
        /// Deletes a sell product from a slider.
        /// </summary>
        /// <param name="megaSliderNewProducts">New product mapping entity.</param>
        public virtual async Task DeleteMegaSliderSellProductAsync(MegaSliderSellProducts megaSliderSellProducts)
        {
            await _megasliderSellProductRepository.DeleteAsync(megaSliderSellProducts);
        }

        /// <summary>
        /// Gets sell products by slider.
        /// </summary>
        /// <param name="sliderid">Slider identifier.</param>
        /// <param name="pageIndex">Page index.</param>
        /// <param name="pageSize">Page size.</param>
        /// <param name="showHidden">A value indicating whether to show hidden products.</param>
        /// <returns>Paged list of sell products.</returns>
        public virtual async Task<IPagedList<MegaSliderSellProducts>> GetSellProductBySliderAsync(int sliderid,
           int pageIndex = 0, int pageSize = int.MaxValue, bool showHidden = false)
        {
            if (sliderid == 0)
                return new PagedList<MegaSliderSellProducts>(new List<MegaSliderSellProducts>(), pageIndex, pageSize);

            var query = from pc in _megasliderSellProductRepository.Table
                        join p in _productRepository.Table on pc.ProductId equals p.Id
                        where pc.SliderId == sliderid && !p.Deleted
                        orderby pc.DisplayOrder, pc.Id
                        select pc;

            return await query.ToPagedListAsync(pageIndex, pageSize);
        }

        /// <summary>
        /// Finds a sell product in the given list.
        /// </summary>
        /// <param name="source">List of new products.</param>
        /// <param name="productId">Product identifier.</param>
        /// <param name="sliderid">Slider identifier.</param>
        /// <returns>sell product mapping if found.</returns>
        public virtual MegaSliderSellProducts FindSellProduct(IList<MegaSliderSellProducts> source, int productId, int sliderid)
        {
            foreach (var productCategory in source)
                if (productCategory.ProductId == productId && productCategory.Id == sliderid)
                    return productCategory;

            return null;
        }

        /// <summary>
        /// Inserts a sell product into a slider.
        /// </summary>
        /// <param name="megaSliderNewProducts">New product mapping entity.</param>
        public virtual async Task InserMegaSliderSellProductAsync(MegaSliderSellProducts megaSliderSellProducts)
        {
            await _megasliderSellProductRepository.InsertAsync(megaSliderSellProducts);
        }

        /// <summary>
        /// Get sell product by id
        /// </summary>
        public async Task<MegaSliderSellProducts> GetSellProductByIdAsync(int id)
        {
            if (id <= 0)
                return null;

            return await _megasliderSellProductRepository.GetByIdAsync(id);
        }

        /// <summary>
        /// Update sell product
        /// </summary>
        public async Task UpdateSellProductAsync(MegaSliderSellProducts entity)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));
                    
            await _megasliderSellProductRepository.UpdateAsync(entity);
        }

        /// <summary>
        /// Gets all Sell products by slider identifier.
        /// </summary>
        /// <param name="sliderid">Slider identifier.</param>
        /// <returns>List of Sell product mappings.</returns>
        public virtual async Task<IList<MegaSliderSellProducts>> GetAllSellProductBySliderIdAsync(int sliderid)
        {
            var query = from pc in _megasliderSellProductRepository.Table
                        join p in _productRepository.Table on pc.ProductId equals p.Id
                        where pc.SliderId == sliderid && !p.Deleted
                        orderby pc.DisplayOrder, pc.Id
                        select pc;

            return await query.ToListAsync();
        }
        #endregion
    }
}