﻿using Nop.Core;
using Nop.Data;
using Nop.Plugin.nop4all.megaslider.Domain; 

namespace Nop.Plugin.nop4all.megaslider.Services
{
    /// <summary>
    /// Condition service
    /// </summary>
    public class ConditionService : IConditionService
    {
        #region Fields
        protected readonly IRepository<MegaSliderGroupCondition> _menuConditionRepository;
        #endregion

        #region Ctor
        public ConditionService(IRepository<MegaSliderGroupCondition> menuConditionRepository)
        {
            _menuConditionRepository = menuConditionRepository;
        }
        #endregion

        #region Methods
        /// <summary>
        /// Get Menu Condition By GroupId.
        /// </summary>
        /// <param name="GroupId">The ID of the menu to retrieve conditions for.</param>
        /// <param name="pageIndex">The zero-based index of the page to retrieve. Defaults to 0.</param>
        /// <param name="pageSize">The maximum number of conditions per page. Defaults to Int32.MaxValue.</param>
        /// <returns>A paged list of menu conditions.</returns>
        public async Task<IPagedList<MegaSliderGroupCondition>> GetMenuConditionByMenuIdAsync(int groupId, int pageIndex = 0, int pageSize = int.MaxValue)
        {
            var query = from m in _menuConditionRepository.Table
                        where m.GroupId == groupId
                        select m;

            return await query.ToPagedListAsync(pageIndex, pageSize);
        }

        /// <summary>
        ///Get Menu Condition By Id.
        /// </summary>
        /// <param name="Id">The identifier of the menu condition to retrieve.</param>
        /// <returns> if found; otherwise, null.</returns>
        public async Task<MegaSliderGroupCondition> GetMenuConditionByIdAsync(int id)
        {
            return await _menuConditionRepository.GetByIdAsync(id);
        }

        /// <summary>
        ///Insert Condition .
        /// </summary>
        /// <param name="condition">The MenuCondition object to be inserted.</param>
        /// <returns>A Task representing the asynchronous operation.</returns>
        public async Task InsertConditionAsync(MegaSliderGroupCondition condition)
        {
            await _menuConditionRepository.InsertAsync(condition);
        }

        /// <summary>
        /// Update Condition .
        /// </summary>
        /// <param name="condition">The MenuCondition object to be Update.</param>
        /// <returns>A Task representing the asynchronous operation.</returns>
        public async Task UpdateConditionAsync(MegaSliderGroupCondition condition)
        {
            await _menuConditionRepository.UpdateAsync(condition);
        }

        /// <summary>
        /// Delete Condition .
        /// </summary>
        /// <param name="condition">The MenuCondition object to be Delete.</param>
        /// <returns>A Task representing the asynchronous operation.</returns>
        public async Task DeleteConditionAsync(MegaSliderGroupCondition condition)
        {
            await _menuConditionRepository.DeleteAsync(condition);
        }

        /// <summary>
        /// Is Widget Zone Has Condition
        /// </summary>
        /// <param name="widgetZone">Widget zone name</param>
        /// <returns>A Task representing the asynchronous operation.</returns>
        public async Task<bool> IsWidgetZoneHasConditionAsync(string widgetZone)
        {
            if (string.IsNullOrEmpty(widgetZone))
                return false;

            return await _menuConditionRepository.Table
                .AnyAsync(x => x.WidgetZone == widgetZone);
        }

        /// <summary>
        /// Get by Al lConditions
        /// </summary>
        /// <returns>A Task representing the asynchronous operation.</returns>
        public async Task<IList<MegaSliderGroupCondition>> GetAllConditionsAsync()
        {
            return await _menuConditionRepository.Table
                .ToListAsync();
        }

        #endregion
    }
}