﻿namespace Nop.Plugin.nop4all.megaslider
{
    /// <summary>
    /// Represents plugin constants
    /// </summary>
    public class MegasliderDefaults
    {
        /// <summary>
        /// The key of the settings Locale String Resource Prefix
        /// </summary>
        public const string LocaleStringResourcePrefix = "Plugin.nop4all.megaslider";

    }
}
