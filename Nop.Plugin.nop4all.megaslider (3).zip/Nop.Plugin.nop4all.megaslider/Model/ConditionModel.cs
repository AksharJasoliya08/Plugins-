﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Web.Framework.Models;

namespace Nop.Plugin.nop4all.megaslider.Models
{
    /// <summary>
    /// Represents a Menu Condition Model.
    /// </summary>
    public partial record ConditionModel : BaseNopEntityModel
    {
        public ConditionModel()
        {
            AvailableConditionType = new List<SelectListItem>();
            AvailableProperty = new List<SelectListItem>();
            AvailableOperator = new List<SelectListItem>();
            AvailableValue = new List<SelectListItem>();
            AvailableManufacturers = new List<SelectListItem>();
            AvailableWidgetZones = new List<SelectListItem>();
        }
        public int GroupId { get; set; }
        public string ConditionType { get; set; }
        public string Property { get; set; }
        public string Operator { get; set; }
        public string Value { get; set; }
        public int NumberValue { get; set; }
        public string TextValue { get; set; } 
        public int Type { get; set; }

        public string WidgetZone { get; set; }
        public IList<SelectListItem> AvailableWidgetZones { get; set; }
        public List<SelectListItem> AvailableConditionType { get; set; }
        public IList<SelectListItem> AvailableProperty { get; set; }
        public IList<SelectListItem> AvailableOperator { get; set; }
        public List<SelectListItem> AvailableValue { get; set; }
        public List<SelectListItem> AvailableManufacturers { get; set; }
    }
}