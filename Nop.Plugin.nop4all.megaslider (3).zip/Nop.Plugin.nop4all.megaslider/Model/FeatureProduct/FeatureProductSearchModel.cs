﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.nop4all.megaslider.Model.FeatureProduct
{
    /// <summary>
    /// Feature product search model
    /// </summary>
    public partial record FeatureProductSearchModel : BaseSearchModel
    {
        public int MegaSliderId { get; set; }
    }
}