﻿using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.nop4all.megaslider.Model.FeatureProduct
{
    /// <summary>
    /// Feature product model
    /// </summary>
    public record FeatureProductModel : BaseNopEntityModel
    {
        public int SliderId { get; set; }
        public int ProductId { get; set; }
        [NopResourceDisplayName("Admin.Catalog.Categories.Products.Fields.Product")]
        public string ProductName { get; set; }
        [NopResourceDisplayName("Admin.Catalog.Categories.Products.Fields.DisplayOrder")]
        public int DisplayOrder { get; set; }

        public int PictureId { get; set; }

        public string PictureUrl { get; set; }
        public string EditUrl { get; set; }
    }
}