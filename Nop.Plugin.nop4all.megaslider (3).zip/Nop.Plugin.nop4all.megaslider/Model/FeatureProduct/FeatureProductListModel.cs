﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.nop4all.megaslider.Model.FeatureProduct
{
    /// <summary>
    /// Add feature product to slider list model
    /// </summary>
    public partial record FeatureProductListModel : BasePagedListModel<FeatureProductModel>
    {
    }
}