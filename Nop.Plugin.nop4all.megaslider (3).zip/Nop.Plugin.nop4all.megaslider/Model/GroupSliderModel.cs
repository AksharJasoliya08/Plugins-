﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Plugin.nop4all.megaslider.Model.Slider;
using Nop.Plugin.nop4all.megaslider.Models;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.nop4all.megaslider.Model;
/// <summary>
/// Represent Group Slider Model
/// </summary>
public record GroupSliderModel  :  BaseNopEntityModel, IStoreMappingSupportedModel    
{
    #region ctor 
    public GroupSliderModel()
    {
        SliderSearchModel = new SliderSearchModel();
        SliderOverviewModel = new SliderModel();
        SliderModel = new List<SliderModel>();
        Availablewidgetzone = new List<SelectListItem>();

        SelectedStoreIds = new List<int>();
        AvailableStores = new List<SelectListItem>();
        BannerImageUrls = new List<string>();
        AvailableAnimationEffects = new List<SelectListItem>();
        AvailableTransitionAnimationEffect = new List<SelectListItem>();
    }

    #endregion

    [NopResourceDisplayName("Plugin.nop4all.megaslider.Enable")]
    public bool Enable { get; set; }

    [NopResourceDisplayName("Plugin.nop4all.megaslider.Name")]
    public string Name { get; set; }

    [NopResourceDisplayName("Plugin.nop4all.megaslider.DisplayOrder")]
    public int DisplayOrder { get; set; }

    [NopResourceDisplayName("Plugin.nop4all.megaslider.LimitedToStores")]
    public bool LimitedToStores { get; set; }
    [NopResourceDisplayName(" Plugin.nop4all.megaslider.SelectedStoreIds")]
    public IList<int> SelectedStoreIds { get; set; }
    public IList<SelectListItem> AvailableStores { get; set; }

    [NopResourceDisplayName("Plugin.nop4all.megaslider.Widgetzone")]
    public string Widgetzone { get; set; }
    public IList<SelectListItem> Availablewidgetzone { get; set; }

    [NopResourceDisplayName("Plugin.nop4all.megaslider.Show")]
    public bool Show { get; set; }

    [NopResourceDisplayName("Plugin.nop4all.megaslider.Hide")]
    public bool Hide { get; set; }

    [NopResourceDisplayName("Plugin.nop4all.megaslider.LeftSide")]
    public bool LeftSide { get; set; }

    [NopResourceDisplayName("Plugin.nop4all.megaslider.RightSide")]
    public bool RightSide { get; set; }

    [NopResourceDisplayName("Plugin.nop4all.megaslider.DotArrrow")]
    public bool DotArrrow { get; set; }

    [NopResourceDisplayName("Plugin.nop4all.megaslider.Menu")]
    public bool Menu { get; set; }

    [NopResourceDisplayName("Plugin.nop4all.megaslider.AnimationEffect")]
    public int AnimationEffectId { get; set; }
    public string AnimationEffect { get; set; }

    public IList<SelectListItem> AvailableAnimationEffects { get; set; }

    public int GroupId { get; set; }

    [NopResourceDisplayName("Plugin.nop4all.megaslider.GroupSliderHeight")]
    public int GroupSliderHeight { get; set; }
    public IList<SliderModel> SliderModel { get; set; }
    public IList<string> BannerImageUrls { get; set; }
    public SliderModel SliderOverviewModel { get; set; }
    public SliderSearchModel SliderSearchModel { get; set; }
    public ConditionSearchModel ConditionSearchModel { get; set; }

    [NopResourceDisplayName("Plugin.nop4all.megaslider.TransitionAnimationEffect")]
    public int TransitionAnimationEffectId { get; set; }
    public IList<SelectListItem> AvailableTransitionAnimationEffect { get; set; }
}