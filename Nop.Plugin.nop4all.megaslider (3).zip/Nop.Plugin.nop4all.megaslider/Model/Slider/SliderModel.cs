﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Plugin.nop4all.megaslider.Model.FeatureProduct;
using Nop.Plugin.nop4all.megaslider.Model.NewProduct;
using Nop.Plugin.nop4all.megaslider.Model.SellProduct;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;
using Nop.Web.Models.Catalog;

namespace Nop.Plugin.nop4all.megaslider.Model.Slider
{
    /// <summary>
    /// SliderModel
    /// </summary>
    public record SliderModel : BaseNopEntityModel, IStoreMappingSupportedModel, ILocalizedModel<SliderLocalizedModel>
    {
        public SliderModel()
        {
            Availablewidgetzone = new List<SelectListItem>();
            Availablepositioning = new List<SelectListItem>();
            AvailableEffects = new List<SelectListItem>();
            FeatureProductSearchModel = new FeatureProductSearchModel();
            NewProductSearchModel = new NewProductSearchModel();
            FeatureProductModel = new FeatureProductModel();
            SellProductSearchModel = new SellProductSearchModel();
            SellProductModel = new SellProductModel();
            ProductOverviewModel = new List<ProductOverviewModel>();
            NewProductOverviewModel = new List<ProductOverviewModel>();
            SellProductOverviewModel = new List<ProductOverviewModel>();
            Locales = new List<SliderLocalizedModel>();
            SelectedStoreIds = new List<int>();
            AvailableStores = new List<SelectListItem>();
            BannerImageUrls = new List<string>();
            AvailableCTAButtonStyles = new List<SelectListItem>();
            AvailableTextBlockPosition = new List<SelectListItem>();
            AvailableContentSpacing = new List<SelectListItem>();
            AvilableOverlayType = new List<SelectListItem>();
            AvilableColorPresetType = new List<SelectListItem>();
            AvailableTitleFontSizes = new List<SelectListItem>();
            AvailableBackgroundSizes = new List<SelectListItem>();
            AvailableBackgroundOverlays = new List<SelectListItem>();
            AvilableColorPresetType = new List<SelectListItem>();
            AvilableTextAlignment = new List<SelectListItem>();
            AvailableBackgroundVideoTypes = new List<SelectListItem>();

            //Remove Code 
            //AvailableContentLayerPositions = new List<SelectListItem>();
            //AvailableContentLayerPositionsSecond = new List<SelectListItem>();
            //AvailableContentLayerPositionsThird = new List<SelectListItem>();
        }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Enable")]
        public bool Enable { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Name")]
        public string Name { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.ContentType")]
        public int ContentType { get; set; }
        [NopResourceDisplayName("Plugin.nop4all.megaslider.ProductType")]
        public bool ProductType { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.IncludeTop")]
        public bool IncludeTop { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Title")]
        public string Title { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.ShortDescription")]
        public string ShortDescription { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.HtmlContent")]
        public string HtmlContent { get; set; }
        
        [NopResourceDisplayName("Plugin.nop4all.megaslider.DisplayOrder")]
        public int DisplayOrder { get; set; }
        
        [NopResourceDisplayName("Plugin.nop4all.megaslider.DescriptionFontSize")]
        public int DescriptionFontSize { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Positioning")]
        public int Positioning { get; set; }
        
        public string Positionings { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.WidgetZone")]
        public string WidgetZone { get; set; } 

        [NopResourceDisplayName("Plugin.nop4all.megaslider.FeaturedProductEffect")]
        public string FeaturedProductEffect { get; set; }
        [NopResourceDisplayName("Plugin.nop4all.megaslider.SellProductModelEffect")]
        public string SellProductModelEffect { get; set; }
        [NopResourceDisplayName("Plugin.nop4all.megaslider.NewProductseffect")]
        public string NewProductseffect { get; set; }
        
        [NopResourceDisplayName("plugin.nop4all.megaslider.ProductSliderDots")]
        public bool ProductSliderDots { get; set; }
        [NopResourceDisplayName("plugin.nop4all.megaslider.ProductSliderArrows")]
        public bool ProductSliderArrows { get; set; }

        [NopResourceDisplayName("plugin.nop4all.megaslider.SliderDelay")]
        public int SliderDelay { get; set; }
        public int GroupHight { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.SelectedStoreIds")]
        public IList<int> SelectedStoreIds { get; set; }
        public IList<SelectListItem> AvailableStores { get; set; }
        public IList<ProductOverviewModel> ProductOverviewModel { get; set; }
        public IList<ProductOverviewModel> NewProductOverviewModel { get; set; }
        public IList<ProductOverviewModel> SellProductOverviewModel { get; set; } 
        public IList<SelectListItem> Availablewidgetzone { get; set; }
        public IList<SelectListItem> Availablepositioning { get; set; }
        
        public IList<SelectListItem> AvailableEffects { get; set; }

        //add new
        public IList<SelectListItem> AvailableTextBlockPosition { get; set; }
        public IList<SelectListItem> AvailableContentSpacing { get; set; }
        public IList<SelectListItem> AvilableOverlayType { get; set; }
        public IList<SelectListItem> AvilableColorPresetType { get; set; }
        public IList<SelectListItem> AvilableCardTheme { get; set; }
        public FeatureProductSearchModel FeatureProductSearchModel { get; set; }
        public NewProductSearchModel NewProductSearchModel { get; set; }
        public FeatureProductModel FeatureProductModel { get; set; } 
        public SellProductSearchModel SellProductSearchModel { get; set; }
        public SellProductModel SellProductModel { get; set; }
        public int GroupId { get; set; }
        public IList<SliderLocalizedModel> Locales { get; set; }
        public IList<string> BannerImageUrls { get; set; }
        public bool SliderArrows { get; set; }
        public bool SliderDots { get; set; }
        public bool Menu { get; set; }

        [NopResourceDisplayName("Plugins.Widgets.MegaSlider.Fields.IsAutoPlay")]
        public bool IsAutoPlay { get; set; }

        [NopResourceDisplayName("Plugins.Widgets.MegaSlider.Fields.UseNaturalVideoSizeOnMobile")]
        public bool UseNaturalVideoSizeOnMobile { get; set; }
        public string AnimationEffect { get; set; }
        public string TransitionAnimationEffect { get; set; }

        #region CTA BUTTON 1
        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.CTAButton1IsVisible")]
        public bool CTAButton1IsVisible { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.CTAButton1Text")]
        public string CTAButton1Text { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.CTAButton1Style")]
        public int CTAButton1StyleId { get; set; }
        public string CTAButton1StyleIds { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.CTAButton1BackgroundColor")]
        public string CTAButton1BackgroundColor { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.CTAButton1TextColor")]
        public string CTAButton1TextColor { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.CTAButton1RedirectUrl")]
        public string CTAButton1RedirectUrl { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.CTAButton1FontSize")]
        public int CTAButton1FontSize { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.Cta1OpenInNewTab")]
        public bool Cta1OpenInNewTab { get; set; }
        #endregion


        #region CTA BUTTON 2
        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.CTAButton2IsVisible")]
        public bool CTAButton2IsVisible { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.CTAButton2Text")]
        public string CTAButton2Text { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.CTAButton2Style")]
        public int CTAButton2StyleId { get; set; }
        public string CTAButton2StyleIds { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.CTAButton2BackgroundColor")]
        public string CTAButton2BackgroundColor { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.CTAButton2TextColor")]
        public string CTAButton2TextColor { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.CTAButton2RedirectUrl")]
        public string CTAButton2RedirectUrl { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.CTAButton2FontSize")]
        public int CTAButton2FontSize { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.Cta2OpenInNewTab")]
        public bool Cta2OpenInNewTab { get; set; }

        public IList<SelectListItem> AvailableCTAButtonStyles { get; set; }
        #endregion

        #region Conten  
        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.BadgeText")]
        public string BadgeText { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.BadgeImageId")]
        public int BadgeImageId { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.PriceText")]
        public string PriceText { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.SlideAltDescription")]
        public string SlideAltDescription { get; set; }
        #endregion


        #region Layout & style
        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.BackgroundType")]
        public int BackgroundType { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.BackgroundColor")]
        public string BackgroundColor { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.BackgroundImageId")]
        public int BackgroundImageId { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.BackgroundSize")]
        public int BackgroundSize { get; set; }          // Stores numeric enum value
        public string BackgroundSizes { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.BackgroundOverlay")]
        public int BackgroundOverlay { get; set; }
        public string BackgroundOverlays { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.TextAlignment")]
        public int TextAlignment { get; set; }
        public string TextAlignments { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.BlockStyle")]
        public int BlockStyle { get; set; }
        public string BlockStyles { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.TextTheme")]
        public int TextTheme { get; set; }
        public string TextThemes {  get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.TitleFontSize")]
        public int TitleFontSize { get; set; }
        public string TitleFontSizes { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.BackgroundVideoUrl")]
        public string BackgroundVideoUrl { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.BackgroundVideoTypeId")]
        public int BackgroundVideoTypeId { get; set; }
        public string BackgroundVideoTypeIds { get; set; }
        public IList<SelectListItem> AvailableBackgroundVideoTypes { get; set; }

        public IList<SelectListItem> AvailableTitleFontSizes { get; set; }
        public IList<SelectListItem> AvailableBackgroundSizes { get; set; }
        public IList<SelectListItem> AvailableBackgroundOverlays { get; set; }
        public IList<SelectListItem> AvilableTextAlignment {get; set;}

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.TextBlockOffset")]
        public bool TextBlockOffset { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.Top")]

        //change
        public int? Top { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.Right")]
        public int? Right { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.Bottom")]
        public int? Bottom { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.Left")]
        public int? Left { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.TextBlockPosition")]
        public int TextBlockPosition { get; set; }
        public string TextBlockPositions { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.ContentSpacing")]
        public int ContentSpacing { get; set; }
        public string ContentSpacings { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.Cardtheme")]
        public int Cardtheme { get; set; }
        public string Cardthemes { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.Cardbackgroundcolor")]
        public string Cardbackgroundcolor { get; set; }
        #endregion

        #region Zone Tab
        public int ZoneType { get; set; }

        // Left Zone
        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.LeftImageId")]
        public int LeftImageId { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.LeftImageLink")]
        public string LeftImageLink { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.LeftColor")]
        public string LeftColor { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.LeftEmpty")]
        public string LeftEmpty { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.LeftOpenInNewTab")]
        public bool LeftOpenInNewTab { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.LeftHideOnDesktop")]
        public bool LeftHideOnDesktop { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.LeftHideOnMobile")]
        public bool LeftHideOnMobile { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.LeftImageAlt")]
        public string LeftImageAlt { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.LeftOverlay")]
        public int LeftOverlay { get; set; }
        public string LeftOverlays { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.LeftColorpreset")]
        public int LeftColorpreset { get; set; }
        public string LeftColorpresets { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.LeftZoneType")]
        public int LeftZoneType { get; set; }
        public string LeftZoneTypes { get; set; }

        // Right Zone
        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.RightImageId")]
        public int RightImageId { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.RightImageLink")]
        public string RightImageLink { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.RightColor")]
        public string RightColor { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.RightEmpty")]
        public string RightEmpty { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.RightOpenInNewTab")]
        public bool RightOpenInNewTab { get; set; }
        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.RightHideOnDesktop")]
        public bool RightHideOnDesktop { get; set; }
        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.RightHideOnMobile")]
        public bool RightHideOnMobile { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.RightImageAlt")]
        public string RightImageAlt { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.RightOverlay")]
        public int RightOverlay { get; set; }
        public string RightOverlays { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.RightColorpreset")]
        public int RightColorpreset { get; set; }
        public string RightColorpresets { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.RightZoneType")]
        public int RightZoneType { get; set; }
        public string RightZoneTypes { get; set; }
        #endregion

        //Remove Code
        //[NopResourceDisplayName("Plugin.nop4all.megaslider.Content")]
        //public string Content { get; set; }
        //[NopResourceDisplayName("Plugin.nop4all.megaslider.ContentLayer")]
        //public string ContentLayer { get; set; }
        //[NopResourceDisplayName("Plugin.nop4all.megaslider.ContentLayer3")]
        //public string ContentLayer3 { get; set; }
        //[NopResourceDisplayName("Plugin.nop4all.megaslider.ContentLayerPositions")]
        //public int ContentLayerPositions { get; set; }
        //[NopResourceDisplayName("Plugin.nop4all.megaslider.ContentLayerPositionsSecond")]
        //public int ContentLayerPositionsSecond { get; set; }
        //[NopResourceDisplayName("Plugin.nop4all.megaslider.ContentLayerPositionsThird")]
        //public int ContentLayerPositionsThird { get; set; }
        //[NopResourceDisplayName("Plugin.nop4all.megaslider.Texttransitions")]
        //public string Texttransitions { get; set; }
        //[NopResourceDisplayName("plugin.nop4all.megaslider.TransitionEffectDelay")]
        //public int TransitionEffectDelay { get; set; }
        //[NopResourceDisplayName("plugin.nop4all.megaslider.AllowRepeatAnimation")]
        //public bool AllowRepeatAnimation { get; set; } 
        //public IList<SelectListItem> AvailableContentLayerPositions { get; set; }
        //public IList<SelectListItem> AvailableContentLayerPositionsSecond { get; set; }
        //public IList<SelectListItem> AvailableContentLayerPositionsThird { get; set; }


    }
    public partial record SliderLocalizedModel : ILocalizedLocaleModel
    {
        public int LanguageId { get; set; }

        //hero Description
        [NopResourceDisplayName("Plugin.nop4all.megaslider.ShortDescription")]
        public string ShortDescription { get; set; }

        //hero Description
        [NopResourceDisplayName("Plugin.nop4all.megaslider.Title")]
        public string Title { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.HtmlContent")]
        public string HtmlContent { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.CTAButton1Text")]
        public string CTAButton1Text { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.CTAButton2Text")]
        public string CTAButton2Text { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.CTAButton1RedirectUrl")]
        public string CTAButton1RedirectUrl { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.CTAButton2RedirectUrl")]
        public string CTAButton2RedirectUrl { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.BadgeText")]
        public string BadgeText { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.PriceText")]
        public string PriceText { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.SlideAltDescription")]
        public string SlideAltDescription { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Fields.BackgroundVideoUrl")]
        public string BackgroundVideoUrl { get; set; }

        //Remove Code 
        //[NopResourceDisplayName("Plugin.nop4all.megaslider.ContentLayer")]
        //public string ContentLayer { get; set; }
        //[NopResourceDisplayName("Plugin.nop4all.megaslider.ContentLayer3")]
        //public string ContentLayer3 { get; set; }
        //[NopResourceDisplayName("Plugin.nop4all.megaslider.Content")]
        //public string Content { get; set; }

    }
}