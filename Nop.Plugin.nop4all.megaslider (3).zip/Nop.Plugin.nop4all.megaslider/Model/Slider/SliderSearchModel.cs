﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.nop4all.megaslider.Model.Slider
{
    /// <summary>
    /// SliderSearchModel
    /// </summary>
    public record SliderSearchModel : BaseSearchModel
    {
        public int GroupId { get; set; }
    }
}