﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.nop4all.megaslider.Model.Slider
{
    /// <summary>
    /// Slider list model
    /// </summary>
    public partial record SliderListModel : BasePagedListModel<SliderModel>
    {
    }
}