﻿using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.nop4all.megaslider.Model.MSLanguageResource
{
    /// <summary>
    /// MS Language Resource Model
    /// </summary>
    public record MSLanguageResourceModel : BaseNopEntityModel
    {
        [NopResourceDisplayName("Plugin.nop4all.megaslider.fields.ResourceName")]
        public string ResourceName { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.fields.ResourceName.Value")]
        public string Value { get; set; }
    }
}