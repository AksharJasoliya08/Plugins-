﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.nop4all.megaslider.Model.MSLanguageResource
{
    /// <summary>
    /// MS Languag eResource List Model
    /// </summary>
    public partial record MSLanguageResourceListModel : BasePagedListModel<MSLanguageResourceModel>
    {
    }
}