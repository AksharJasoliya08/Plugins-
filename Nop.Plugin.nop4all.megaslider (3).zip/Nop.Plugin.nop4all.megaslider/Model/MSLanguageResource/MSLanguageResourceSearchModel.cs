﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Web.Framework.Models;

namespace Nop.Plugin.nop4all.megaslider.Model.MSLanguageResource
{
    /// <summary>
    /// MS Language Resource Search Model
    /// </summary>
    public partial record MSLanguageResourceSearchModel : BaseSearchModel
    {
        public MSLanguageResourceSearchModel()
        {
            AvailableLanguages = new List<SelectListItem>();
        }
        public IList<SelectListItem> AvailableLanguages { get; set; }
        public int SelectedLanguage { get; set; }

    }
}