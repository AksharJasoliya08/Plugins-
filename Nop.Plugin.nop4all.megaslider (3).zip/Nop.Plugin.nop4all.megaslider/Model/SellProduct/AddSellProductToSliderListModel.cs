﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.nop4all.megaslider.Model.SellProduct;
/// <summary>
/// Add sell product to slider list model
/// </summary>
public partial record AddSellProductToSliderListModel : BasePagedListModel<AddSellProductToSliderModel>
{
 
}