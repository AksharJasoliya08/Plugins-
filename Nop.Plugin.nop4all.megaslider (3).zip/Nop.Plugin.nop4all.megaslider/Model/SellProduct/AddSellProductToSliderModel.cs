﻿using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.nop4all.megaslider.Model.SellProduct;

/// <summary>
/// Add sell product to slider model
/// </summary>
public record AddSellProductToSliderModel : BaseNopEntityModel
{
    public AddSellProductToSliderModel()
    {
        SelectedProductIds = new List<int>();
    }
    [NopResourceDisplayName("Admin.Catalog.Products.List.SearchProductName")]
    public string ProductName { get; set; }
    [NopResourceDisplayName("Admin.Catalog.Products.List.Publish")]
    public bool Publish { get; set; }
    public int MegaSliderId { get; set; }
    public IList<int> SelectedProductIds { get; set; }
}