﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.nop4all.megaslider.Model.SellProduct;

/// <summary>
/// sell product list model
/// </summary>
public partial record SellProductListModel : BasePagedListModel<SellProductModel>
{
}