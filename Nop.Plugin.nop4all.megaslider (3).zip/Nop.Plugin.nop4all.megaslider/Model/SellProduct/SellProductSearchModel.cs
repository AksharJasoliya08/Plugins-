﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.nop4all.megaslider.Model.SellProduct;
/// <summary>
/// sell Product Search Model
/// </summary>
public partial record SellProductSearchModel : BaseSearchModel
{
    /// <summary>
    /// sell product search model
    /// </summary>
    public int MegaSliderId { get; set; }
}