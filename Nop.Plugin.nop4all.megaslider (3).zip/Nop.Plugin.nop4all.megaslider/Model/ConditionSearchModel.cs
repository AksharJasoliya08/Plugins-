﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.nop4all.megaslider.Models
{
    /// <summary>
    /// Represents a Condition Search Model.
    /// </summary>
    public record ConditionSearchModel : BaseSearchModel
    {
        #region Properties
        /// <summary>
        /// Gets or sets the GroupId.
        /// </summary>
        public int GroupId { get; set; }
        #endregion
    }
}