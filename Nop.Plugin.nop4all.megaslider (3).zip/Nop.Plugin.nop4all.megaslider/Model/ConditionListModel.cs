﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.nop4all.megaslider.Models
{
    /// <summary>
    /// Represents a condition list model.
    /// </summary>
    public partial record ConditionListModel : BasePagedListModel<ConditionModel>
    {
    }
}