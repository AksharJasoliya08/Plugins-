﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.nop4all.megaslider.Model.NewProduct
{
    /// <summary>
    /// New product search model
    /// </summary>
    public partial record NewProductSearchModel : BaseSearchModel
    {
        public int MegaSliderId { get; set; }
    }
}