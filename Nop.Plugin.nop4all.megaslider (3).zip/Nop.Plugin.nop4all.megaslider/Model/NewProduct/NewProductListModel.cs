﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.nop4all.megaslider.Model.NewProduct
{
    /// <summary>
    /// New product list model
    /// </summary>
    public partial record NewProductListModel : BasePagedListModel<NewProductModel>
    {
    }
}