﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.nop4all.megaslider.Model.NewProduct
{
    /// <summary>
    /// Add new product to slider list model
    /// </summary>
    public partial record AddNewProductToSliderListModel : BasePagedListModel<AddNewProductToSliderModel>
    {
    }
}