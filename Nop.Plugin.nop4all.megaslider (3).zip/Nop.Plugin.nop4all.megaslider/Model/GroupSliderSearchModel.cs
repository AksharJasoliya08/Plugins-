﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.nop4all.megaslider.Model;
/// <summary>
/// Represent Group Slider Search Model
/// </summary>
public record GroupSliderSearchModel : BaseSearchModel
{
}