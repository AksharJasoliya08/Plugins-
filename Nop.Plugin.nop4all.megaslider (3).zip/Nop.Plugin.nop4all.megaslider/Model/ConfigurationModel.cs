﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.nop4all.megaslider.Model
{
    /// <summary>
    /// Configuration model
    /// </summary>
    public record ConfigurationModel : BaseNopModel
    {
        public ConfigurationModel()
        {
            AvailableNewProductPositions = new List<SelectListItem>();
        }
        public int ActiveStoreScopeConfiguration { get; set; }
        [NopResourceDisplayName("Plugin.nop4all.megaslider.Enable")]
        public bool Enable { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Enabled_OverrideForStore")]
        public bool Enable_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Autoplay")]
        public int Autoplay { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Autoplay_OverrideForStore")]
        public bool Autoplay_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.ProductAutoplay")]
        public int ProductAutoplay { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.ProductAutoplay_OverrideForStore")]
        public bool ProductAutoplay_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.ProductSliderDots")]
        public bool ProductSliderDots { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.ProductSliderDots_OverrideForStore")]
        public bool ProductSliderDots_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.ProductSliderArrows")]
        public bool ProductSliderArrows { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.ProductSliderArrows_OverrideForStore")]
        public bool ProductSliderArrows_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.MainSliderDots")]
        public bool MainSliderDots { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.MainSliderDots_OverrideForStore")]
        public bool MainSliderDots_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.MainSliderArrows")]
        public bool MainSliderArrows { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.MainSliderArrows_OverrideForStore")]
        public bool MainSliderArrows_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.SliderHeight")]
        public int SliderHeight { get; set; }

        [NopResourceDisplayName("plugin.nop4all.megaslider.AnimationRepeat")]
        public int AnimationRepeat { get; set; }

        [NopResourceDisplayName("plugin.nop4all.megaslider.AnimationRepeat_OverrideForStore")]
        public bool AnimationRepeat_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.SliderHeight_OverrideForStore")]
        public bool SliderHeight_OverrideForStore { get; set; }

        [NopResourceDisplayName("plugin.nop4all.megaslider.Newproductdropdown")]
        public string Newproductdropdown { get; set; }

        [NopResourceDisplayName("Plugin.nop4all.megaslider.Newproductdropdown_OverrideForStore")]
        public bool Newproductdropdown_OverrideForStore { get; set; }

        public IList<SelectListItem> AvailableNewProductPositions { get; set; }
    }
}