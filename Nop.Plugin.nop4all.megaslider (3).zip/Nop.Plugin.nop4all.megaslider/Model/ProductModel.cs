﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.nop4all.megaslider.Model
{
    /// <summary>
    /// Product model
    /// </summary>
    public partial record ProductModel : BaseNopEntityModel
    {
        public int ProductId { get; set; }

    }
}
