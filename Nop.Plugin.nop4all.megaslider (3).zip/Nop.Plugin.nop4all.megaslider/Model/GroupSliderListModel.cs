﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.nop4all.megaslider.Model;
/// <summary>
/// Represent Group Slider List Model
/// </summary>
public partial record GroupSliderListModel : BasePagedListModel<GroupSliderModel>
{
}