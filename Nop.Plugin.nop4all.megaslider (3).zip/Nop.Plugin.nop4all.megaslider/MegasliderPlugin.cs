﻿using Nop.Core;
using Nop.Data;
using Nop.Plugin.nop4all.megaslider.Components;
using Nop.Plugin.nop4all.megaslider.Domain;
using Nop.Plugin.nop4all.megaslider.Services;
using Nop.Services.Cms;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Plugins;
using Nop.Services.Security;

namespace Nop.Plugin.nop4all.megaslider
{
    public class MegasliderPlugin : BasePlugin, IWidgetPlugin
    {
        #region Fields
        protected readonly IWebHelper _webHelper;
        protected readonly ISettingService _settingService;
        protected readonly ILocalizationService _localizationService;
        protected readonly IPermissionService _permissionService;
        protected readonly MegasliderSettings _megasliderSettings;
        protected readonly IMegasliderServices _megasliderServices;
        protected readonly IRepository<GroupMegaSlider> _groupMegaSlider;
        protected readonly IConditionService _conditionService;

        #endregion

        #region Ctor
        public MegasliderPlugin(IWebHelper webHelper,
            ISettingService settingService,
            ILocalizationService localizationService,
            IPermissionService permissionService,
            MegasliderSettings megasliderSettings,
            IMegasliderServices megasliderServices,
            IRepository<GroupMegaSlider> groupMegaSlider,
            IConditionService conditionService)
        {
            _webHelper = webHelper;
            _settingService = settingService;
            _localizationService = localizationService;
            _permissionService = permissionService;
            _megasliderSettings = megasliderSettings;
            _megasliderServices = megasliderServices;
            _groupMegaSlider = groupMegaSlider;
            _conditionService = conditionService;
        }
        #endregion

        #region Methods

        /// <summary>
        /// Get widget zones async
        /// </summary>
        /// <returns></returns>
        public async Task<IList<string>> GetWidgetZonesAsync()
        {
            var zones = new List<string>();

            // Get all enabled groups
            var groups = await _megasliderServices.GetAllGroupSlidersAsync(null, true);
            if (groups != null && groups.Any())
            {
                zones.AddRange(
                    groups
                        .Where(g => g.Enable && !string.IsNullOrEmpty(g.Widgetzone))
                        .Select(g => g.Widgetzone)
                );
            }

            // Get all enabled sliders
            var sliders = await _megasliderServices.GetAllSlidersAsync(enabled: true);
            if (sliders != null && sliders.Any())
            {
                zones.AddRange(
                    sliders
                        .Where(s => s.Enable && !string.IsNullOrEmpty(s.WidgetZone))
                        .Select(s => s.WidgetZone)
                );
            }

            var conditions = await _conditionService.GetAllConditionsAsync(); 

            if (conditions != null && conditions.Any())
            {
                zones.AddRange(
                    conditions
                        .Where(c => !string.IsNullOrEmpty(c.WidgetZone))
                        .Select(c => c.WidgetZone)
                );
            }

            return zones.Distinct().ToList();
        }


        /// <summary>
        /// Gets a type of a view component for displaying widget
        /// </summary>
        /// <param name="widgetZone">Name of the widget zone</param>
        /// <returns>View component type</returns>
       
        public Type GetWidgetViewComponent(string widgetZone)
        {
            if (_conditionService.IsWidgetZoneHasConditionAsync(widgetZone).GetAwaiter().GetResult())
                return typeof(SliderConditionViewComponent);

            return typeof(SliderViewComponent);
        }

        /// <summary>
        /// Gets a configuration page URL
        /// </summary>
        public override string GetConfigurationPageUrl()
        {
            return _webHelper.GetStoreLocation() + "Admin/Megaslider/Settings";
        }

        /// <summary>
        /// Install async
        /// </summary>
        /// <returns></returns>
        public override async Task InstallAsync()
        {
            var settings = new MegasliderSettings()
            {
                WidgetZone = "switchstylesheet",
                Color = "blue"
            };
            await _settingService.SaveSettingAsync(settings);

            await _localizationService.AddOrUpdateLocaleResourceAsync(new Dictionary<string, string>
            {
                ["Plugin.nop4all.megaslider.Configure.Info"] = "Configure",
                ["Plugin.nop4all.megaslider.Configure.Slider.List"] = "Slider List",
                ["Plugin.nop4all.megaslider.Color"] = "Color",
                ["Plugin.nop4all.megaslider.Color.Hint"] = "Color",
                ["Plugin.nop4all.megaslider.Enable"] = "Enable",
                ["Plugin.nop4all.megaslider.Enable.Hint"] = "Enable",
                ["Plugin.nop4all.megaslider.Widgetzone"] = "Widget zone",
                ["Plugin.nop4all.megaslider.Widgetzone.Hint"] = "Select Widget zone",
                ["Plugin.nop4all.megaslider.LeftSide"] = "Slider Side",
                ["Plugin.nop4all.megaslider.LeftSide.Hint"] = "The slider is set to the right by default; check the checkbox to move it to the left",
                ["Plugin.nop4all.megaslider.RightSide"] = "RightSide",
                ["Plugin.nop4all.megaslider.RightSide.Hint"] = "RightSide",
                ["Plugin.nop4all.megaslider.Show"] = "Slider Visible?",
                ["Plugin.nop4all.megaslider.Show.Hint"] = "The slider is set to the Visible by default; Set the Redion button to Hide Slider",
                ["Plugin.nop4all.megaslider.Hide"] = "Hide",
                ["Plugin.nop4all.megaslider.Hide.Hint"] = "Hide",
                ["Plugin.nop4all.megaslider.Autoplay"] = "Content Delay",
                ["Plugin.nop4all.megaslider.Autoplay.Hint"] = "Set The Content Delay in Mili Second (2000 , 5000...)",
                ["Plugin.nop4all.megaslider.Name"] = "Slider Name",
                ["Plugin.nop4all.megaslider.Name.Hint"] = "Slider Name",
                ["Plugin.nop4all.megaslider.ContentType"] = "Content Type",
                ["Plugin.nop4all.megaslider.ContentType.Hint"] = "The Content is set to the Product by default; Set the Redion button To Show Content Layer(Add Text and Image Etc...)",
                ["Plugin.nop4all.megaslider.DisplayOrder"] = "Display Order",
                ["Plugin.nop4all.megaslider.DisplayOrder.Hint"] = "Display Order",
                ["Plugin.nop4all.megaslider.Content"] = "Content",
                ["Plugin.nop4all.megaslider.Content.Hint"] = "Content",
                ["Plugin.nop4all.megaslider.AddNewSlider"] = "AddNew Slider",
                ["Plugin.nop4all.megaslider.AddNew"] = "Add New Group",
                ["Plugin.nop4all.megaslider.BackToList"] = "BackToList",
                ["Plugin.nop4all.megaslider.Slider.Info"] = "Slider Info",
                ["Plugin.nop4all.megaslider.FeatureProducts"] = "Feature Products",
                ["Plugin.nop4all.megaslider.NewProducts"] = "NewProducts",
                ["Plugin.nop4all.megaslider.FeatureProducts.AddNew"] = "AddNew",
                ["Plugin.nop4all.megaslider.NewProducts.AddNew"] = "AddNew",
                ["Plugin.nop4all.megaslider.Slider"] = "Slider",
                ["fantastic.newproduct"] = "New",
                ["Plugin.nop4all.megaslider.ContentLayer"] = "Content Layer",
                ["Plugin.nop4all.megaslider.ContentLayer3"] = "Content Layer Third",
                ["Pugin.nop4all.megaslider.selectedstoreids.Hint"] = "Selected Store Name",
                ["Plugin.nop4all.megaslider.SelectedStoreIds"] = "Limited to stores",
                ["Plugin.nop4all.megaslider.SelectedStoreIds.Hint"] = "Select to stores",
                ["Plugin.nop4all.megaslider.ContentLayer.Hint"] = "Content Layer",
                ["Plugin.nop4all.megaslider.ContentLayer3.Hint"] = "Content Layer Third",
                ["Plugin.nop4all.megaslider.ProductAutoplay"] = "Content Item Delay",
                ["Plugin.nop4all.megaslider.ProductAutoplay.Hint"] = "Set The Content Delay in Mili Second (2000 , 5000...)",
                ["Plugin.nop4all.megaslider.Fields.QuickEdit"] = "QuickEdit",
                ["Plugin.nop4all.megaslider.Fields.Enable"] = "Enable",
                ["Plugin.nop4all.megaslider.IncludeTop"] = "Include In Top",
                ["Plugin.nop4all.megaslider.IncludeTop.Hint"] = "Include In Setting WigdetZone",
                ["plugin.nop4all.megaslider.group.slider.info"] = "Group-Slider",
                ["plugin.nop4all.megaslider.edit"] = "Edit",
                ["plugin.nop4all.megaslider.contentitemdelay"] = "ContentItem Delay",
                ["plugin.nop4all.megaslider.contentitemdelay.Hint"] = "Enter for ContentItem Delay",
                ["plugin.nop4all.megaslider.contentdelay"] = " Content Delay",
                ["plugin.nop4all.megaslider.contentdelay.Hint"] = "Enter for Content Delay",
                ["plugin.nop4all.megamenu4all.fields.configuremegamenu.addnew"] = "Add New Menu Group",
                ["plugin.nop4all.megaslider.featuredproducteffect"] = "FeatureProduct Effect",
                ["plugin.nop4all.megaslider.featuredproducteffect.Hint"] = "Select Effect for FeatureProduct ",
                ["plugin.nop4all.megaslider.SellProductModelEffect"] = "Sell Product Model Effect",
                ["plugin.nop4all.megaslider.SellProductModelEffect.Hint"] = "Sell Product Model Effect",
                ["plugin.nop4all.megaslider.newproductseffect"] = "Select Effect for NewProduct ",
                ["plugin.nop4all.megaslider.newproductseffect.Hint"] = "Select Effect for NewProduct ",
                ["plugin.nop4all.megaslider.Texttransitions"] = "Text transitions",
                ["plugin.nop4all.megaslider.Texttransitions.Hint"] = "Text transitions",

                ["Plugin.nop4all.megaslider.Slider.BasicInfo"] = "Basic Info",
                ["Plugin.nop4all.megaslider.Slider.ContentInfo"] = "Content Info",
                ["Plugin.nop4all.megaslider.Slider.StoreMapping"] = "Store Mapping",
                ["plugin.nop4all.megaslider.sellproducts"] = "Sell Products",

                //sitemap 
                ["Plugin.nop4all.SiteMap.Nop4all"] = "Nop4All",
                ["Plugin.nop4all.SiteMap.Nop4all.Plugin"] = "Plugins",
                ["Plugin.nop4all.megaslider.SiteMap.megaslider"] = "Mega Slider",
                ["Plugin.nop4all.megaslider.SiteMap.MegaSliderConfigure"] = "Settings",
                ["Plugin.nop4all.megaslider.SiteMap.MegaSliderHelp"] = "Help",
                ["Plugin.nop4all.megaslider.SiteMap.MSLanguageResource"] = "Language Resource",
                ["Plugin.nop4all.megaslider.MSLanguageResource.List"] = "Language Resource",
                ["Plugin.nop4all.megaslider.MSLanguageResource.List.Instructions"] = "Don't change 'Plugin.nop4all.megaslider' prefix.",
                ["Plugin.nop4all.megaslider.fields.ResourceName"] = "Resource Name",
                ["Plugin.nop4all.megaslider.fields.ResourceName.Value"] = "Value",
                ["Plugin.nop4all.megaslider.Methods.Configure"] = "Settings",
                ["Plugin.nop4all.megaslider.Save"] = "Slider has been created successfully.",
                ["Plugin.nop4all.megaslider.update"] = "Slider has been updated successfully.",
                ["Plugin.nop4all.megaslider.sliderdots"] = "Slider Dots",
                ["Plugin.nop4all.megaslider.sliderdots.Hint"] = "Slider Dots",
                ["Plugin.nop4all.megaslider.sliderarrow"] = "Slider Arrow",
                ["Plugin.nop4all.megaslider.sliderarrow.Hint"] = "Slider Arrow",
                ["Nop.Plugin.nop4all.megaslider.Fields.SelectEffect"] = "--Select--",
                ["Plugin.nop4all.megaslider.Menu"] = "Menu Type",
                ["Plugin.nop4all.megaslider.Menu.Hint"] = "Select the menu type where the Mega Slider will be displayed.",


                //new for conditions
                ["plugin.nop4all.megaslider.groupslider.conditions"] = "Group Slider Conditions",
                ["plugin.nop4all.megaslider.groupmegaslider.conditions.addnew"] = "Add New",
                ["plugin.nop4all.megaslider.fields.conditiontype"] = "Condition Type",
                ["plugin.nop4all.megaslider.fields.property"] = "Property",
                ["plugin.nop4all.megaslider.fields.operator"] = "Operator",
                ["plugin.nop4all.megaslider.fields.value"] = "Value",
                ["plugin.nop4all.megaslider.megamenu.conditions.title"] = "Conditions",
                ["Plugin.nop4all.megaslider.Fields.WidgetZone"] = "WidgetZone",

                ["plugin.nop4all.megaslider.SliderDelay"] = "SliderDelay",
                ["plugin.nop4all.megaslider.TransitionEffectDelay"] = "Transition Effect Delay",
                ["plugin.nop4all.megaslider.positioning"] = "Positioning",

                ["plugin.nop4all.megaslider.ProductSliderDots"] = "Product Slider Dots",
                ["plugin.nop4all.megaslider.ProductSliderDots.Hint"] = "Enable or disable dots for the product slider",
                ["plugin.nop4all.megaslider.ProductSliderArrows"] = "Product Slider Arrows",
                ["plugin.nop4all.megaslider.ProductSliderArrows.Hint"] = "Enable or disable arrows for the product slider",
                ["plugin.nop4all.megaslider.MainSliderDots"] = "Main Slider Dots",
                ["plugin.nop4all.megaslider.MainSliderDots.Hint"] = "Enable or disable dots for the main slider",
                ["plugin.nop4all.megaslider.MainSliderArrows"] = "Main Slider Arrows",
                ["plugin.nop4all.megaslider.MainSliderArrows.Hint"] = "Enable or disable arrows for the main slider",
                ["plugin.nop4all.megaslider.sliderheight"] = "Slider Height",
                ["plugin.nop4all.megaslider.sliderheight.Hint"] = "Enter slider height in px, %, vh, or auto",
                ["plugin.nop4all.megaslider.SellProductModelEffect"] = "Sell Product Model Effect",
                ["plugin.nop4all.megaslider.SellProductModelEffect.Hint"] = "Enable or disable sell product model animation effect",
                ["plugin.nop4all.megaslider.Newproductdropdown"] = "New Product Position",
                ["plugin.nop4all.megaslider.Newproductdropdown.Hint"] = "Select the position for new product display (topright, topleft, bottomright, bottomleft)",

                ["plugin.nop4all.megaslider.Title"] = "HeroTitle",
                ["plugin.nop4all.megaslider.Title.Hint"] = "Enter the hero title text for the slider.",
                ["plugin.nop4all.megaslider.Shortdescription"] = "HeroDescription",
                ["plugin.nop4all.megaslider.Shortdescription.Hint"] = "Enter a hero description to display on the slider.",
                ["plugin.nop4all.megaslider.titlefontsize"] = "Title Font Size",
                ["plugin.nop4all.megaslider.titlefontsize.Hint"] = "Enter the font size in px for the slider title (e.g., 24).",
                ["plugin.nop4all.megaslider.descriptionfontsize"] = "Description Font Size",
                ["plugin.nop4all.megaslider.descriptionfontsize.Hint"] = "Enter the font size in px for the slider description (e.g., 16).",
                ["plugin.nop4all.megaslider.contentlayerpositionssecond"] = "Content Layer Positions Second",
                ["plugin.nop4all.megaslider.contentlayerpositions"] = "Content Layer Positions",
                ["plugin.nop4all.megaslider.contentlayerpositionsthird"] = "Content Layer Positions Third",
                ["plugin.nop4all.megaslider.contentlayerpositionssecond.Hint"] = "Content Layer Positions Second",
                ["plugin.nop4all.megaslider.contentlayerpositionsthird.Hint"] = "Content Layer Positions Third",
                ["plugin.nop4all.megaslider.contentlayerpositions.Hint"] = "Content Layer Positions",

                ["Plugin.nop4all.megaslider.Fields.CTAButton1IsVisible"] = "CTA Button 1 Visible",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1IsVisible.Hint"] = "Enable this option to display CTA Button 1 on the slider.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1Text"] = "CTA Button 1 Text",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1Text.Hint"] = "Enter the text that will appear on CTA Button 1. This field supports multiple languages.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1Style"] = "CTA Button 1 Style",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1Style.Hint"] = "Select the visual style for CTA Button 1.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1BackgroundColor"] = "CTA Button 1 Background Color",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1BackgroundColor.Hint"] = "Choose the background color for CTA Button 1.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1TextColor"] = "CTA Button 1 Text Color",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1TextColor.Hint"] = "Choose the text color for CTA Button 1.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1RedirectUrl"] = "CTA Button 1 Redirect URL",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1RedirectUrl.Hint"] = "Enter the URL where users will be redirected after clicking CTA Button 1. This field supports multiple languages.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2IsVisible"] = "CTA Button 2 Visible",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2IsVisible.Hint"] = "Enable this option to display CTA Button 2 on the slider.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2Text"] = "CTA Button 2 Text",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2Text.Hint"] = "Enter the text that will appear on CTA Button 2. This field supports multiple languages.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2Style"] = "CTA Button 2 Style",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2Style.Hint"] = "Select the visual style for CTA Button 2.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2BackgroundColor"] = "CTA Button 2 Background Color",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2BackgroundColor.Hint"] = "Choose the background color for CTA Button 2.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2TextColor"] = "CTA Button 2 Text Color",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2TextColor.Hint"] = "Choose the text color for CTA Button 2.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2RedirectUrl"] = "CTA Button 2 Redirect URL",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2RedirectUrl.Hint"] = "Enter the URL where users will be redirected after clicking CTA Button 2. This field supports multiple languages.",
                ["Plugin.nop4all.megaslider.CTAButton1"] = "CTA Button 1 Settings",
                ["Plugin.nop4all.megaslider.CTAButton2"] = "CTA Button 2 Settings",


                ["Plugin.nop4all.megaslider.Fields.CTAButton1FontSize"] = "CTA Button 1 Font Size",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1FontSize.Hint"] = "Enter the font size for CTA Button 1 (for example: 14px, 16px).",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2FontSize"] = "CTA Button 2 Font Size",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2FontSize.Hint"] = "Enter the font size for CTA Button 2 (for example: 14px, 16px).",


                ["Plugin.nop4all.megaslider.HtmlContent"] = "Html Content",
                ["Plugin.nop4all.megaslider.HtmlContent.Hint"] = "Html Content",

                ["plugin.nop4all.megaslider.AllowRepeatAnimation"] = "Allow Repeat Animation",
                ["plugin.nop4all.megaslider.AllowRepeatAnimation.Hint"] = "Check to enable the animation to repeat continuously.",

                ["Plugin.nop4all.megaslider.Fields.BadgeText"] = "Badge Text",
                ["Plugin.nop4all.megaslider.Fields.BadgeText.Hint"] = "Enter the text to display as a badge on the slide (e.g., New, Sale).",

                ["Plugin.nop4all.megaslider.Fields.BadgeImageId"] = "Badge Image",
                ["Plugin.nop4all.megaslider.Fields.BadgeImageId.Hint"] = "Upload or select an image to use as a badge for the slide.",

                ["Plugin.nop4all.megaslider.Fields.PriceText"] = "Price Text",
                ["Plugin.nop4all.megaslider.Fields.PriceText.Hint"] = "Enter the price or promotional text to display on the slide.",

                ["Plugin.nop4all.megaslider.Fields.SlideAltDescription"] = "Slide Alt Description",
                ["Plugin.nop4all.megaslider.Fields.SlideAltDescription.Hint"] = "Provide alternative text for the slide image for SEO and accessibility.",

                ["Plugin.nop4all.megaslider.Fields.Cta1OpenInNewTab"] = "CTA 1 Open in New Tab",
                ["Plugin.nop4all.megaslider.Fields.Cta1OpenInNewTab.Hint"] = "Check this option to open the first call-to-action link in a new browser tab.",

                ["Plugin.nop4all.megaslider.Fields.Cta2OpenInNewTab"] = "CTA 2 Open in New Tab",
                ["Plugin.nop4all.megaslider.Fields.Cta2OpenInNewTab.Hint"] = "Check this option to open the second call-to-action link in a new browser tab.",

                ["plugin.nop4all.megaslider.Title"] = "HeroTitle",
                ["plugin.nop4all.megaslider.Title.Hint"] = "Enter the hero title text for the slider.",
                ["plugin.nop4all.megaslider.Shortdescription"] = "HeroDescription",
                ["plugin.nop4all.megaslider.Shortdescription.Hint"] = "Enter a hero description to display on the slider.",
                ["Plugin.nop4all.megaslider.Fields.OpenInNewTab"] = "Open in New Tab",
                ["Plugin.nop4all.megaslider.Fields.OpenInNewTab.Hint"] = "Enable this option to open the link in a new browser tab instead of the current tab.",

                ["Plugin.nop4all.megaslider.Fields.TextBlockOffset"] = "Text Block Off set",
                ["Plugin.nop4all.megaslider.Fields.TextBlockOffset.Hint"] = "Enable this option to manually adjust the position of the text block using top, right, bottom, and left values.",

                ["Plugin.nop4all.megaslider.Fields.Top"] = "Top Offset",
                ["Plugin.nop4all.megaslider.Fields.Top.Hint"] = "Set the distance from the top of the slide (in pixels).",

                ["Plugin.nop4all.megaslider.Fields.Right"] = "Right Offset",
                ["Plugin.nop4all.megaslider.Fields.Right.Hint"] = "Set the distance from the right side of the slide (in pixels).",

                ["Plugin.nop4all.megaslider.Fields.Bottom"] = "Bottom Offset",
                ["Plugin.nop4all.megaslider.Fields.Bottom.Hint"] = "Set the distance from the bottom of the slide (in pixels).",

                ["Plugin.nop4all.megaslider.Fields.Left"] = "Left Offset",
                ["Plugin.nop4all.megaslider.Fields.Left.Hint"] = "Set the distance from the left side of the slide (in pixels).",

                ["Plugin.nop4all.megaslider.Fields.TextBlockPosition"] = "Text Block Position",
                ["Plugin.nop4all.megaslider.Fields.TextBlockPosition.Hint"] = "Select the predefined position of the text block (e.g., Top Left, Center, Bottom Right).",

                ["Plugin.nop4all.megaslider.Fields.ContentSpacing"] = "Content Spacing",
                ["Plugin.nop4all.megaslider.Fields.ContentSpacing.Hint"] = "Set the spacing between elements inside the text block (in pixels).",



                ["Plugin.nop4all.megaslider.Fields.ZoneType"] = "Zone Type",
                ["Plugin.nop4all.megaslider.Fields.ZoneType.Hint"] = "Select the type of content for this zone (e.g., Text, Image, Button, HTML).",

                // LEFT
                ["Plugin.nop4all.megaslider.Fields.LeftImageId"] = "Left Image",
                ["Plugin.nop4all.megaslider.Fields.LeftImageId.Hint"] = "Upload or select an image to display in the left zone.",

                ["Plugin.nop4all.megaslider.Fields.LeftImageLink"] = "Left Image Link",
                ["Plugin.nop4all.megaslider.Fields.LeftImageLink.Hint"] = "Enter the URL to navigate when the left image is clicked.",

                ["Plugin.nop4all.megaslider.Fields.LeftColor"] = "Left Background Color",
                ["Plugin.nop4all.megaslider.Fields.LeftColor.Hint"] = "Select a background color for the left zone.",

                ["Plugin.nop4all.megaslider.Fields.LeftEmpty"] = "Left Empty",
                ["Plugin.nop4all.megaslider.Fields.LeftEmpty.Hint"] = "No content will be displayed in the left zone.",

                ["Plugin.nop4all.megaslider.Fields.LeftOpenInNewTab"] = "Left Open in New Tab",
                ["Plugin.nop4all.megaslider.Fields.LeftOpenInNewTab.Hint"] = "Enable this option to open the left zone link in a new browser tab.",

                ["Plugin.nop4all.megaslider.Fields.LeftHideOnDesktop"] = "Left Hide on Desktop",
                ["Plugin.nop4all.megaslider.Fields.LeftHideOnDesktop.Hint"] = "Enable this option to hide the left zone on desktop devices.",

                ["Plugin.nop4all.megaslider.Fields.LeftHideOnMobile"] = "Left Hide on Mobile",
                ["Plugin.nop4all.megaslider.Fields.LeftHideOnMobile.Hint"] = "Enable this option to hide the left zone on mobile devices.",

                ["Plugin.nop4all.megaslider.Fields.LeftImageAlt"] = "Left Image Alt Text",
                ["Plugin.nop4all.megaslider.Fields.LeftImageAlt.Hint"] = "Enter alternative text for the left image (used for SEO and accessibility).",

                ["Plugin.nop4all.megaslider.Fields.LeftOverlay"] = "Left Overlay",
                ["Plugin.nop4all.megaslider.Fields.LeftOverlay.Hint"] = "Enable or configure an overlay on the left zone (e.g., dark/light overlay over image or color).",

                ["Plugin.nop4all.megaslider.Fields.LeftColorpreset"] = "Left Color Preset",
                ["Plugin.nop4all.megaslider.Fields.LeftColorpreset.Hint"] = "Select a predefined color preset for the left zone background.",

                ["Plugin.nop4all.megaslider.Fields.LeftZoneType"] = "Left Zone Type",
                ["Plugin.nop4all.megaslider.Fields.LeftZoneType.Hint"] = "Select the content type for the left zone (e.g., Image, Color, or Empty).",

                // RIGHT
                ["Plugin.nop4all.megaslider.Fields.RightImageId"] = "Right Image",
                ["Plugin.nop4all.megaslider.Fields.RightImageId.Hint"] = "Upload or select an image to display in the right zone.",

                ["Plugin.nop4all.megaslider.Fields.RightImageLink"] = "Right Image Link",
                ["Plugin.nop4all.megaslider.Fields.RightImageLink.Hint"] = "Enter the URL to navigate when the right image is clicked.",

                ["Plugin.nop4all.megaslider.Fields.RightColor"] = "Right Background Color",
                ["Plugin.nop4all.megaslider.Fields.RightColor.Hint"] = "Select a background color for the right zone.",

                ["Plugin.nop4all.megaslider.Fields.RightEmpty"] = "Right Empty",
                ["Plugin.nop4all.megaslider.Fields.RightEmpty.Hint"] = "No content will be displayed in the right zone.",

                ["Plugin.nop4all.megaslider.Fields.RightOpenInNewTab"] = "Right Open in New Tab",
                ["Plugin.nop4all.megaslider.Fields.RightOpenInNewTab.Hint"] = "Enable this option to open the right zone link in a new browser tab.",

                ["Plugin.nop4all.megaslider.Fields.RightHideOnDesktop"] = "Right Hide on Desktop",
                ["Plugin.nop4all.megaslider.Fields.RightHideOnDesktop.Hint"] = "Enable this option to hide the right zone on desktop devices.",

                ["Plugin.nop4all.megaslider.Fields.RightHideOnMobile"] = "Right Hide on Mobile",
                ["Plugin.nop4all.megaslider.Fields.RightHideOnMobile.Hint"] = "Enable this option to hide the right zone on mobile devices.",

                ["Plugin.nop4all.megaslider.Fields.RightImageAlt"] = "Right Image Alt Text",
                ["Plugin.nop4all.megaslider.Fields.RightImageAlt.Hint"] = "Enter alternative text for the right image (used for SEO and accessibility).",

                ["Plugin.nop4all.megaslider.Fields.RightOverlay"] = "Right Overlay",
                ["Plugin.nop4all.megaslider.Fields.RightOverlay.Hint"] = "Enable or configure an overlay on the right zone (e.g., dark/light overlay over image or color).",

                ["Plugin.nop4all.megaslider.Fields.RightColorpreset"] = "Right Color Preset",
                ["Plugin.nop4all.megaslider.Fields.RightColorpreset.Hint"] = "Select a predefined color preset for the right zone background.",

                ["Plugin.nop4all.megaslider.Fields.RightZoneType"] = "Right Zone Type",
                ["Plugin.nop4all.megaslider.Fields.RightZoneType.Hint"] = "Select the content type for the right zone (e.g., Image, Color, or Empty).",

                //Layout & Style
                ["Plugin.nop4all.megaslider.Fields.BackgroundType"] = "Background type",
                ["Plugin.nop4all.megaslider.Fields.BackgroundType.Hint"] = "select back ground type",

                ["Plugin.nop4all.megaslider.Fields.TextAlignment"] = "Alignment",
                ["Plugin.nop4all.megaslider.Fields.TextAlignment.Hint"] = "select alignment",

                ["Plugin.nop4all.megaslider.Fields.BlockStyle"] = "Block style",
                ["Plugin.nop4all.megaslider.Fields.BlockStyle.Hint"] = "select block style",

                ["Plugin.nop4all.megaslider.Fields.TextTheme"] = "Text theme",
                ["Plugin.nop4all.megaslider.Fields.TextTheme.Hint"] = "select text theme",

                ["Plugin.nop4all.megaslider.Fields.BackgroundColor"] = "Background color",
                ["Plugin.nop4all.megaslider.Fields.BackgroundColor.Hint"] = "selct back ground color",

                ["Plugin.nop4all.megaslider.Fields.BackgroundImageId"] = "Background image",
                ["Plugin.nop4all.megaslider.Fields.BackgroundImageId.Hint"] = "select back ground image",

                ["Plugin.nop4all.megaslider.Fields.BackgroundSize"] = "Background size",
                ["Plugin.nop4all.megaslider.Fields.BackgroundSize.Hint"] = "select back ground size",

                ["Plugin.nop4all.megaslider.Fields.BackgroundOverlay"] = "Background overlay",
                ["Plugin.nop4all.megaslider.Fields.BackgroundOverlay.Hint"] = "select back ground overlay",

                ["Plugin.nop4all.megaslider.Fields.Cardtheme"] = "Card Theme",
                ["Plugin.nop4all.megaslider.Fields.Cardtheme.Hint"] = "Select a predefined theme for the card (e.g., White, Dark).",

                ["Plugin.nop4all.megaslider.Fields.Cardbackgroundcolor"] = "Card Background Color",
                ["Plugin.nop4all.megaslider.Fields.Cardbackgroundcolor.Hint"] = "Select a background color for the card.",

                ["Plugin.nop4all.megaslider.Fields.BackgroundVideoUrl"] = "Background Video URL",
                ["Plugin.nop4all.megaslider.Fields.BackgroundVideoUrl.Hint"] = "Enter the URL of the background video to display in the slider (e.g., MP4 or YouTube link).",

                ["Plugin.nop4all.megaslider.Fields.BackgroundVideoTypeId"] = "Background Video Type",
                ["Plugin.nop4all.megaslider.Fields.BackgroundVideoTypeId.Hint"] = "Select the type of background video (e.g., uploaded video file or YouTube link).",

                //Validators

                //Content
                ["Plugin.nop4all.megamenu4all.Fields.BadgeImageIdErrorMsg"] = "Please select a badge image.",

                ["Plugin.nop4all.megaslider.Fields.LeftHideErrorMsg"] = "Left zone cannot be hidden on both mobile and desktop. It will not be visible on any device.",

                ["Plugin.nop4all.megaslider.Fields.RightHideErrorMsg"] = "Right zone cannot be hidden on both mobile and desktop. It will not be visible on any device.",

                ["Plugin.nop4all.megamenu4all.Fields.ContentErrorMsg"] = "At least one content (Content / Layer 1 / Layer 2) is required.",

                ["Plugin.nop4all.megamenu4all.Fields.CTAButton1TextErrorMsg"] = "CTA Button 1 text is required.",
                ["Plugin.nop4all.megamenu4all.Fields.CTAButton2TextErrorMsg"] = "CTA Button 2 text is required.",

                ["Plugin.nop4all.megamenu4all.Fields.CTAButton1RedirectUrlErrorMsg"] = "CTA Button 1 redirect URL is required.",
                ["Plugin.nop4all.megamenu4all.Fields.CTAButton2RedirectUrlErrorMsg"] = "CTA Button 2 redirect URL is required.",

                //LEFT
                ["Plugin.nop4all.megaslider.Fields.LeftImageIdErrorMsg"] = "Please select a left image.",
                ["Plugin.nop4all.megaslider.Fields.LeftImageLinkErrorMsg"] = "Please enter a valid left image link.",
                ["Plugin.nop4all.megaslider.Fields.LeftColorErrorMsg"] = "Please select a left background color.",
                ["Plugin.nop4all.megaslider.Fields.LeftEmptyErrorMsg"] = "No input is required for the left empty zone.",

                // RIGHT
                ["Plugin.nop4all.megaslider.Fields.RightImageIdErrorMsg"] = "Please select a right image.",
                ["Plugin.nop4all.megaslider.Fields.RightImageLinkErrorMsg"] = "Please enter a valid right image link.",
                ["Plugin.nop4all.megaslider.Fields.RightColorErrorMsg"] = "Please select a right background color.",
                ["Plugin.nop4all.megaslider.Fields.RightEmptyErrorMsg"] = "No input is required for the right empty zone.",


                ["Plugin.nop4all.megaslider.AnimationEffect"] = "Slider Effect",
                ["Plugin.nop4all.megaslider.AnimationEffect.Hint"] = "Select slider effect",

            });

            await base.InstallAsync();
        }

        /// <summary>
        /// Uninstall the plugin
        /// </summary>
        /// <returns>A task that represents the asynchronous operation</returns>
        public override async Task UninstallAsync()
        {
            //settings
            await _settingService.DeleteSettingAsync<MegasliderSettings>();

            await _localizationService.DeleteLocaleResourcesAsync("Plugin.nop4all.megaslider");

            await base.UninstallAsync();
        }
        #endregion

        #region Widgets

        /// <summary>
        /// Gets a value indicating whether to hide this plugin on the widget list page in the admin area
        /// </summary>
        public bool HideInWidgetList => false;


        #endregion
    }
}