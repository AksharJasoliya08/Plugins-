﻿using Nop.Services.Events;
using Nop.Services.Localization;
using Nop.Services.Security;
using Nop.Web.Framework.Events;
using Nop.Web.Framework.Menu;
using Nop.Web.Framework.Mvc.Filters;

namespace Nop.Plugin.nop4all.megaslider.Events
{
    /// <summary>
    /// Represents an event that occurs after admin menu created
    /// </summary>
    public class AdminMenuEventConsumer : IConsumer<AdminMenuCreatedEvent>
    {
        #region Fields
        protected readonly IPermissionService _permissionService;
        protected readonly ILocalizationService _localizationService;
        protected readonly IAdminMenu _adminMenu;
        #endregion  

        #region Ctor
        public AdminMenuEventConsumer(IPermissionService permissionService,
            ILocalizationService localizationService,
            IAdminMenu adminMenu)
        {
            _permissionService = permissionService;
            _localizationService = localizationService;
            _adminMenu = adminMenu;
        }
        #endregion

        #region Method

        /// <summary>
        /// Handle page rendering event
        /// </summary>
        /// <param name="eventMessage">Event message</param>
        /// <returns>A task that represents the asynchronous operation</returns>
        [CheckPermission(StandardPermission.Configuration.MANAGE_PLUGINS)]
        public async Task HandleEventAsync(AdminMenuCreatedEvent eventMessage)
        { 
            var pluginNode = eventMessage.RootMenuItem.ChildNodes.FirstOrDefault(x => x.SystemName == "nop4all");
            if (pluginNode == null)
            {
                eventMessage.RootMenuItem.ChildNodes.Add(new AdminMenuItem()
                {
                    SystemName = "nop4all",
                    Title = await _localizationService.GetResourceAsync("Plugin.nop4all.SiteMap.Nop4all"),
                    Visible = true,
                    IconClass = "fa fa-bars"
                });
                pluginNode = eventMessage.RootMenuItem.ChildNodes.FirstOrDefault(x => x.SystemName == "nop4all");
            }

            var pluginNodeChild = eventMessage.RootMenuItem.ChildNodes.FirstOrDefault(x => x.SystemName == "nop4all");
            var exist = pluginNodeChild.ChildNodes.FirstOrDefault(x => x.SystemName == "nop4allPlugin");
            if (exist == null && pluginNodeChild != null)
            {
                pluginNode.ChildNodes.Add(new AdminMenuItem()
                {
                    SystemName = "nop4allPlugin",
                    Title = await _localizationService.GetResourceAsync("Plugin.nop4all.SiteMap.Nop4all.Plugin"),
                    Visible = true,
                    IconClass = "fas fa-plug"
                });
                pluginNodeChild = pluginNode.ChildNodes.FirstOrDefault(x => x.SystemName == "nop4allPlugin");
            }
            else
            {
                pluginNodeChild = exist;
            }

            var pluginChildNode = pluginNode.ChildNodes.FirstOrDefault(x => x.SystemName == "nop4allPlugin");
            if (pluginChildNode != null)
            {
                pluginNodeChild.ChildNodes.Add(new AdminMenuItem()
                {
                    SystemName = "megaslider",
                    Title = await _localizationService.GetResourceAsync("Plugin.nop4all.megaslider.SiteMap.megaslider"),
                    Visible = true,
                    IconClass = "far fa-dot-circle"
                });
                pluginChildNode = pluginNodeChild.ChildNodes.FirstOrDefault(x => x.SystemName == "megaslider");
            }
             
            var megasliderConfigure = new AdminMenuItem()
            {
                SystemName = "megasliderConfigure",
                Title = await _localizationService.GetResourceAsync("Plugin.nop4all.megaslider.SiteMap.megasliderConfigure"),
                IconClass = "far fa-circle",
                Url = _adminMenu.GetMenuItemUrl("Megaslider", "Configure"),
                Visible = true,
            };

            var megasliderList = new AdminMenuItem()
            {
                SystemName = "megasliderList",
                Title = await _localizationService.GetResourceAsync("Plugin.nop4all.megaslider.SiteMap.megasliderList"),
                IconClass = "far fa-circle",
                Url = _adminMenu.GetMenuItemUrl("Megaslider", "GroupSliderList"),
                Visible = true,
            };

            var qTLanguageResource = new AdminMenuItem()
            {
                SystemName = "MSLanguageResource",
                Title = await _localizationService.GetResourceAsync("Plugin.nop4all.megaslider.SiteMap.MSLanguageResource"),
                IconClass = "far fa-circle",
                Url = _adminMenu.GetMenuItemUrl("Megaslider", "List"),
                Visible = true,
            };

            var megasliderHelp = new AdminMenuItem()
            {
                SystemName = "megasliderHelp",
                Title = await _localizationService.GetResourceAsync("Plugin.nop4all.megaslider.SiteMap.megasliderHelp"),
                IconClass = "far fa-circle",
                Url = "https://docs.nop4all.com/megaslider",
                Visible = true,
                OpenUrlInNewTab = true
            }; 

            pluginChildNode.ChildNodes.Add(megasliderConfigure); 
            pluginChildNode.ChildNodes.Add(megasliderList); 
            pluginChildNode.ChildNodes.Add(qTLanguageResource);
            pluginChildNode.ChildNodes.Add(megasliderHelp);
        }

        #endregion
    }
}