﻿using Nop.Core.Domain.Localization;
using Nop.Core.Events;
using Nop.Services.Events;
using Nop.Services.Localization;

namespace Nop.Plugin.nop4all.megaslider.Events
{
    /// <summary>
    /// Represents language event consumer
    /// </summary>
    public partial class LanguageEventConsumer : IConsumer<EntityInsertedEvent<Language>>
    {
        #region Fields
        protected readonly ILocalizationService _localizationService;
        #endregion

        #region Ctor
        public LanguageEventConsumer(ILocalizationService localizationService)
        {
            _localizationService = localizationService;
        }
        #endregion

        #region Methods
        /// <summary>
        /// Handle the add Language event
        /// </summary>
        /// <param name="eventMessage">The event message.</param>
        /// <returns>A task that represents the asynchronous operation</returns>
        public async Task HandleEventAsync(EntityInsertedEvent<Language> eventMessage)
        {
            var language = eventMessage.Entity;
            await _localizationService.AddOrUpdateLocaleResourceAsync(new Dictionary<string, string>
            {
                ["Plugin.nop4all.megaslider.Configure.Info"] = "Configure",
                ["Plugin.nop4all.megaslider.Configure.Slider.List"] = "Slider List",
                ["Plugin.nop4all.megaslider.Color"] = "Color",
                ["Plugin.nop4all.megaslider.Color.Hint"] = "Color",
                ["Plugin.nop4all.megaslider.Enable"] = "Enable",
                ["Plugin.nop4all.megaslider.Enable.Hint"] = "Enable",
                ["Plugin.nop4all.megaslider.Widgetzone"] = "Widget zone",
                ["Plugin.nop4all.megaslider.Widgetzone.Hint"] = "Select Widget zone",
                ["Plugin.nop4all.megaslider.LeftSide"] = "Slider Side",
                ["Plugin.nop4all.megaslider.LeftSide.Hint"] = "The slider is set to the right by default; check the checkbox to move it to the left",
                ["Plugin.nop4all.megaslider.RightSide"] = "RightSide",
                ["Plugin.nop4all.megaslider.RightSide.Hint"] = "RightSide",
                ["Plugin.nop4all.megaslider.Show"] = "Slider Visible?",
                ["Plugin.nop4all.megaslider.Show.Hint"] = "The slider is set to the Visible by default; Set the Redion button to Hide Slider",
                ["Plugin.nop4all.megaslider.Hide"] = "Hide",
                ["Plugin.nop4all.megaslider.Hide.Hint"] = "Hide",
                ["Plugin.nop4all.megaslider.Autoplay"] = "Content Delay",
                ["Plugin.nop4all.megaslider.Autoplay.Hint"] = "Set The Content Delay in Mili Second (2000 , 5000...)",
                ["Plugin.nop4all.megaslider.Name"] = "Slider Name",
                ["Plugin.nop4all.megaslider.Name.Hint"] = "Slider Name",
                ["Plugin.nop4all.megaslider.ContentType"] = "Content Type",
                ["Plugin.nop4all.megaslider.ContentType.Hint"] = "The Content is set to the Product by default; Set the Redion button To Show Content Layer(Add Text and Image Etc...)",
                ["Plugin.nop4all.megaslider.DisplayOrder"] = "Display Order",
                ["Plugin.nop4all.megaslider.DisplayOrder.Hint"] = "Display Order",
                ["Plugin.nop4all.megaslider.Content"] = "Content",
                ["Plugin.nop4all.megaslider.Content.Hint"] = "Content",
                ["Plugin.nop4all.megaslider.AddNewSlider"] = "AddNew Slider",
                ["Plugin.nop4all.megaslider.AddNew"] = "AddNew",
                ["Plugin.nop4all.megaslider.BackToList"] = "BackToList",
                ["Plugin.nop4all.megaslider.Slider.Info"] = "Slider Info",
                ["Plugin.nop4all.megaslider.FeatureProducts"] = "Feature Products",
                ["Plugin.nop4all.megaslider.NewProducts"] = "NewProducts",
                ["Plugin.nop4all.megaslider.FeatureProducts.AddNew"] = "AddNew",
                ["Plugin.nop4all.megaslider.NewProducts.AddNew"] = "AddNew",
                ["Plugin.nop4all.megaslider.Slider"] = "Slider",
                ["fantastic.newproduct"] = "New",
                ["Plugin.nop4all.megaslider.ContentLayer"] = "Content Layer",
                ["Plugin.nop4all.megaslider.ContentLayer3"] = "Content Layer Third",
                ["Pugin.nop4all.megaslider.selectedstoreids.Hint"] = "Selected Store Name",
                ["Plugin.nop4all.megaslider.SelectedStoreIds"] = "Limited to stores",
                ["Plugin.nop4all.megaslider.SelectedStoreIds.Hint"] = "Select to stores",
                ["Plugin.nop4all.megaslider.ContentLayer.Hint"] = "Content Layer",
                ["Plugin.nop4all.megaslider.ContentLayer3.Hint"] = "Content Layer Third",
                ["Plugin.nop4all.megaslider.ProductAutoplay"] = "Content Item Delay",
                ["Plugin.nop4all.megaslider.ProductAutoplay.Hint"] = "Set The Content Delay in Mili Second (2000 , 5000...)",
                ["Plugin.nop4all.megaslider.Fields.QuickEdit"] = "QuickEdit",
                ["Plugin.nop4all.megaslider.Fields.Enable"] = "Enable",
                ["Plugin.nop4all.megaslider.IncludeTop"] = "Include In Top",
                ["Plugin.nop4all.megaslider.IncludeTop.Hint"] = "Include In Setting WigdetZone",
                ["plugin.nop4all.megaslider.group.slider.info"] = "Group-Slider",
                ["plugin.nop4all.megaslider.edit"] = "Edit",
                ["plugin.nop4all.megaslider.contentitemdelay"] = "ContentItem Delay",
                ["plugin.nop4all.megaslider.contentitemdelay.Hint"] = "Enter for ContentItem Delay",
                ["plugin.nop4all.megaslider.contentdelay"] = " Content Delay",
                ["plugin.nop4all.megaslider.contentdelay.Hint"] = "Enter for Content Delay",
                ["plugin.nop4all.megamenu4all.fields.configuremegamenu.addnew"] = "Add New Menu Group",
                ["plugin.nop4all.megaslider.featuredproducteffect"] = "FeatureProduct Effect",
                ["plugin.nop4all.megaslider.featuredproducteffect.Hint"] = "Select Effect for FeatureProduct ",
                ["plugin.nop4all.megaslider.SellProductModelEffect"] = "Sell Product Model Effect",
                ["plugin.nop4all.megaslider.SellProductModelEffect.Hint"] = "Sell Product Model Effect",
                ["plugin.nop4all.megaslider.newproductseffect"] = "Select Effect for NewProduct ",
                ["plugin.nop4all.megaslider.newproductseffect.Hint"] = "Select Effect for NewProduct ",
                ["plugin.nop4all.megaslider.Texttransitions"] = "Text transitions",
                ["plugin.nop4all.megaslider.Texttransitions.Hint"] = "Text transitions",

                ["Plugin.nop4all.megaslider.Slider.BasicInfo"] = "Basic Info",
                ["Plugin.nop4all.megaslider.Slider.ContentInfo"] = "Content Info",
                ["Plugin.nop4all.megaslider.Slider.StoreMapping"] = "Store Mapping",
                ["plugin.nop4all.megaslider.sellproducts"] = "Sell Products",

                //sitemap 
                ["Plugin.nop4all.SiteMap.Nop4all"] = "Nop4All",
                ["Plugin.nop4all.SiteMap.Nop4all.Plugin"] = "Plugins",
                ["Plugin.nop4all.megaslider.SiteMap.megaslider"] = "Mega Slider",
                ["Plugin.nop4all.megaslider.SiteMap.MegaSliderConfigure"] = "Settings",
                ["Plugin.nop4all.megaslider.SiteMap.MegaSliderHelp"] = "Help",
                ["Plugin.nop4all.megaslider.SiteMap.MSLanguageResource"] = "Language Resource",
                ["Plugin.nop4all.megaslider.MSLanguageResource.List"] = "Language Resource",
                ["Plugin.nop4all.megaslider.MSLanguageResource.List.Instructions"] = "Don't change 'Plugin.nop4all.megaslider' prefix.",
                ["Plugin.nop4all.megaslider.fields.ResourceName"] = "Resource Name",
                ["Plugin.nop4all.megaslider.fields.ResourceName.Value"] = "Value",
                ["Plugin.nop4all.megaslider.Methods.Configure"] = "Settings",
                ["Plugin.nop4all.megaslider.Save"] = "Slider has been created successfully.",
                ["Plugin.nop4all.megaslider.update"] = "Slider has been updated successfully.",
                ["Plugin.nop4all.megaslider.sliderdots"] = "Slider Dots",
                ["Plugin.nop4all.megaslider.sliderdots.Hint"] = "Slider Dots",
                ["Plugin.nop4all.megaslider.sliderarrow"] = "Slider Arrow",
                ["Plugin.nop4all.megaslider.sliderarrow.Hint"] = "Slider Arrow",
                ["Nop.Plugin.nop4all.megaslider.Fields.SelectEffect"] = "--Select--",
                ["Plugin.nop4all.megaslider.Menu"] = "Menu Type",
                ["Plugin.nop4all.megaslider.Menu.Hint"] = "Select the menu type where the Mega Slider will be displayed.",


                //new for conditions
                ["plugin.nop4all.megaslider.groupslider.conditions"] = "Group Slider Conditions",
                ["plugin.nop4all.megaslider.groupmegaslider.conditions.addnew"] = "Add New",
                ["plugin.nop4all.megaslider.fields.conditiontype"] = "Condition Type",
                ["plugin.nop4all.megaslider.fields.property"] = "Property",
                ["plugin.nop4all.megaslider.fields.operator"] = "Operator",
                ["plugin.nop4all.megaslider.fields.value"] = "Value",
                ["plugin.nop4all.megaslider.megamenu.conditions.title"] = "Conditions",
                ["Plugin.nop4all.megaslider.Fields.WidgetZone"] = "WidgetZone",

                ["plugin.nop4all.megaslider.SliderDelay"] = "SliderDelay",
                ["plugin.nop4all.megaslider.TransitionEffectDelay"] = "Transition Effect Delay",
                ["plugin.nop4all.megaslider.positioning"] = "Positioning",

                ["plugin.nop4all.megaslider.ProductSliderDots"] = "Product Slider Dots",
                ["plugin.nop4all.megaslider.ProductSliderDots.Hint"] = "Enable or disable dots for the product slider",
                ["plugin.nop4all.megaslider.ProductSliderArrows"] = "Product Slider Arrows",
                ["plugin.nop4all.megaslider.ProductSliderArrows.Hint"] = "Enable or disable arrows for the product slider",
                ["plugin.nop4all.megaslider.MainSliderDots"] = "Main Slider Dots",
                ["plugin.nop4all.megaslider.MainSliderDots.Hint"] = "Enable or disable dots for the main slider",
                ["plugin.nop4all.megaslider.MainSliderArrows"] = "Main Slider Arrows",
                ["plugin.nop4all.megaslider.MainSliderArrows.Hint"] = "Enable or disable arrows for the main slider",
                ["plugin.nop4all.megaslider.sliderheight"] = "Slider Height",
                ["plugin.nop4all.megaslider.sliderheight.Hint"] = "Enter slider height in px, %, vh, or auto",
                ["plugin.nop4all.megaslider.SellProductModelEffect"] = "Sell Product Model Effect",
                ["plugin.nop4all.megaslider.SellProductModelEffect.Hint"] = "Enable or disable sell product model animation effect",
                ["plugin.nop4all.megaslider.Newproductdropdown"] = "New Product Position",
                ["plugin.nop4all.megaslider.Newproductdropdown.Hint"] = "Select the position for new product display (topright, topleft, bottomright, bottomleft)",

                ["plugin.nop4all.megaslider.title"] = "Slider Title",
                ["plugin.nop4all.megaslider.title.Hint"] = "Enter the title text for the slider.",
                ["plugin.nop4all.megaslider.shortdescription"] = "Slider Description",
                ["plugin.nop4all.megaslider.shortdescription.Hint"] = "Enter a short description to display on the slider.",
                ["plugin.nop4all.megaslider.titlefontsize"] = "Title Font Size",
                ["plugin.nop4all.megaslider.titlefontsize.Hint"] = "Enter the font size in px for the slider title (e.g., 24).",
                ["plugin.nop4all.megaslider.descriptionfontsize"] = "Description Font Size",
                ["plugin.nop4all.megaslider.descriptionfontsize.Hint"] = "Enter the font size in px for the slider description (e.g., 16).",
                ["plugin.nop4all.megaslider.contentlayerpositionssecond"] = "Content Layer Positions Second",
                ["plugin.nop4all.megaslider.contentlayerpositions"] = "Content Layer Positions",
                ["plugin.nop4all.megaslider.contentlayerpositionsthird"] = "Content Layer Positions Third",
                ["plugin.nop4all.megaslider.contentlayerpositionssecond.Hint"] = "Content Layer Positions Second",
                ["plugin.nop4all.megaslider.contentlayerpositionsthird.Hint"] = "Content Layer Positions Third",
                ["plugin.nop4all.megaslider.contentlayerpositions.Hint"] = "Content Layer Positions",

                ["Plugin.nop4all.megaslider.Fields.CTAButton1IsVisible"] = "CTA Button 1 Visible",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1IsVisible.Hint"] = "Enable this option to display CTA Button 1 on the slider.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1Text"] = "CTA Button 1 Text",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1Text.Hint"] = "Enter the text that will appear on CTA Button 1. This field supports multiple languages.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1Style"] = "CTA Button 1 Style",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1Style.Hint"] = "Select the visual style for CTA Button 1.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1BackgroundColor"] = "CTA Button 1 Background Color",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1BackgroundColor.Hint"] = "Choose the background color for CTA Button 1.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1TextColor"] = "CTA Button 1 Text Color",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1TextColor.Hint"] = "Choose the text color for CTA Button 1.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1RedirectUrl"] = "CTA Button 1 Redirect URL",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1RedirectUrl.Hint"] = "Enter the URL where users will be redirected after clicking CTA Button 1. This field supports multiple languages.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2IsVisible"] = "CTA Button 2 Visible",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2IsVisible.Hint"] = "Enable this option to display CTA Button 2 on the slider.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2Text"] = "CTA Button 2 Text",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2Text.Hint"] = "Enter the text that will appear on CTA Button 2. This field supports multiple languages.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2Style"] = "CTA Button 2 Style",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2Style.Hint"] = "Select the visual style for CTA Button 2.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2BackgroundColor"] = "CTA Button 2 Background Color",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2BackgroundColor.Hint"] = "Choose the background color for CTA Button 2.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2TextColor"] = "CTA Button 2 Text Color",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2TextColor.Hint"] = "Choose the text color for CTA Button 2.",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2RedirectUrl"] = "CTA Button 2 Redirect URL",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2RedirectUrl.Hint"] = "Enter the URL where users will be redirected after clicking CTA Button 2. This field supports multiple languages.",
                ["Plugin.nop4all.megaslider.CTAButton1"] = "CTA Button 1 Settings",
                ["Plugin.nop4all.megaslider.CTAButton2"] = "CTA Button 2 Settings",


                ["Plugin.nop4all.megaslider.Fields.CTAButton1FontSize"] = "CTA Button 1 Font Size",
                ["Plugin.nop4all.megaslider.Fields.CTAButton1FontSize.Hint"] = "Enter the font size for CTA Button 1 (for example: 14px, 16px).",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2FontSize"] = "CTA Button 2 Font Size",
                ["Plugin.nop4all.megaslider.Fields.CTAButton2FontSize.Hint"] = "Enter the font size for CTA Button 2 (for example: 14px, 16px).",

                //Add new
                ["Plugin.nop4all.megaslider.HtmlContent"] = "Html Content",
                ["Plugin.nop4all.megaslider.HtmlContent.Hint"] = "Html Content",

                ["plugin.nop4all.megaslider.AllowRepeatAnimation"] = "Allow Repeat Animation",
                ["plugin.nop4all.megaslider.AllowRepeatAnimation.Hint"] = "Check to enable the animation to repeat continuously.",

            }, language.Id);
        }
        #endregion
    }
}