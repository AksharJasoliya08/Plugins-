using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.nop4all.megaslider.Domain;
using Nop.Plugin.nop4all.megaslider.Model;
using Nop.Plugin.nop4all.megaslider.Model.Slider;
using Nop.Plugin.nop4all.megaslider.Services;
using Nop.Services.Catalog;
using Nop.Services.Localization;
using Nop.Services.Stores;
using Nop.Web.Factories;
using Nop.Web.Framework.Components;
using Nop.Services.Media;
using Nop.Services.Configuration;
using NUglify.Helpers;

namespace Nop.Plugin.nop4all.megaslider.Components
{
    /// <summary>
    /// Represents view component to slider condition
    /// </summary>
    public class SliderConditionViewComponent : NopViewComponent
    {
        protected readonly IMegasliderServices _megasliderServices;
        protected readonly IConditionService _conditionService;
        protected readonly IProductService _productServices;
        protected readonly IProductModelFactory _productModelFactory;
        protected readonly IStoreContext _storeContext;
        protected readonly IStoreMappingService _storeMappingService;
        protected readonly ILocalizationService _localizationService;
        protected readonly IPictureService _pictureService;
        protected readonly ISettingService _settingService;

        #region Ctor
        public SliderConditionViewComponent(
            IMegasliderServices megasliderServices,
            IConditionService conditionService,
            IProductService productServices,
            IProductModelFactory productModelFactory,
            IStoreContext storeContext,
            IStoreMappingService storeMappingService,
            ILocalizationService localizationService,
            IPictureService pictureService,
            ISettingService settingService)
        {
            _megasliderServices = megasliderServices;
            _conditionService = conditionService;
            _productServices = productServices;
            _productModelFactory = productModelFactory;
            _storeContext = storeContext;
            _storeMappingService = storeMappingService;
            _localizationService = localizationService;
            _pictureService = pictureService;
            _settingService = settingService;
        }
        #endregion

        #region Methods
        /// <summary>
        /// Invoke view component
        /// </summary>
        /// <param name="widgetZone">Widget zone name</param>
        /// <param name="additionalData">Additional data</param>
        /// <returns>View component result</returns>
        public async Task<IViewComponentResult> InvokeAsync(string widgetZone, object additionalData)
        {
            // Detect current page type & value
            var storeScope = await _storeContext.GetCurrentStoreAsync();
            var megasliderSettings = await _settingService.LoadSettingAsync<MegasliderSettings>(storeScope.Id);

            var route = HttpContext.Request.RouteValues;

            string conditionType = "";
            string currentValue = "";

            if (route.ContainsKey("topicId"))
            {
                conditionType = ConditionType.Topic.ToString();
                currentValue = route["topicId"]?.ToString();
            }
            else if (route.ContainsKey("blogPostId"))
            {
                conditionType = ConditionType.Blog.ToString();
                currentValue = route["blogPostId"]?.ToString();
            }
            else if (route.ContainsKey("categoryId"))
            {
                conditionType = ConditionType.Category.ToString();
                currentValue = route["categoryId"]?.ToString();
            }
            else if (route.ContainsKey("productId"))
            {
                conditionType = ConditionType.Product.ToString();
                currentValue = route["productId"]?.ToString();
            }
            else if (route.ContainsKey("manufacturerId"))
            {
                conditionType = ConditionType.Manufacturer.ToString();
                currentValue = route["manufacturerId"]?.ToString();
            }
            else if (additionalData != null)
            {
                var idProperty = additionalData.GetType().GetProperty("Id");

                if (idProperty != null)
                {
                    var idValue = idProperty.GetValue(additionalData);

                    if (idValue != null && Convert.ToInt32(idValue) > 0)
                    {
                        conditionType = ConditionType.Casestudy.ToString();
                        currentValue = idValue.ToString();
                    }
                }
            }

            if (string.IsNullOrEmpty(conditionType))
           
                return Content(string.Empty);

            // Load enabled groups
            var currentStore = await _storeContext.GetCurrentStoreAsync();

            var allGroups = (await _megasliderServices.GetAllGroupSlidersAsync(null, true))
                .Where(g => g.Enable)
                .OrderBy(g => g.DisplayOrder)
                .ToList();

            if (!allGroups.Any())
                return Content(string.Empty);

            var result = new List<GroupSliderModel>();

            foreach (var group in allGroups)
            {
                var mergedSliders = new List<MegaSlider>();

                // Get conditions for THIS GROUP ID
                var groupConditions =
                    await _conditionService.GetMenuConditionByMenuIdAsync(group.Id);

                bool allowGroup = false;

                foreach (var condition in groupConditions)
                {
                    if (!string.Equals(condition.WidgetZone, widgetZone, StringComparison.OrdinalIgnoreCase))
                        continue;

                    if (!string.Equals(condition.ConditionType, conditionType, StringComparison.OrdinalIgnoreCase))
                        continue;

                    // EqualTo
                    if (condition.Oprater == (int)OperatorType.EqualTo &&
                        condition.Value == currentValue)
                    {
                        allowGroup = true;
                        break;
                    }

                    // NotEqualTo
                    if (condition.Oprater == (int)OperatorType.NotEqualTo &&
                        condition.Value != currentValue)
                    {
                        allowGroup = true;
                        break;
                    }
                }

                if (!allowGroup)
                    continue;

                var groupSliders =
                    await _megasliderServices.GetAllSliderByGroupIdAsync(group.Id, 0, int.MaxValue);

                foreach (var slider in groupSliders.Where(s => s.Enable))
                {
                    mergedSliders.Add(slider);
                }

                mergedSliders = mergedSliders
                    .GroupBy(s => s.Id)
                    .Select(g => g.First())
                    .OrderBy(s => s.DisplayOrder)
                    .ToList();

                if (!mergedSliders.Any())
                    continue;

                var model = new GroupSliderModel
                {
                    RightSide = group.RightSide,
                    LeftSide = group.LeftSide,
                    Show = group.Show,
                    Hide = group.Hide,
                    DotArrrow = group.DotArrrow,
                    Menu = group.Menu
                };

                foreach (var item in mergedSliders)
                {
                    if (item.LimitedToStores &&
                        !await _storeMappingService.AuthorizeAsync(item, currentStore.Id))
                        continue;

                    bool comonheight = false;

                    var groupDetailsbysliderID = await _megasliderServices.GetGroupBySliderIdAsync(item.Id);
                    var groupdetails = await _megasliderServices.GetSliderGroupByIdAsync(groupDetailsbysliderID.GroupSliderId);

                    // height logic
                    if ((item.IncludeTop) && (groupdetails.Widgetzone == widgetZone))
                    {
                        //model.GroupSliderHeight = megasliderSettings.SliderHeight; // group top height
                        comonheight = true;
                    }
                    else
                    {
                        comonheight = false;
                    }

                    var sliderModel = new SliderModel
                    {
                        Id = item.Id,
                        Name = item.Name,
                        ContentType = item.ContentType,
                        HtmlContent = await _localizationService.GetLocalizedAsync(item, x => x.HtmlContent),
                        Title = await _localizationService.GetLocalizedAsync(item, x => x.Title),
                        ShortDescription = await _localizationService.GetLocalizedAsync(item, x => x.ShortDescription),
                        WidgetZone = item.WidgetZone,
                        Enable = item.Enable,
                        IncludeTop = item.IncludeTop,
                        NewProductseffect = item.NewProductseffect,
                        FeaturedProductEffect = item.FeaturedProductEffect,
                        SellProductModelEffect = item.SellProductModelEffect,
                        SliderArrows = item.ProductSliderArrows,
                        SliderDots = item.ProductSliderDots,
                        SliderDelay = item.SliderDelay > 0 ? item.SliderDelay : 5000,
                        Positionings = ((Positioning)item.Positioning).ToString(),
                        Positioning = item.Positioning,

                        //CTA Button 
                        CTAButton1IsVisible = item.CTAButton1IsVisible,
                        CTAButton1Text = await _localizationService.GetLocalizedAsync(item, x => x.CTAButton1Text),
                        CTAButton1StyleId = item.CTAButton1StyleId,
                        CTAButton1StyleIds = ((SliderCTAButtonStyleEnum)item.CTAButton1StyleId).ToString(),
                        CTAButton2StyleIds = ((SliderCTAButtonStyleEnum)item.CTAButton2StyleId).ToString(),
                        CTAButton1BackgroundColor = item.CTAButton1BackgroundColor,
                        CTAButton1TextColor = item.CTAButton1TextColor,
                        CTAButton1FontSize = item.CTAButton1FontSize,
                        CTAButton1RedirectUrl = await _localizationService.GetLocalizedAsync(item, x => x.CTAButton1RedirectUrl),
                        CTAButton2IsVisible = item.CTAButton2IsVisible,
                        CTAButton2Text = await _localizationService.GetLocalizedAsync(item, x => x.CTAButton2Text),
                        CTAButton2StyleId = item.CTAButton2StyleId,
                        CTAButton2BackgroundColor = item.CTAButton2BackgroundColor,
                        CTAButton2TextColor = item.CTAButton2TextColor,
                        CTAButton2FontSize = item.CTAButton2FontSize,
                        CTAButton2RedirectUrl = await _localizationService.GetLocalizedAsync(item, x => x.CTAButton2RedirectUrl),
                        
                        GroupHight = ((comonheight == true) ? megasliderSettings.SliderHeight : groupdetails.GroupSliderHeight),

                        //Content model
                        BadgeText = await _localizationService.GetLocalizedAsync(item, x => x.BadgeText),
                        BadgeImageId = item.BadgeImageId,
                        PriceText = await _localizationService.GetLocalizedAsync(item, x => x.PriceText),
                        SlideAltDescription = await _localizationService.GetLocalizedAsync(item, x => x.SlideAltDescription),
                        Cta1OpenInNewTab = item.Cta1OpenInNewTab,
                        Cta2OpenInNewTab = item.Cta2OpenInNewTab,

                        //Zone mode
                        ZoneType = item.ZoneType,

                        // Left Zone
                        LeftImageId = item.LeftImageId,
                        LeftImageLink = item.LeftImageLink,
                        LeftColor = item.LeftColor,
                        LeftEmpty = item.LeftEmpty,
                        LeftOpenInNewTab = item.LeftOpenInNewTab,
                        LeftHideOnDesktop = item.LeftHideOnDesktop,
                        LeftHideOnMobile = item.LeftHideOnMobile,
                        LeftImageAlt = item.LeftImageAlt,
                        LeftOverlay = item.LeftOverlay,
                        LeftOverlays = ((OverlayType)item.LeftOverlay).ToString(),
                        LeftColorpreset = item.LeftColorpreset,
                        LeftColorpresets = ((ColorPresetType)item.LeftColorpreset).ToString(),
                        LeftZoneType = item.LeftZoneType,
                        LeftZoneTypes = ((ZoneTypeEnum)item.LeftZoneType).ToString(),

                        // Right Zone
                        RightImageId = item.RightImageId,
                        RightImageLink = item.RightImageLink,
                        RightColor = item.RightColor,
                        RightEmpty = item.RightEmpty,
                        RightOpenInNewTab = item.RightOpenInNewTab,
                        RightHideOnDesktop = item.RightHideOnDesktop,
                        RightHideOnMobile = item.RightHideOnMobile,
                        RightImageAlt = item.RightImageAlt,
                        RightOverlay = item.RightOverlay,
                        RightOverlays = ((OverlayType)item.RightOverlay).ToString(),
                        RightColorpreset = item.RightColorpreset,
                        RightColorpresets = ((ColorPresetType)item.RightColorpreset).ToString(),
                        RightZoneType = item.RightZoneType,
                        RightZoneTypes = ((ZoneTypeEnum)item.RightZoneType).ToString(),

                        // layout model
                        TextBlockOffset = item.TextBlockOffset,
                        Top = item.Top,
                        Right = item.Right,
                        Bottom = item.Bottom,
                        Left = item.Left,
                        TextBlockPosition = item.TextBlockPosition,
                        TextBlockPositions = ((TextBlockPositionenum)item.TextBlockPosition).ToString(),
                        ContentSpacing = item.ContentSpacing,
                        ContentSpacings = ((ContentSpacingenum)item.ContentSpacing).ToString(),
                        Cardtheme = item.Cardtheme,
                        Cardthemes = ((CardTheme)item.Cardtheme).ToString(),
                        Cardbackgroundcolor = item.Cardbackgroundcolor,

                        BackgroundType = item.BackgroundType,
                        BackgroundColor = item.BackgroundColor,
                        BackgroundImageId = item.BackgroundImageId,
                        BackgroundSize = item.BackgroundSize,  // int value
                        BackgroundSizes = ((BackgroundSizeEnum)item.BackgroundSize).ToString(), // string value
                        BackgroundOverlay = item.BackgroundOverlay,
                        BackgroundOverlays = ((OverlayType)item.BackgroundOverlay).ToString(),
                        TextAlignment = item.TextAlignment,
                        TextAlignments = ((TextAlignmentEnum)item.TextAlignment).ToString(),
                        BlockStyle = item.BlockStyle,
                        BlockStyles = ((BlockStyleEnum)item.BlockStyle).ToString(),
                        TextTheme = item.TextTheme,
                        TextThemes = ((TextThemeEnum)item.TextTheme).ToString(),
                        TitleFontSize = item.TitleFontSize,
                        TitleFontSizes = ((TitleFontSizeEnum)item.TitleFontSize).ToString(),

                        //new
                        BackgroundVideoUrl = item.BackgroundVideoUrl,
                        BackgroundVideoTypeId = item.BackgroundVideoTypeId,
                        IsAutoPlay = item.IsAutoPlay,
                        UseNaturalVideoSizeOnMobile = item.UseNaturalVideoSizeOnMobile,

                        //Client remove code
                        //Content = await _localizationService.GetLocalizedAsync(item, x => x.Content),
                        //ContentLayer = await _localizationService.GetLocalizedAsync(item, x => x.ContentLayer),
                        //ContentLayer3 = await _localizationService.GetLocalizedAsync(item, x => x.ContentLayer3),
                        //TitleFontSize = item.TitleFontSize,
                        //DescriptionFontSize = item.DescriptionFontSize,
                        //Texttransitions = item.Texttransitions,
                        //TransitionEffectDelay = item.TransitionEffectDelay,
                        //ContentLayerPositions = (int)item.ContentLayerPositions,
                        //ContentLayerPositionsSecond = (int)item.ContentLayerPositionsSecond,
                        //ContentLayerPositionsThird = (int)item.ContentLayerPositionsThird,
                        //AllowRepeatAnimation = item.AllowRepeatAnimation,
                    };

                    // Featured Products
                    var featuredProducts =
                        await _megasliderServices.GetAllFeturechedProductBySliderIdAsync(item.Id);

                    var featuredIds = featuredProducts.Select(x => x.ProductId).Distinct().ToArray();
                    var featuredList = await _productServices.GetProductsByIdsAsync(featuredIds);

                    sliderModel.ProductOverviewModel =
                        (await _productModelFactory
                            .PrepareProductOverviewModelsAsync(featuredList, true, true))
                        .ToList();

                    // New Products
                    var newProducts =
                        await _megasliderServices.GetAllNewProductBySliderIdAsync(item.Id);

                    var newIds = newProducts.Select(x => x.ProductId).Distinct().ToArray();
                    var newList = await _productServices.GetProductsByIdsAsync(newIds);

                    sliderModel.NewProductOverviewModel =
                        (await _productModelFactory
                            .PrepareProductOverviewModelsAsync(newList, true, true))
                        .ToList();


                    //Extract banner image URLs from newProducts.PictureId
                    var bannerImageUrls = new List<string>();
                    foreach (var newProduct in newProducts)
                    {
                        if (newProduct.PictureId > 0)
                        {
                            var picture = await _pictureService.GetPictureByIdAsync(newProduct.PictureId);
                            if (picture != null)
                            {
                                var pictureUrlResult = await _pictureService.GetPictureUrlAsync(picture);
                                bannerImageUrls.Add(pictureUrlResult.Url);
                            }
                        }
                    }

                    //Store banner image URLs in the model
                    sliderModel.BannerImageUrls = bannerImageUrls;
                    model.SliderModel.Add(sliderModel);
                }

                result.Add(model);
            }

            if (!result.Any())
                return Content(string.Empty);

            return View("~/Plugins/nop4all.megaslider/Views/SliderWrapper.cshtml", result);
        }

        #endregion
    }
}