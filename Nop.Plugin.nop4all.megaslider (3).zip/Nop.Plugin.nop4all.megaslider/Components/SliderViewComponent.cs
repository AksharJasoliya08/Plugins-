﻿using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.nop4all.megaslider.Domain;
using Nop.Plugin.nop4all.megaslider.Model;
using Nop.Plugin.nop4all.megaslider.Model.Slider;
using Nop.Plugin.nop4all.megaslider.Services;
using Nop.Services.Catalog;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Media;
using Nop.Services.Stores;
using Nop.Web.Factories;
using Nop.Web.Framework.Components;

namespace Nop.Plugin.nop4all.megaslider.Components
{
    /// <summary>
    /// Represents view component to Slider View
    /// </summary>
    public class SliderViewComponent : NopViewComponent
    {
        #region Fields
        protected readonly IMegasliderServices _megasliderServices;
        protected readonly IProductService _productServices;
        protected readonly IProductModelFactory _productModelFactory;
        protected readonly IStoreContext _storeContext;
        protected readonly ISettingService _settingService;
        protected readonly IStoreMappingService _storeMappingService;
        protected readonly ILocalizationService _localizationService;
        protected readonly IPictureService _pictureService;
        #endregion

        #region Ctor
        public SliderViewComponent(
            IMegasliderServices megasliderServices,
            IProductService productServices,
            IProductModelFactory productModelFactory,
            IStoreContext storeContext,
            ISettingService settingService,
            IStoreMappingService storeMappingService,
            ILocalizationService localizationService,
            IPictureService pictureService)
        {
            _megasliderServices = megasliderServices;
            _productServices = productServices;
            _productModelFactory = productModelFactory;
            _storeContext = storeContext;
            _settingService = settingService;
            _storeMappingService = storeMappingService;
            _localizationService = localizationService;
            _pictureService = pictureService;
        }
        #endregion

        #region Methods
        /// <summary>
        /// Invoke view component
        /// </summary>
        /// <param name="widgetZone">Widget zone name</param>
        /// <param name="additionalData">Additional data</param>
        /// <returns>View component result</returns>
        public async Task<IViewComponentResult> InvokeAsync(string widgetZone, object additionalData)
        {
            var storeScope = await _storeContext.GetCurrentStoreAsync();
            var megasliderSettings = await _settingService.LoadSettingAsync<MegasliderSettings>(storeScope.Id);

            var currentStore = await _storeContext.GetCurrentStoreAsync();
            var allGroups = (await _megasliderServices.GetAllGroupSlidersAsync(null, true))
                .Where(g => g.Enable)
                .OrderBy(g => g.DisplayOrder)
                .ToList();

            if (!allGroups.Any())
                return Content(string.Empty);

            var result = new List<GroupSliderModel>();
            var groupsByMenu = allGroups.GroupBy(g => g.Menu);

            foreach (var menuGroup in groupsByMenu)
            {
                var mergedSliders = new List<MegaSlider>();
                var firstGroup = menuGroup.First();

                foreach (var group in menuGroup)
                {
                    var groupSliders = await _megasliderServices.GetAllSliderByGroupIdAsync(group.Id, 0, int.MaxValue);

                    foreach (var slider in groupSliders.Where(s => s.Enable))
                    {
                        bool show = (group.Widgetzone == widgetZone);

                        if (!show)
                            continue;

                        mergedSliders.Add(slider);
                    }
                }

                mergedSliders = mergedSliders
                    .GroupBy(s => s.Id)
                    .Select(g => g.First())
                    .OrderBy(s => s.DisplayOrder)
                    .ToList();

                if (!mergedSliders.Any())
                    continue;

                var model = new GroupSliderModel
                {
                    RightSide = firstGroup.RightSide,
                    LeftSide = firstGroup.LeftSide,
                    Show = firstGroup.Show,
                    Hide = firstGroup.Hide,
                    DotArrrow = firstGroup.DotArrrow,
                    Menu = firstGroup.Menu,
                    GroupSliderHeight = firstGroup.GroupSliderHeight,
                    SliderModel = new List<SliderModel>()
                };

                foreach (var item in mergedSliders)
                {
                    if (item.LimitedToStores &&
                        !await _storeMappingService.AuthorizeAsync(item, currentStore.Id))
                        continue;

                    bool comonheight = false;

                    var groupDetailsbysliderID = await _megasliderServices.GetGroupBySliderIdAsync(item.Id);
                    var groupdetails = await _megasliderServices.GetSliderGroupByIdAsync(groupDetailsbysliderID.GroupSliderId);
                    string animationEffectName = Enum.GetName(typeof(SliderAnimationEffect), groupdetails.AnimationEffectId);
                    string groupTransitionEffect = Enum.GetName(typeof(GroupTransitionEffect), groupdetails.TransitionAnimationEffectId);
                    //// height logic
                    //if ((item.IncludeTop) && (groupdetails.Widgetzone == widgetZone))
                    //{
                    //     comonheight = true;
                    //}
                    //else  
                    //{
                    //    model.GroupSliderHeight = firstGroup.GroupSliderHeight;  
                    //} 

                    var bannerImageUrls = new List<string>();

                    var sliderModel = new SliderModel
                    {
                        Id = item.Id,
                        Name = item.Name,

                        //Add New
                        ContentType = item.ContentType,
                        HtmlContent = await _localizationService.GetLocalizedAsync(item, x => x.HtmlContent),
                        Title = await _localizationService.GetLocalizedAsync(item, x => x.Title),
                        ShortDescription = await _localizationService.GetLocalizedAsync(item, x => x.ShortDescription),
                        WidgetZone = item.WidgetZone,
                        Enable = item.Enable,
                        IncludeTop = item.IncludeTop,
                        NewProductseffect = item.NewProductseffect,
                        FeaturedProductEffect = item.FeaturedProductEffect,
                        SellProductModelEffect = item.SellProductModelEffect,
                        SliderArrows = item.ProductSliderArrows,
                        SliderDots = item.ProductSliderDots,
                        SliderDelay = item.SliderDelay > 0 ? item.SliderDelay : 5000,
                        Positionings = ((Positioning)item.Positioning).ToString(),
                        Positioning = item.Positioning,

                        //CTA Button
                        CTAButton1IsVisible = item.CTAButton1IsVisible,
                        CTAButton1Text = await _localizationService.GetLocalizedAsync(item, x => x.CTAButton1Text),
                        CTAButton1StyleId = item.CTAButton1StyleId,
                        CTAButton1StyleIds = ((SliderCTAButtonStyleEnum)item.CTAButton1StyleId).ToString(),
                        CTAButton1BackgroundColor = item.CTAButton1BackgroundColor,
                        CTAButton1TextColor = item.CTAButton1TextColor,
                        CTAButton1FontSize = item.CTAButton1FontSize,
                        CTAButton1RedirectUrl = await _localizationService.GetLocalizedAsync(item, x => x.CTAButton1RedirectUrl),
                        CTAButton2IsVisible = item.CTAButton2IsVisible,
                        CTAButton2Text = await _localizationService.GetLocalizedAsync(item, x => x.CTAButton2Text),
                        CTAButton2StyleId = item.CTAButton2StyleId,
                        CTAButton2StyleIds = ((SliderCTAButtonStyleEnum)item.CTAButton2StyleId).ToString(),
                        CTAButton2BackgroundColor = item.CTAButton2BackgroundColor,
                        CTAButton2TextColor = item.CTAButton2TextColor,
                        CTAButton2FontSize = item.CTAButton2FontSize,
                        CTAButton2RedirectUrl = await _localizationService.GetLocalizedAsync(item, x => x.CTAButton2RedirectUrl),
                        GroupHight = ((comonheight == true) ? megasliderSettings.SliderHeight : groupdetails.GroupSliderHeight),

                        //Content Model
                        BadgeText = await _localizationService.GetLocalizedAsync(item, x => x.BadgeText),
                        BadgeImageId = item.BadgeImageId,
                        PriceText = await _localizationService.GetLocalizedAsync(item, x => x.PriceText),
                        SlideAltDescription = await _localizationService.GetLocalizedAsync(item, x => x.SlideAltDescription),
                        Cta1OpenInNewTab = item.Cta1OpenInNewTab,
                        Cta2OpenInNewTab = item.Cta2OpenInNewTab,

                        //Zone model
                        ZoneType = item.ZoneType,

                        // Left Zone
                        LeftImageId = item.LeftImageId,
                        LeftImageLink = item.LeftImageLink,
                        LeftColor = item.LeftColor,
                        LeftEmpty = item.LeftEmpty,
                        LeftOpenInNewTab = item.LeftOpenInNewTab,
                        LeftHideOnDesktop = item.LeftHideOnDesktop,
                        LeftHideOnMobile = item.LeftHideOnMobile,
                        LeftImageAlt = item.LeftImageAlt, //local
                        LeftOverlay = item.LeftOverlay,
                        LeftOverlays = ((OverlayType)item.LeftOverlay).ToString(),
                        LeftColorpreset = item.LeftColorpreset,
                        LeftColorpresets = ((ColorPresetType)item.LeftColorpreset).ToString(),
                        LeftZoneType = item.LeftZoneType,
                        LeftZoneTypes = ((ZoneTypeEnum)item.LeftZoneType).ToString(),

                        // Right Zone
                        RightImageId = item.RightImageId,
                        RightImageLink = item.RightImageLink,
                        RightColor = item.RightColor,
                        RightEmpty = item.RightEmpty,
                        RightOpenInNewTab = item.RightOpenInNewTab,
                        RightHideOnDesktop = item.RightHideOnDesktop,
                        RightHideOnMobile = item.RightHideOnMobile,
                        RightImageAlt = item.RightImageAlt, // local
                        RightOverlay = item.RightOverlay,
                        RightOverlays = ((OverlayType)item.RightOverlay).ToString(),
                        RightColorpreset = item.RightColorpreset,
                        RightColorpresets = ((ColorPresetType)item.RightColorpreset).ToString(),
                        RightZoneType = item.RightZoneType,
                        RightZoneTypes = ((ZoneTypeEnum)item.RightZoneType).ToString(),

                        // layout model
                        TextBlockOffset = item.TextBlockOffset,
                        Top = item.Top,
                        Right = item.Right,
                        Bottom = item.Bottom,
                        Left = item.Left,
                        TextBlockPosition = item.TextBlockPosition,
                        TextBlockPositions = ((TextBlockPositionenum)item.TextBlockPosition).ToString(),
                        ContentSpacing = item.ContentSpacing,
                        ContentSpacings = ((ContentSpacingenum)item.ContentSpacing).ToString(),
                        Cardtheme = item.Cardtheme,
                        Cardthemes = ((CardTheme)item.Cardtheme).ToString(),
                        Cardbackgroundcolor = item.Cardbackgroundcolor,

                        BackgroundType = item.BackgroundType,
                        BackgroundColor = item.BackgroundColor,
                        BackgroundImageId = item.BackgroundImageId,
                        BackgroundSize = item.BackgroundSize,  // int value
                        BackgroundSizes = ((BackgroundSizeEnum)item.BackgroundSize).ToString(), // string value
                        BackgroundOverlay = item.BackgroundOverlay,
                        BackgroundOverlays = ((OverlayType)item.BackgroundOverlay).ToString(),
                        TextAlignment = item.TextAlignment,
                        TextAlignments = ((TextAlignmentEnum)item.TextAlignment).ToString(),
                        BlockStyle = item.BlockStyle,
                        BlockStyles = ((BlockStyleEnum)item.BlockStyle).ToString(),
                        TextTheme = item.TextTheme,
                        TextThemes = ((TextThemeEnum)item.TextTheme).ToString(),
                        TitleFontSize = item.TitleFontSize,
                        TitleFontSizes = ((TitleFontSizeEnum)item.TitleFontSize).ToString(),

                        //new
                        BackgroundVideoUrl = item.BackgroundVideoUrl ?? string.Empty,

                        BackgroundVideoTypeId = item.BackgroundVideoTypeId,
                        IsAutoPlay = item.IsAutoPlay,
                        UseNaturalVideoSizeOnMobile = item.UseNaturalVideoSizeOnMobile,
                        AnimationEffect = animationEffectName,
                        TransitionAnimationEffect = groupTransitionEffect,

                        //Client Remove code
                        //Content = await _localizationService.GetLocalizedAsync(item, x => x.Content),
                        //ContentLayer = await _localizationService.GetLocalizedAsync(item, x => x.ContentLayer),
                        //ContentLayer3 = await _localizationService.GetLocalizedAsync(item, x => x.ContentLayer3),
                        //TitleFontSize = item.TitleFontSize,
                        //DescriptionFontSize = item.DescriptionFontSize,
                        //Texttransitions = item.Texttransitions,
                        //TransitionEffectDelay = item.TransitionEffectDelay,
                        //ContentLayerPositions = (int)item.ContentLayerPositions,
                        //ContentLayerPositionsSecond = (int)item.ContentLayerPositionsSecond,
                        //ContentLayerPositionsThird = (int)item.ContentLayerPositionsThird,
                        //AllowRepeatAnimation = item.AllowRepeatAnimation,

                    };

                    // SELL PRODUCTS
                    var sellProducts =
                        await _megasliderServices.GetAllSellProductBySliderIdAsync(item.Id);

                    var sellIds = sellProducts.Select(x => x.ProductId).Distinct().ToArray();
                    var sellList = await _productServices.GetProductsByIdsAsync(sellIds);

                    sliderModel.SellProductOverviewModel =
                        (await _productModelFactory
                            .PrepareProductOverviewModelsAsync(sellList, true, true))
                        .ToList();

                    foreach (var sellProduct in sellProducts)
                    {
                        if (sellProduct.PictureId > 0)
                        {
                            var picture = await _pictureService.GetPictureByIdAsync(sellProduct.PictureId);
                            if (picture != null)
                            {
                                var pictureUrlResult = await _pictureService.GetPictureUrlAsync(picture);
                                bannerImageUrls.Add(pictureUrlResult.Url);
                            }
                        }
                    }

                    // FEATURED PRODUCTS
                    var featuredProducts =
                        await _megasliderServices.GetAllFeturechedProductBySliderIdAsync(item.Id);

                    var featuredIds = featuredProducts.Select(x => x.ProductId).Distinct().ToArray();
                    var featuredList = await _productServices.GetProductsByIdsAsync(featuredIds);

                    sliderModel.ProductOverviewModel =
                        (await _productModelFactory
                            .PrepareProductOverviewModelsAsync(featuredList, true, true))
                        .ToList();

                    foreach (var featuredProduct in featuredProducts)
                    {
                        if (featuredProduct.PictureId > 0)
                        {
                            var picture = await _pictureService.GetPictureByIdAsync(featuredProduct.PictureId);
                            if (picture != null)
                            {
                                var pictureUrlResult = await _pictureService.GetPictureUrlAsync(picture);
                                bannerImageUrls.Add(pictureUrlResult.Url);
                            }
                        }
                    }

                    // NEW PRODUCTS
                    var newProducts =
                        await _megasliderServices.GetAllNewProductBySliderIdAsync(item.Id);

                    var newIds = newProducts.Select(x => x.ProductId).Distinct().ToArray();
                    var newList = await _productServices.GetProductsByIdsAsync(newIds);

                    sliderModel.NewProductOverviewModel =
                        (await _productModelFactory
                            .PrepareProductOverviewModelsAsync(newList, true, true))
                        .ToList();


                    //Extract banner image URLs from newProducts.PictureId
                    foreach (var newProduct in newProducts)
                    {
                        if (newProduct.PictureId > 0)
                        {
                            var picture = await _pictureService.GetPictureByIdAsync(newProduct.PictureId);
                            if (picture != null)
                            {
                                var pictureUrlResult = await _pictureService.GetPictureUrlAsync(picture);
                                bannerImageUrls.Add(pictureUrlResult.Url);
                            }
                        }
                    }

                    ///Store banner image URLs in the model
                    sliderModel.BannerImageUrls = bannerImageUrls;
                    model.SliderModel.Add(sliderModel);
                }

                if (model.SliderModel == null || model.SliderModel.Count == 0)
                    continue;

                result.Add(model);
            }

            if (!result.Any())
                return Content(string.Empty);
            if (megasliderSettings.Enable)
            {
                return View("~/Plugins/nop4all.megaslider/Views/SliderWrapper.cshtml", result);
            }
            else
            {
                return Content(string.Empty);
            }
        }
        #endregion
    }
}