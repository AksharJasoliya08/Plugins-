﻿function mainSlideFunction() {
    $(document).ready(function () {
        (function heroslider() {
            //remove no-js class
            var htmlElement = document.getElementsByTagName("html")[0];
            if (htmlElement) {
                removeClass(htmlElement, "no-js");
            }

            function HeroSlider(element) {
                this.element = element;
                this.navigation = this.element.getElementsByClassName("js-cd-nav")[0];

                // Check if navigation exists before proceeding
                if (!this.navigation) {
                    return;
                }

                this.navigationItems = this.navigation.getElementsByTagName('li');
                this.marker = this.navigation.getElementsByClassName("js-cd-marker")[0];
                this.slides = this.element.getElementsByClassName("js-cd-slide");
                this.slidesNumber = this.slides.length;
                this.newSlideIndex = 0;
                this.oldSlideIndex = 0;
                this.autoplay = hasClass(this.element, "js-cd-autoplay");
                this.autoPlayId;
                this.autoPlayDelay = parseInt(this.element.dataset.autoplay) || 12000;
                this.init();
            };

            HeroSlider.prototype.init = function () {
                var self = this;

                // Additional safety check
                if (!this.navigation || !this.slides || this.slides.length === 0) {
                    return;
                }

                //autoplay slider
                this.oldSlideIndex = 0;
                this.newSlideIndex = 0;

                // Remove ALL transition classes from every slide
                for (var i = 0; i < this.slides.length; i++) {
                    removeClass(this.slides[i],
                        "cd-hero__slide--selected cd-hero__slide--from-left cd-hero__slide--from-right cd-hero__slide--move-left cd-hero__slide--is-moving"
                    );
                }

                // Set ONLY first slide as selected (no animation)
                addClass(this.slides[0], "cd-hero__slide--selected");

                // mark initialized
                this.initialized = true;

                // autoplay
                this.setAutoplay();
                //listen for the click event on the slider navigation
                this.navigation.addEventListener('click', function (event) {
                    if (event.target.tagName.toLowerCase() == 'div')
                        return;
                    event.preventDefault();
                    var selectedSlide = event.target;
                    if (hasClass(event.target.parentElement, 'cd-selected'))
                        return;
                    self.oldSlideIndex = self.newSlideIndex;
                    self.newSlideIndex = Array.prototype.indexOf.call(self.navigationItems, event.target.parentElement);
                    self.newSlide();
                    self.updateNavigationMarker();
                    self.updateSliderNavigation();
                    self.setAutoplay();
                });

                if (this.autoplay) {
                    // on hover - pause autoplay
                    this.element.addEventListener("mouseenter", function () {
                        clearInterval(self.autoPlayId);
                    });
                    this.element.addEventListener("mouseleave", function () {
                        self.setAutoplay();
                    });
                }
            };

            HeroSlider.prototype.setAutoplay = function () {
                var self = this;
                if (this.autoplay) {
                    clearInterval(self.autoPlayId);
                    self.autoPlayId = window.setInterval(function () { self.autoplaySlider() }, self.autoPlayDelay);
                }
            };

            HeroSlider.prototype.autoplaySlider = function () {
                this.oldSlideIndex = this.newSlideIndex;
                var self = this;
                if (this.newSlideIndex < this.slidesNumber - 1) {
                    this.newSlideIndex += 1;
                    this.newSlide();
                } else {
                    this.newSlideIndex = 0;
                    this.newSlide();
                }

                this.updateNavigationMarker();
                this.updateSliderNavigation();
            };

            HeroSlider.prototype.newSlide = function (direction) {
                var self = this;
                removeClass(this.slides[this.oldSlideIndex], "cd-hero__slide--selected cd-hero__slide--from-left cd-hero__slide--from-right");
                addClass(this.slides[this.oldSlideIndex], "cd-hero__slide--is-moving");
                setTimeout(function () { removeClass(self.slides[self.oldSlideIndex], "cd-hero__slide--is-moving"); }, 500);

                for (var i = 0; i < this.slidesNumber; i++) {
                    if (i < this.newSlideIndex && this.oldSlideIndex < this.newSlideIndex) {
                        addClass(this.slides[i], "cd-hero__slide--move-left");
                    } else if (i == this.newSlideIndex && this.oldSlideIndex < this.newSlideIndex) {
                        addClass(this.slides[i], "cd-hero__slide--selected cd-hero__slide--from-right");
                    } else if (i == this.newSlideIndex && this.oldSlideIndex > this.newSlideIndex) {
                        addClass(this.slides[i], "cd-hero__slide--selected cd-hero__slide--from-left");
                        removeClass(this.slides[i], "cd-hero__slide--move-left");
                    } else if (i > this.newSlideIndex && this.oldSlideIndex > this.newSlideIndex) {
                        removeClass(this.slides[i], "cd-hero__slide--move-left");
                    }
                }
            };

            HeroSlider.prototype.updateNavigationMarker = function () {
                if (this.marker) {
                    removeClassPrefix(this.marker, 'item');
                    addClass(this.marker, "cd-hero__marker--item-" + (Number(this.newSlideIndex)));
                    $(this.marker).css('transform', 'translateY(calc(80px * ' + (Number(this.newSlideIndex)) + '))');
                }
            };

            HeroSlider.prototype.updateSliderNavigation = function () {
                if (this.navigationItems && this.navigationItems.length > 0) {
                    removeClass(this.navigationItems[this.oldSlideIndex], 'cd-selected');
                    addClass(this.navigationItems[this.newSlideIndex], 'cd-selected');
                }
            };

            var heroSliders = document.getElementsByClassName("js-cd-hero");
            if (heroSliders.length > 0) {
                for (var i = 0; i < heroSliders.length; i++) {
                    (function (i) {
                        new HeroSlider(heroSliders[i])
                    })(i);
                }
            }

            function removeClassPrefix(el, prefix) {
                //remove all classes starting with 'prefix'
                if (!el) return;
                var classes = el.className.split(" ").filter(function (c) {
                    return c.indexOf(prefix) < 0;
                });
                el.className = classes.join(" ");
            };
            //class manipulations - needed if classList is not supported

            function hasClass(el, className) {
                if (!el) return false;
                if (el.classList) return el.classList.contains(className);
                else return !!el.className.match(new RegExp('(\\s|^)' + className + '(\\s|$)'));
            }
            function addClass(el, className) {
                if (!el) return;
                var classList = className.split(' ');
                if (el.classList) el.classList.add(classList[0]);
                else if (!hasClass(el, classList[0])) el.className += " " + classList[0];
                if (classList.length > 1) addClass(el, classList.slice(1).join(' '));
            }
            function removeClass(el, className) {
                if (!el) return;
                var classList = className.split(' ');
                if (el.classList) el.classList.remove(classList[0]);
                else if (hasClass(el, classList[0])) {
                    var reg = new RegExp('(\\s|^)' + classList[0] + '(\\s|$)');
                    el.className = el.className.replace(reg, ' ');
                }
                if (classList.length > 1) removeClass(el, classList.slice(1).join(' '));
            }
        })();
    });
}