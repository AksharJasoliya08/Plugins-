﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Core; 
using Nop.Data;
using Nop.Plugin.nop4all.megaslider.Domain;
using Nop.Plugin.nop4all.megaslider.Models;
using Nop.Plugin.nop4all.megaslider.Services;
using Nop.Services;
using Nop.Services.Blogs;
using Nop.Services.Catalog;
using Nop.Services.Customers;
using Nop.Services.Topics;
using Nop.Services.Vendors;
using Nop.Web.Areas.Admin.Controllers;
using Nop.Web.Framework.Models.Extensions;
using Nop.Web.Framework.Mvc;

namespace Nop.Plugin.nop4all.megaslider.Controllers
{
    public class ConditionsMegaSliderAdminController : BaseAdminController
    {
        #region Fields
        protected readonly IConditionService _conditionService;
        protected readonly IManufacturerService _manufacturerService;
        protected readonly ICategoryService _categoryService;
        protected readonly IProductService _productService;
        protected readonly IVendorService _vendorService;
        protected readonly ICustomerService _customerService;
        protected readonly ITopicService _topicService;
        protected readonly IStoreContext _storeConext;
        protected readonly IBlogService _blogService;
        protected readonly IRepository<CaseStudy> _caseStudyRepository;
        #endregion

        #region Ctor
        public ConditionsMegaSliderAdminController(IConditionService conditionService,
            IManufacturerService manufacturerService,
            ICategoryService categoryService,
            IProductService productService,
            IVendorService vendorService,
            ICustomerService customerService,
            ITopicService topicService,
            IStoreContext storeContext,
            IBlogService blogService
,
            IRepository<CaseStudy> caseStudyRepository
            )
        {
            _conditionService = conditionService;
            _manufacturerService = manufacturerService;
            _categoryService = categoryService;
            _productService = productService;
            _vendorService = vendorService;
            _customerService = customerService;
            _topicService = topicService;
            _storeConext = storeContext;
            _blogService = blogService;
            _caseStudyRepository = caseStudyRepository;
        }
        #endregion

        #region Methods

        private async Task<List<SelectListItem>> GetCaseStudyListAsync()
        {
            var result = new List<SelectListItem>();

            var caseStudies = await _caseStudyRepository.GetAllAsync(query =>
                query.Where(x => x.Visible));

            result.AddRange(caseStudies.Select(s => new SelectListItem
            {
                Value = s.Id.ToString(),
                Text = s.Title
            }));

            return result;
        }
        private async Task<CaseStudy> GetCaseStudyByIdAsync(int id)
        {
            return await _caseStudyRepository.GetByIdAsync(id);
        }

        public virtual async Task PreparePropertyAsync(IList<SelectListItem> items, string conditionType)
        {
            if (items == null)
                throw new ArgumentNullException(nameof(items));

            if (conditionType == ConditionType.Manufacturer.ToString())
            {
                items.Add(new SelectListItem { Value = ManufacturerConditionProperty.Default.ToString(), Text = "Select" });
                items.Add(new SelectListItem { Value = ((int)ManufacturerConditionProperty.Name).ToString(), Text = ManufacturerConditionProperty.Name.ToString() });
            }
            else if (conditionType == ConditionType.Category.ToString())
            {
                items.Add(new SelectListItem { Value = CategoryConditionProperty.Default.ToString(), Text = "Select" });
                items.Add(new SelectListItem { Value = ((int)CategoryConditionProperty.Name).ToString(), Text = CategoryConditionProperty.Name.ToString() });
            }
            else if (conditionType == ConditionType.Product.ToString())
            {
                var property = await ProductConditionProperty.Category.ToSelectListAsync(false);
                foreach (var statusItem in property)
                {
                    if (statusItem.Value == "0")
                        items.Add(new SelectListItem { Value = statusItem.Value, Text = "select" });
                    else
                        items.Add(new SelectListItem { Value = statusItem.Value, Text = statusItem.Text });
                }
            }
            else if (conditionType == ConditionType.Topic.ToString())
            {
                items.Add(new SelectListItem { Value = TopicConditionProperty.Default.ToString(), Text = "Select" });
                items.Add(new SelectListItem { Value = ((int)TopicConditionProperty.SystemName).ToString(), Text = TopicConditionProperty.SystemName.ToString() });
            }
            else if (conditionType == ConditionType.Blog.ToString())
            {
                items.Add(new SelectListItem { Value = BlogConditionProperty.Default.ToString(), Text = "Select" });
                items.Add(new SelectListItem { Value = ((int)BlogConditionProperty.SystemName).ToString(), Text = BlogConditionProperty.SystemName.ToString() });
            }
            else if (conditionType == ConditionType.Casestudy.ToString())
            {
                items.Add(new SelectListItem { Value = CasestudyConditionProperty.Default.ToString(), Text = "Select" });
                items.Add(new SelectListItem { Value = ((int)CasestudyConditionProperty.SystemName).ToString(), Text = CasestudyConditionProperty.SystemName.ToString() });
            }
        }
        private List<SelectListItem> GetWidgetZonesByConditionType(string conditionType)
        {
            var list = new List<SelectListItem>();

            if (conditionType == ConditionType.Topic.ToString())
            {
                list.Add(new SelectListItem { Text = "megamenu_topic_details_top", Value = "megamenu_topic_details_top" });
                list.Add(new SelectListItem { Text = "megamenu_topic_details_bottom", Value = "megamenu_topic_details_bottom" });
                // ADD THESE for standard topic pages:
                list.Add(new SelectListItem { Text = "topic_details_top", Value = "topic_details_top" });
                list.Add(new SelectListItem { Text = "topic_details_bottom", Value = "topic_details_bottom" });
            }
            else if (conditionType == ConditionType.Blog.ToString())
            {
                list.Add(new SelectListItem { Text = "blogpost_page_top", Value = "blogpost_page_top" });
                list.Add(new SelectListItem { Text = "blogpost_page_bottom", Value = "blogpost_page_bottom" });
            }
            else if (conditionType == ConditionType.Category.ToString())
            {
                list.Add(new SelectListItem { Text = "categorydetails_top", Value = "categorydetails_top" });
                list.Add(new SelectListItem { Text = "categorydetails_bottom", Value = "categorydetails_bottom" });
                list.Add(new SelectListItem { Text = "categorydetails_before_product_list", Value = "categorydetails_before_product_list" });
                list.Add(new SelectListItem { Text = "categorydetails_after_breadcrumb", Value = "categorydetails_after_breadcrumb" });
                list.Add(new SelectListItem { Text = "categorydetails_after_featured_products", Value = "categorydetails_after_featured_products" });
                list.Add(new SelectListItem { Text = "categorydetails_before_featured_products", Value = "categorydetails_before_featured_products" });
                list.Add(new SelectListItem { Text = "categorydetails_before_subcategories", Value = "categorydetails_before_subcategories" });
            }
            else if (conditionType == ConditionType.Product.ToString())
            {
                list.Add(new SelectListItem { Text = "productdetails_top", Value = "productdetails_top" });
                list.Add(new SelectListItem { Text = "productdetails_bottom", Value = "productdetails_bottom" });
                list.Add(new SelectListItem { Text = "productdetails_overview_top", Value = "productdetails_overview_top" });
                list.Add(new SelectListItem { Text = "productdetails_overview_bottom", Value = "productdetails_overview_bottom" });
                list.Add(new SelectListItem { Text = "productdetails_essential_top", Value = "productdetails_essential_top" });
                list.Add(new SelectListItem { Text = "productdetails_essential_bottom", Value = "productdetails_essential_bottom" });
            }

            else if (conditionType == ConditionType.Manufacturer.ToString())
            {
                list.Add(new SelectListItem { Text = "manufacturerdetails_top", Value = "manufacturerdetails_top" });
                list.Add(new SelectListItem { Text = "manufacturerdetails_bottom", Value = "manufacturerdetails_bottom" });
            }
            else if (conditionType == ConditionType.Casestudy.ToString())
            {
                list.Add(new SelectListItem { Text = "casestudy_top", Value = "casestudy_top" });
                list.Add(new SelectListItem { Text = "casestudy_bottom", Value = "casestudy_bottom" });
            }

            return list;
        }

        public virtual Task PrepareOperatorAsync(IList<SelectListItem> items, string conditionType, int property)
        {
            if (conditionType == ConditionType.Manufacturer.ToString())
            {
                if ((int)ManufacturerConditionProperty.Name == property)
                    BooleanOperators(items);
            }
            else if (conditionType == ConditionType.Category.ToString())
            {
                if ((int)CategoryConditionProperty.Name == property)
                    BooleanOperators(items);
            }
            else if (conditionType == ConditionType.Topic.ToString())
            {
                if ((int)TopicConditionProperty.SystemName == property)
                    BooleanOperators(items);
            }
            else if (conditionType == ConditionType.Blog.ToString())
            {
                if ((int)BlogConditionProperty.SystemName == property)
                    BooleanOperators(items);
            }
            else if (conditionType == ConditionType.Product.ToString())
            {
                if ((int)ProductConditionProperty.Category == property || (int)ProductConditionProperty.Manufacturer == property ||
                    (int)ProductConditionProperty.PreOrder == property || (int)ProductConditionProperty.FreeShipping == property ||
                    (int)ProductConditionProperty.HasSpecialPrice == property || (int)ProductConditionProperty.MarkedAsNew == property ||
                    (int)ProductConditionProperty.Vendor == property || (int)ProductConditionProperty.Name == property)
                {
                    BooleanOperators(items);
                }
                else if ((int)ProductConditionProperty.ProductAgeHours == property || (int)ProductConditionProperty.DiscountAmmount == property ||
                        (int)ProductConditionProperty.DiscountPercentage == property || (int)ProductConditionProperty.PriceDifferenceAmmount == property ||
                        (int)ProductConditionProperty.PriceDifferencePercentage == property || (int)ProductConditionProperty.MinPrice == property ||
                        (int)ProductConditionProperty.Quantity == property)
                {
                    AllNumericOperators(items);
                }
            }
            else if (conditionType == ConditionType.Casestudy.ToString())
            {
                if ((int)CasestudyConditionProperty.SystemName == property)
                    BooleanOperators(items);
            }

            return Task.CompletedTask;
        }

        public virtual async Task PrepareValueAsync(IList<SelectListItem> items, int type, string conditionType, int property)
        {
            if (conditionType == ConditionType.Manufacturer.ToString())
            {
                if ((int)ManufacturerConditionProperty.Name == property)
                {
                    type = (int)ConditionPropertyValueType.ComboBox;
                    foreach (var manufacturer in await _manufacturerService.GetAllManufacturersAsync())
                        items.Add(new SelectListItem()
                        {
                            Value = manufacturer.Id.ToString(),
                            Text = manufacturer.Name.ToString()
                        });
                }
            }
            else if (conditionType == ConditionType.Category.ToString())
            {
                if ((int)CategoryConditionProperty.Name == property)
                {
                    type = (int)ConditionPropertyValueType.ComboBox;
                    foreach (var category in await _categoryService.GetAllCategoriesAsync())
                        items.Add(new SelectListItem()
                        {
                            Value = category.Id.ToString(),
                            Text = category.Name.ToString()
                        });
                }
            }
            else if (conditionType == ConditionType.Product.ToString())
            {
                if ((int)ProductConditionProperty.Category == property)
                {
                    type = (int)ConditionPropertyValueType.ComboBox;
                    foreach (var category in await _categoryService.GetAllCategoriesAsync())
                        items.Add(new SelectListItem()
                        {
                            Value = category.Id.ToString(),
                            Text = category.Name.ToString()
                        });
                }
                else if ((int)ProductConditionProperty.Manufacturer == property)
                {
                    type = (int)ConditionPropertyValueType.ComboBox;
                    foreach (var manufacturer in await _manufacturerService.GetAllManufacturersAsync())
                        items.Add(new SelectListItem()
                        {
                            Value = manufacturer.Id.ToString(),
                            Text = manufacturer.Name.ToString()
                        });
                }
                else if ((int)ProductConditionProperty.Vendor == property)
                {
                    type = (int)ConditionPropertyValueType.ComboBox;
                    foreach (var vendor in await _vendorService.GetAllVendorsAsync())
                        items.Add(new SelectListItem()
                        {
                            Value = vendor.Id.ToString(),
                            Text = vendor.Name.ToString()
                        });
                }
                else if ((int)ProductConditionProperty.Name == property)
                {
                    type = (int)ConditionPropertyValueType.ComboBox;
                    foreach (var product in await _productService.SearchProductsAsync())
                        items.Add(new SelectListItem()
                        {
                            Value = product.Id.ToString(),
                            Text = product.Name.ToString()
                        });
                }
                else if ((int)ProductConditionProperty.ProductAgeHours == property || (int)ProductConditionProperty.DiscountAmmount == property ||
                    (int)ProductConditionProperty.DiscountPercentage == property || (int)ProductConditionProperty.PriceDifferenceAmmount == property ||
                    (int)ProductConditionProperty.PriceDifferencePercentage == property || (int)ProductConditionProperty.MinPrice == property ||
                    (int)ProductConditionProperty.Quantity == property)
                {
                    type = (int)ConditionPropertyValueType.NumericTextbox;
                }
                else if ((int)ProductConditionProperty.PreOrder == property ||
                         (int)ProductConditionProperty.FreeShipping == property ||
                         (int)ProductConditionProperty.HasSpecialPrice == property ||
                         (int)ProductConditionProperty.MarkedAsNew == property)
                {
                    type = (int)ConditionPropertyValueType.Dropdown;
                    items.Add(new SelectListItem { Value = "True", Text = "True" });
                    items.Add(new SelectListItem { Value = "False", Text = "False" });
                }
            }
            else if (conditionType == ConditionType.Topic.ToString())
            {
                if ((int)TopicConditionProperty.SystemName == property)
                {
                    type = (int)ConditionPropertyValueType.ComboBox;
                    foreach (var topic in await _topicService.GetAllTopicsAsync(_storeConext.GetCurrentStore().Id))
                        items.Add(new SelectListItem()
                        {
                            Value = topic.Id.ToString(),
                            Text = topic.SystemName
                        });
                }
            }
            else if (conditionType == ConditionType.Blog.ToString())
            {
                if ((int)BlogConditionProperty.SystemName == property)
                {
                    type = (int)ConditionPropertyValueType.ComboBox;
                    foreach (var blog in await _blogService.GetAllBlogPostsAsync(_storeConext.GetCurrentStore().Id))
                        items.Add(new SelectListItem()
                        {
                            Value = blog.Id.ToString(),
                            Text = blog.Title
                        });
                }
            }
            else if (conditionType == ConditionType.Casestudy.ToString())
            {
                if ((int)CasestudyConditionProperty.SystemName == property)
                {
                    type = (int)ConditionPropertyValueType.ComboBox;
                    foreach (var caseStudy in await GetCaseStudyListAsync())
                        items.Add(new SelectListItem()
                        {
                            Value = caseStudy.Value,
                            Text = caseStudy.Text
                        });
                }
            }
        }

        public async Task<IActionResult> GetProperty(string conditionType)
        {
            if (string.IsNullOrEmpty(conditionType))
                throw new ArgumentNullException(nameof(conditionType));

            var result = new List<object>();
            if (conditionType == ConditionType.Manufacturer.ToString())
            {
                result.Add(new { id = ManufacturerConditionProperty.Default, name = "Select" });
                result.Add(new { id = ManufacturerConditionProperty.Name, name = ManufacturerConditionProperty.Name.ToString() });
                return Json(result);
            }
            else if (conditionType == ConditionType.Category.ToString())
            {
                result.Add(new { id = CategoryConditionProperty.Default, name = "Select" });
                result.Add(new { id = CategoryConditionProperty.Name, name = CategoryConditionProperty.Name.ToString() });
                return Json(result);
            }
            else if (conditionType == ConditionType.Product.ToString())
            {
                result.Add(new { id = ProductConditionProperty.Default, name = "Select" });
                result.Add(new { id = ProductConditionProperty.Name, name = ProductConditionProperty.Name.ToString() });
                return Json(result);
            }

            else if (conditionType == ConditionType.Topic.ToString())
            {
                result.Add(new { id = TopicConditionProperty.Default, name = "Select" });
                result.Add(new { id = TopicConditionProperty.SystemName, name = TopicConditionProperty.SystemName.ToString() });
                return Json(result);
            }
            else if (conditionType == ConditionType.Blog.ToString())
            {
                result.Add(new { id = BlogConditionProperty.Default, name = "Select" });
                result.Add(new { id = BlogConditionProperty.SystemName, name = BlogConditionProperty.SystemName.ToString() });
                return Json(result);
            }
            else if (conditionType == ConditionType.Casestudy.ToString())
            {
                result.Add(new { id = CasestudyConditionProperty.Default, name = "Select" });
                result.Add(new { id = CasestudyConditionProperty.SystemName, name = CasestudyConditionProperty.SystemName.ToString() });
                return Json(result);
            }
            return Json(string.Empty);
        }

        public virtual void BooleanOperators(IList<SelectListItem> items)
        {
            items.Add(new SelectListItem { Value = "0", Text = OperatorType.EqualTo.ToString() });
            items.Add(new SelectListItem { Value = "1", Text = OperatorType.NotEqualTo.ToString() });
        }

        public virtual void AllNumericOperators(IList<SelectListItem> items)
        {
            foreach (OperatorType operatorType in Enum.GetValues(typeof(OperatorType)))
            {
                switch (operatorType)
                {
                    case OperatorType.Contains:
                    case OperatorType.DoesNotContain:
                        continue;
                    default:
                        items.Add(new SelectListItem { Value = ((int)operatorType).ToString(), Text = ((OperatorType)operatorType).ToString() });
                        continue;
                }
            }
        }
        public virtual void EqualOperator(IList<SelectListItem> items)
        {
            items.Add(new SelectListItem { Value = "0", Text = OperatorType.EqualTo.ToString() });
        }

        public virtual void StringOperators(IList<SelectListItem> items)
        {
            items.Add(new SelectListItem { Value = "0", Text = OperatorType.EqualTo.ToString() });
            items.Add(new SelectListItem { Value = "1", Text = OperatorType.NotEqualTo.ToString() });
            items.Add(new SelectListItem { Value = "2", Text = OperatorType.Contains.ToString() });
            items.Add(new SelectListItem { Value = "3", Text = OperatorType.DoesNotContain.ToString() });
        }

        public Task<IActionResult> GetOperator(string conditionType, int property)
        {
            var result = new List<SelectListItem>();
            if (conditionType == ConditionType.Manufacturer.ToString())
            {
                if ((int)ManufacturerConditionProperty.Name == property)
                {
                    BooleanOperators(result);
                    return Task.FromResult<IActionResult>(Json(result));
                }
            }
            else if (conditionType == ConditionType.Category.ToString())
            {
                if ((int)CategoryConditionProperty.Name == property)
                {
                    BooleanOperators(result);
                    return Task.FromResult<IActionResult>(Json(result));
                }
            }
            else if (conditionType == ConditionType.Topic.ToString())
            {
                if ((int)TopicConditionProperty.SystemName == property)
                {
                    BooleanOperators(result);
                    return Task.FromResult<IActionResult>(Json(result));
                }
            }
            else if (conditionType == ConditionType.Blog.ToString())
            {
                if ((int)BlogConditionProperty.SystemName == property)
                {
                    BooleanOperators(result);
                    return Task.FromResult<IActionResult>(Json(result));
                }
            }
            else if (conditionType == ConditionType.Product.ToString())
            {
                if ((int)ProductConditionProperty.Category == property || (int)ProductConditionProperty.Manufacturer == property ||
                    (int)ProductConditionProperty.PreOrder == property || (int)ProductConditionProperty.FreeShipping == property ||
                    (int)ProductConditionProperty.HasSpecialPrice == property || (int)ProductConditionProperty.MarkedAsNew == property ||
                    (int)ProductConditionProperty.Vendor == property || (int)ProductConditionProperty.Name == property)
                {
                    BooleanOperators(result);
                    return Task.FromResult<IActionResult>(Json(result));
                }
                else if ((int)ProductConditionProperty.ProductAgeHours == property || (int)ProductConditionProperty.DiscountAmmount == property ||
                        (int)ProductConditionProperty.DiscountPercentage == property || (int)ProductConditionProperty.PriceDifferenceAmmount == property ||
                        (int)ProductConditionProperty.PriceDifferencePercentage == property || (int)ProductConditionProperty.MinPrice == property ||
                        (int)ProductConditionProperty.Quantity == property)
                {
                    AllNumericOperators(result);
                    return Task.FromResult<IActionResult>(Json(result));
                }
            }
            else if (conditionType == ConditionType.Casestudy.ToString())
            {
                if ((int)CasestudyConditionProperty.SystemName == property)
                {
                    BooleanOperators(result);
                    return Task.FromResult<IActionResult>(Json(result));
                }
            }

            return Task.FromResult<IActionResult>(Json(string.Empty));
        }

        public async Task<IActionResult> GetValue(string conditionType, int property)
        {
            var type = 0;
            var result = new List<object>();
            var manufacturers = await _manufacturerService.GetAllManufacturersAsync();
            var categories = await _categoryService.GetAllCategoriesAsync();
            var products = await _productService.SearchProductsAsync();
            var vendors = await _vendorService.GetAllVendorsAsync();
            var customerRoles = await _customerService.GetAllCustomerRolesAsync();
            var topic = await _topicService.GetAllTopicsAsync(_storeConext.GetCurrentStore().Id);
            var blog = await _blogService.GetAllBlogPostsAsync(_storeConext.GetCurrentStore().Id);
            var caseStudy = await GetCaseStudyListAsync();
            if (conditionType == ConditionType.Manufacturer.ToString())
            {
                if ((int)ManufacturerConditionProperty.Name == property)
                {
                    type = (int)ConditionPropertyValueType.ComboBox;
                    result.AddRange((from s in manufacturers
                                     select new SelectListItem { Value = s.Id.ToString(), Text = s.Name }).ToList());

                    return Json(new { type = type, result = result });
                }
            }
            else if (conditionType == ConditionType.Category.ToString())
            {
                if ((int)CategoryConditionProperty.Name == property)
                {
                    type = (int)ConditionPropertyValueType.ComboBox;
                    result.AddRange((from s in categories
                                     select new SelectListItem { Value = s.Id.ToString(), Text = s.Name }).ToList());

                    return Json(new { type = type, result = result });
                }
            }
            else if (conditionType == ConditionType.Product.ToString())
            {
                if ((int)ProductConditionProperty.Category == property)
                {
                    type = (int)ConditionPropertyValueType.ComboBox;
                    result.AddRange((from s in categories
                                     select new SelectListItem { Value = s.Id.ToString(), Text = s.Name }).ToList());

                    return Json(new { type = type, result = result });
                }
                else if ((int)ProductConditionProperty.Manufacturer == property)
                {
                    type = (int)ConditionPropertyValueType.ComboBox;
                    result.AddRange((from s in manufacturers
                                     select new SelectListItem { Value = s.Id.ToString(), Text = s.Name }).ToList());

                    return Json(new { type = type, result = result });
                }
                else if ((int)ProductConditionProperty.Vendor == property)
                {
                    type = (int)ConditionPropertyValueType.ComboBox;
                    result.AddRange((from s in vendors
                                     select new SelectListItem { Value = s.Id.ToString(), Text = s.Name }).ToList());

                    return Json(new { type = type, result = result });
                }
                else if ((int)ProductConditionProperty.Name == property)
                {
                    type = (int)ConditionPropertyValueType.ComboBox;
                    result.AddRange((from s in products
                                     select new SelectListItem { Value = s.Id.ToString(), Text = s.Name }).ToList());

                    return Json(new { type = type, result = result });
                }
                else if ((int)ProductConditionProperty.ProductAgeHours == property || (int)ProductConditionProperty.DiscountAmmount == property ||
                    (int)ProductConditionProperty.DiscountPercentage == property || (int)ProductConditionProperty.PriceDifferenceAmmount == property ||
                    (int)ProductConditionProperty.PriceDifferencePercentage == property || (int)ProductConditionProperty.MinPrice == property ||
                    (int)ProductConditionProperty.Quantity == property)
                {
                    type = (int)ConditionPropertyValueType.NumericTextbox;
                    return Json(new { type = type });
                }
                else if ((int)ProductConditionProperty.PreOrder == property ||
                         (int)ProductConditionProperty.FreeShipping == property ||
                         (int)ProductConditionProperty.HasSpecialPrice == property ||
                         (int)ProductConditionProperty.MarkedAsNew == property)
                {
                    type = (int)ConditionPropertyValueType.Dropdown;
                    result.Add(new SelectListItem { Text = "True", Value = "Frue" });
                    result.Add(new SelectListItem { Text = "False", Value = "False" });

                    return Json(new { type = type, result = result });
                }
            }
            else if (conditionType == ConditionType.Topic.ToString())
            {
                if ((int)TopicConditionProperty.SystemName == property)
                {
                    type = (int)ConditionPropertyValueType.ComboBox;
                    result.AddRange((from s in topic
                                     select new SelectListItem { Value = s.Id.ToString(), Text = s.SystemName }).ToList());

                    return Json(new { type = type, result = result });
                }
            }
            else if (conditionType == ConditionType.Blog.ToString())
            {
                if ((int)BlogConditionProperty.SystemName == property)
                {
                    type = (int)ConditionPropertyValueType.ComboBox;
                    result.AddRange((from s in blog
                                     select new SelectListItem { Value = s.Id.ToString(), Text = s.Title }).ToList());

                    return Json(new { type = type, result = result });
                }
            }
            else if (conditionType == ConditionType.Casestudy.ToString())
            {
                if ((int)CasestudyConditionProperty.SystemName == property)
                {
                    type = (int)ConditionPropertyValueType.ComboBox;
                    result.AddRange((from s in caseStudy
                                     select new SelectListItem { Value = s.Value, Text = s.Text}).ToList());

                    return Json(new { type = type, result = result });
                }
            }
            return Json(string.Empty);
        }

        [HttpPost]
        public async Task<IActionResult> Condition(ConditionSearchModel searchModel)
        {
            var conditions = await _conditionService.GetMenuConditionByMenuIdAsync(searchModel.GroupId, pageIndex: searchModel.Page - 1, pageSize: searchModel.PageSize);
            var model = await new ConditionListModel().PrepareToGridAsync(searchModel, conditions, () =>
            {
                return conditions.SelectAwait(async condition =>
                {
                    var configureMenuModel = new ConditionModel();
                    configureMenuModel.Id = condition.Id;
                    configureMenuModel.ConditionType = condition.ConditionType;
                    configureMenuModel.Operator = ((OperatorType)condition.Oprater).ToString();
                    configureMenuModel.Value = condition.Value;
                    configureMenuModel.WidgetZone = condition.WidgetZone;

                    if (condition.ConditionType == ConditionType.Category.ToString())
                    {
                        configureMenuModel.Property = ((CategoryConditionProperty)condition.Property).ToString();
                        configureMenuModel.Value = (await _categoryService.GetCategoryByIdAsync(Convert.ToInt32(condition.Value)))?.Name;
                    }
                    else if (condition.ConditionType == ConditionType.Product.ToString())
                    {
                        configureMenuModel.Property = ((ProductConditionProperty)condition.Property).ToString();
                        if (condition.Property == (int)ProductConditionProperty.Category)
                            configureMenuModel.Value = (await _categoryService.GetCategoryByIdAsync(Convert.ToInt32(condition.Value)))?.Name;

                        else if (condition.Property == (int)ProductConditionProperty.Manufacturer)
                            configureMenuModel.Value = (await _manufacturerService.GetManufacturerByIdAsync(Convert.ToInt32(condition.Value)))?.Name;

                        else if (condition.Property == (int)ProductConditionProperty.Vendor)
                            configureMenuModel.Value = (await _vendorService.GetVendorByIdAsync(Convert.ToInt32(condition.Value)))?.Name;

                        else if (condition.Property == (int)ProductConditionProperty.Name)
                            configureMenuModel.Value = (await _productService.GetProductByIdAsync(Convert.ToInt32(condition.Value)))?.Name;
                    }
                    else if (condition.ConditionType == ConditionType.Manufacturer.ToString())
                    {
                        configureMenuModel.Property = ((ManufacturerConditionProperty)condition.Property).ToString();
                        configureMenuModel.Value = (await _manufacturerService.GetManufacturerByIdAsync(Convert.ToInt32(condition.Value)))?.Name;
                    }
                    else if (condition.ConditionType == ConditionType.Topic.ToString())
                    {
                        configureMenuModel.Property = ((TopicConditionProperty)condition.Property).ToString();
                        configureMenuModel.Value = (await _topicService.GetTopicByIdAsync(Convert.ToInt32(condition.Value)))?.SystemName;
                    }
                    else if (condition.ConditionType == ConditionType.Blog.ToString())
                    {
                        configureMenuModel.Property = ((BlogConditionProperty)condition.Property).ToString();
                        configureMenuModel.Value = (await _blogService.GetBlogPostByIdAsync(Convert.ToInt32(condition.Value)))?.Title;
                    }
                    else if (condition.ConditionType == ConditionType.Casestudy.ToString())
                    {
                        configureMenuModel.Property = ((CasestudyConditionProperty)condition.Property).ToString();
                        configureMenuModel.Value = (await GetCaseStudyByIdAsync(Convert.ToInt32(condition.Value)))?.Title;
                    }

                    return configureMenuModel;
                });
            });
            return Json(model);
        }

        public virtual async Task<IActionResult> ValueCreatePopup(int GroupId)
        {
            var model = new ConditionModel();
            model.GroupId = GroupId;
            model.AvailableConditionType = (await ConditionType.Default.ToSelectListAsync()).Select(entity => new SelectListItem
            {
                Text = entity.Text,
                Value = entity.Text,
            }).ToList();
            model.AvailableProperty = (await ConditionProperty.Default.ToSelectListAsync()).Select(entity => new SelectListItem
            {
                Text = entity.Text,
                Value = entity.Value,
            }).ToList();
            model.AvailableManufacturers = (await _manufacturerService.GetAllManufacturersAsync()).Select(manufacturer => new SelectListItem
            {
                Text = manufacturer.Name,
                Value = manufacturer.Id.ToString(),
            }).ToList();

            return View("~/Plugins/nop4all.megaslider/Views/GroupMegaSlider/ValueCreatePopup.cshtml", model);
        }

        [HttpPost]
        public virtual async Task<IActionResult> SaveValueCreatePopup(ConditionModel model)
        {
            if (model.Id == 0)
            {
                var condition = new MegaSliderGroupCondition();
                condition.GroupId = model.GroupId;
                condition.Property = Convert.ToInt32(model.Property);
                condition.ConditionType = model.ConditionType;
                condition.Oprater = Convert.ToInt32(model.Operator);
                condition.WidgetZone = model.WidgetZone;

                if (model.Type == (int)ConditionPropertyValueType.ComboBox)
                    condition.Value = model.Value;
                else if (model.Type == (int)ConditionPropertyValueType.NumericTextbox)
                    condition.Value = model.NumberValue.ToString();
                else if (model.Type == (int)ConditionPropertyValueType.Textbox)
                    condition.Value = model.TextValue;

                await _conditionService.InsertConditionAsync(condition);
            }
            else
            {
                var condition = await _conditionService.GetMenuConditionByIdAsync(model.Id);
                if (condition != null)
                {
                    condition.GroupId = model.GroupId;
                    condition.Property = Convert.ToInt32(model.Property);
                    condition.ConditionType = model.ConditionType;
                    condition.Oprater = Convert.ToInt32(model.Operator);
                    condition.WidgetZone = model.WidgetZone;

                    if (model.Type == (int)ConditionPropertyValueType.ComboBox)
                        condition.Value = model.Value;
                    else if (model.Type == (int)ConditionPropertyValueType.NumericTextbox)
                        condition.Value = model.NumberValue.ToString();
                    else if (model.Type == (int)ConditionPropertyValueType.Textbox)
                        condition.Value = model.TextValue;

                    await _conditionService.UpdateConditionAsync(condition);
                }
            }

            return Json(new { success = true });
        }

        public virtual async Task<IActionResult> ValueEditPopup(int id)
        {
            var condtion = await _conditionService.GetMenuConditionByIdAsync(id);
            var model = new ConditionModel();
            model.Id = condtion.Id;
            model.GroupId = condtion.GroupId;
            model.WidgetZone = condtion.WidgetZone;
            model.AvailableConditionType = (await ConditionType.Default.ToSelectListAsync()).Select(entity => new SelectListItem
            {
                Text = entity.Text,
                Value = entity.Text,
            }).ToList();
            model.Operator = condtion.Oprater.ToString();
            model.Property = condtion.Property.ToString();
            model.ConditionType = condtion.ConditionType;

            //prepare available countries
            await PreparePropertyAsync(model.AvailableProperty, condtion.ConditionType);
            await PrepareOperatorAsync(model.AvailableOperator, condtion.ConditionType, condtion.Property);
            await PrepareValueAsync(model.AvailableValue, model.Type, condtion.ConditionType, condtion.Property);

            if (condtion.ConditionType == ConditionType.Manufacturer.ToString())
            {
                if ((int)ManufacturerConditionProperty.Name == condtion.Property)
                    model.Type = (int)ConditionPropertyValueType.ComboBox;
            }
            else if (condtion.ConditionType == ConditionType.Category.ToString())
            {
                if ((int)CategoryConditionProperty.Name == condtion.Property)
                    model.Type = (int)ConditionPropertyValueType.ComboBox;
            }
            else if (condtion.ConditionType == ConditionType.Product.ToString())
            {
                if ((int)ProductConditionProperty.Category == condtion.Property)
                {
                    model.Type = (int)ConditionPropertyValueType.ComboBox;
                }
                else if ((int)ProductConditionProperty.Manufacturer == condtion.Property)
                {
                    model.Type = (int)ConditionPropertyValueType.ComboBox;
                }
                else if ((int)ProductConditionProperty.Vendor == condtion.Property)
                {
                    model.Type = (int)ConditionPropertyValueType.ComboBox;
                }
                else if ((int)ProductConditionProperty.Name == condtion.Property)
                {
                    model.Type = (int)ConditionPropertyValueType.ComboBox;
                }
                else if ((int)ProductConditionProperty.ProductAgeHours == condtion.Property || (int)ProductConditionProperty.DiscountAmmount == condtion.Property ||
                    (int)ProductConditionProperty.DiscountPercentage == condtion.Property || (int)ProductConditionProperty.PriceDifferenceAmmount == condtion.Property ||
                    (int)ProductConditionProperty.PriceDifferencePercentage == condtion.Property || (int)ProductConditionProperty.MinPrice == condtion.Property ||
                    (int)ProductConditionProperty.Quantity == condtion.Property)
                {
                    model.Type = (int)ConditionPropertyValueType.NumericTextbox;
                }
                else if ((int)ProductConditionProperty.PreOrder == condtion.Property ||
                         (int)ProductConditionProperty.FreeShipping == condtion.Property ||
                         (int)ProductConditionProperty.HasSpecialPrice == condtion.Property ||
                         (int)ProductConditionProperty.MarkedAsNew == condtion.Property)
                {
                    model.Type = (int)ConditionPropertyValueType.Dropdown;
                }
            }
            else if (condtion.ConditionType == ConditionType.Topic.ToString())
            {
                if ((int)TopicConditionProperty.SystemName == condtion.Property)
                    model.Type = (int)ConditionPropertyValueType.ComboBox;
            }
            else if (condtion.ConditionType == ConditionType.Blog.ToString())
            {
                if ((int)BlogConditionProperty.SystemName == condtion.Property)
                    model.Type = (int)ConditionPropertyValueType.ComboBox;
            }
            else if (condtion.ConditionType == ConditionType.Casestudy.ToString())
            {
                if ((int)CasestudyConditionProperty.SystemName == condtion.Property)
                    model.Type = (int)ConditionPropertyValueType.ComboBox;
            }

            if (model.Type == (int)ConditionPropertyValueType.ComboBox || (int)ConditionPropertyValueType.Dropdown == model.Type)
                model.Value = condtion.Value.ToString();
            else if (model.Type == (int)ConditionPropertyValueType.Textbox)
                model.TextValue = condtion.Value;
            else if (model.Type == (int)ConditionPropertyValueType.NumericTextbox)
                model.NumberValue = Convert.ToInt32(condtion.Value);

            return View("~/Plugins/nop4all.megaslider/Views/GroupMegaSlider/ValueCreatePopup.cshtml", model);
        }

        [HttpPost]
        public virtual async Task<IActionResult> ConditionDelete(int id)
        {
            var condtion = await _conditionService.GetMenuConditionByIdAsync(id);
            await _conditionService.DeleteConditionAsync(condtion);

            return new NullJsonResult();
        }

        public IActionResult GetWidgetZones(string conditionType)
        {
            var zones = GetWidgetZonesByConditionType(conditionType);
            return Json(zones);
        }

        #endregion
    }
}