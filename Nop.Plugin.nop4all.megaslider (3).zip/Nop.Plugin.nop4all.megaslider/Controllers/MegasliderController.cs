﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Core;
using Nop.Plugin.nop4all.megaslider.Domain;
using Nop.Plugin.nop4all.megaslider.Factories;
using Nop.Plugin.nop4all.megaslider.Model;
using Nop.Plugin.nop4all.megaslider.Model.FeatureProduct;
using Nop.Plugin.nop4all.megaslider.Model.MSLanguageResource;
using Nop.Plugin.nop4all.megaslider.Model.NewProduct;
using Nop.Plugin.nop4all.megaslider.Model.SellProduct;
using Nop.Plugin.nop4all.megaslider.Model.Slider;
using Nop.Plugin.nop4all.megaslider.Services;
using Nop.Services.Catalog;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Messages;
using Nop.Services.Security;
using Nop.Services.Stores;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Models.Extensions;
using Nop.Web.Framework.Mvc;
using Nop.Web.Framework.Mvc.Filters;

namespace Nop.Plugin.nop4all.megaslider.Controllers
{
    [AuthorizeAdmin]
    [Area(AreaNames.ADMIN)]
    public class MegasliderController : BasePluginController
    {
        #region Fields
        protected readonly ISettingService _settingService;
        protected readonly ILocalizationService _localizationService;
        protected readonly IPermissionService _permissionService;
        protected readonly INotificationService _notificationService;
        protected readonly IMegasliderServices _megaService;
        protected readonly ISliderFactories _sliderFactories;
        protected readonly IProductService _productService;
        protected readonly IStoreMappingService _storeMappingService;
        protected readonly IMegasliderServices _megasliderServices;
        protected readonly ILocalizedEntityService _localizedEntityService;
        protected readonly IStoreContext _storeContext;

        #endregion

        #region Ctor
        public MegasliderController(ISettingService settingService,
            ILocalizationService localizationService,
            IPermissionService permissionService,
            INotificationService notificationService,
            IMegasliderServices megaService,
            ISliderFactories sliderFactories,
            IProductService productService,
            IStoreMappingService storeMappingService,
            IMegasliderServices megasliderServices,
            ILocalizedEntityService localizedEntityService,
            IStoreContext storeContext)
        {
            _settingService = settingService;
            _localizationService = localizationService;
            _permissionService = permissionService;
            _notificationService = notificationService;
            _megaService = megaService;
            _sliderFactories = sliderFactories;
            _productService = productService;
            _storeMappingService = storeMappingService;
            _megasliderServices = megasliderServices;
            _localizedEntityService = localizedEntityService;
            _storeContext = storeContext;
        }
        #endregion

        #region Utilities 

        protected virtual async Task UpdateLocalesAsync(MegaSlider slider, SliderModel model)
        {
            foreach (var localized in model.Locales)
            {
                //HeroShortDescription
                await _localizedEntityService.SaveLocalizedValueAsync(slider,
                    x => x.ShortDescription,
                    localized.ShortDescription,
                    localized.LanguageId);
                //HeroTitle
                await _localizedEntityService.SaveLocalizedValueAsync(slider,
                    x => x.Title,
                    localized.Title,
                    localized.LanguageId);
                await _localizedEntityService.SaveLocalizedValueAsync(slider,
                    x => x.CTAButton1Text,
                    localized.CTAButton1Text,
                    localized.LanguageId);
                await _localizedEntityService.SaveLocalizedValueAsync(slider,
                    x => x.CTAButton2Text,
                    localized.CTAButton2Text,
                    localized.LanguageId);
                await _localizedEntityService.SaveLocalizedValueAsync(slider,
                    x => x.CTAButton1RedirectUrl,
                    localized.CTAButton1RedirectUrl,
                    localized.LanguageId);
                await _localizedEntityService.SaveLocalizedValueAsync(slider,
                    x => x.CTAButton2RedirectUrl,
                    localized.CTAButton2RedirectUrl,
                    localized.LanguageId);
                await _localizedEntityService.SaveLocalizedValueAsync(slider,
                    x => x.HtmlContent,
                    localized.HtmlContent,
                    localized.LanguageId);
                await _localizedEntityService.SaveLocalizedValueAsync(slider,
                    x => x.BadgeText,
                    localized.BadgeText,
                    localized.LanguageId);
                await _localizedEntityService.SaveLocalizedValueAsync(slider,
                   x => x.PriceText,
                   localized.PriceText,
                   localized.LanguageId);
                await _localizedEntityService.SaveLocalizedValueAsync(slider,
                   x => x.SlideAltDescription,
                   localized.SlideAltDescription,
                   localized.LanguageId);

                //layout
                await _localizedEntityService.SaveLocalizedValueAsync(slider,
                   x => x.BackgroundVideoUrl,
                   localized.BackgroundVideoUrl,
                   localized.LanguageId);

                //Client Remove code
                //await _localizedEntityService.SaveLocalizedValueAsync(slider,
                //    x => x.Content,
                //    localized.Content,
                //    localized.LanguageId);

                //await _localizedEntityService.SaveLocalizedValueAsync(slider,
                //    x => x.ContentLayer,
                //    localized.ContentLayer,
                //    localized.LanguageId);

                //await _localizedEntityService.SaveLocalizedValueAsync(slider,
                //    x => x.ContentLayer3,
                //    localized.ContentLayer3,
                //    localized.LanguageId);
            }
        }

        #endregion

        #region Methods

        #region Configure 

        [CheckPermission(StandardPermission.Configuration.MANAGE_PLUGINS)]
        public async Task<IActionResult> Configure()
        {
            var storeScope = await _storeContext.GetActiveStoreScopeConfigurationAsync();
            var megasliderSettings = await _settingService.LoadSettingAsync<MegasliderSettings>(storeScope);
            var model = new ConfigurationModel
            {
                ActiveStoreScopeConfiguration = storeScope,
                Enable = megasliderSettings.Enable,
                Autoplay = megasliderSettings.Autoplay, 
                MainSliderDots = megasliderSettings.MainSliderDots,
                MainSliderArrows = megasliderSettings.MainSliderArrows,
                SliderHeight = (megasliderSettings.SliderHeight > 0 ? megasliderSettings.SliderHeight : 750 ),
                AnimationRepeat = megasliderSettings.AnimationRepeat,
                Newproductdropdown = megasliderSettings.Newproductdropdown

            };
            if (storeScope > 0)
            {
                model.Enable_OverrideForStore =await _settingService.SettingExistsAsync(megasliderSettings, x => x.Enable, storeScope);
                model.Autoplay_OverrideForStore = await _settingService.SettingExistsAsync(megasliderSettings, x => x.Autoplay, storeScope); 
                model.MainSliderDots_OverrideForStore = await _settingService.SettingExistsAsync(megasliderSettings, x => x.MainSliderDots, storeScope);
                model.MainSliderArrows_OverrideForStore = await _settingService.SettingExistsAsync(megasliderSettings, x => x.MainSliderArrows, storeScope);
                model.SliderHeight_OverrideForStore = await _settingService.SettingExistsAsync(megasliderSettings, x => x.SliderHeight, storeScope);
                model.AnimationRepeat_OverrideForStore = await _settingService.SettingExistsAsync(megasliderSettings, x => x.AnimationRepeat, storeScope);
                model.Newproductdropdown_OverrideForStore = await _settingService.SettingExistsAsync(megasliderSettings, x => x.Newproductdropdown, storeScope);
            
            }

            // Load positions from XML file
            var positions = await _megaService.GetAllNewProductPositionsAsync();
            model.AvailableNewProductPositions = new List<SelectListItem>
            {
                new SelectListItem { Text = "Select Position", Value = "" }
            };
            
            foreach (var pos in positions)
            {
                model.AvailableNewProductPositions.Add(new SelectListItem
                {
                    Text = pos,
                    Value = pos,
                    Selected = pos.Equals(model.Newproductdropdown, StringComparison.InvariantCultureIgnoreCase)
                });
            }
            return View("~/Plugins/nop4all.megaslider/Views/Configure.cshtml", model);
        }

        [HttpPost]
        [CheckPermission(StandardPermission.Configuration.MANAGE_PLUGINS)]
        public async Task<IActionResult> Configure(ConfigurationModel model)
        {
            var storeScope = await _storeContext.GetActiveStoreScopeConfigurationAsync();
            var megasliderSettings = await _settingService.LoadSettingAsync<MegasliderSettings>(storeScope);
             
            megasliderSettings.Enable = model.Enable;
            megasliderSettings.Autoplay = model.Autoplay; 
            megasliderSettings.MainSliderDots = model.MainSliderDots;
            megasliderSettings.MainSliderArrows = model.MainSliderArrows;
            megasliderSettings.SliderHeight = model.SliderHeight;
            megasliderSettings.Newproductdropdown = model.Newproductdropdown;
            megasliderSettings.AnimationRepeat = model.AnimationRepeat;

            await _settingService.SaveSettingOverridablePerStoreAsync(megasliderSettings, x => x.Enable, model.Enable_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(megasliderSettings, x => x.Autoplay, model.Autoplay_OverrideForStore, storeScope, false); 
            await _settingService.SaveSettingOverridablePerStoreAsync(megasliderSettings, x => x.MainSliderDots, model.MainSliderDots_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(megasliderSettings, x => x.MainSliderArrows, model.MainSliderArrows_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(megasliderSettings, x => x.SliderHeight, model.SliderHeight_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(megasliderSettings, x => x.AnimationRepeat, model.AnimationRepeat_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(megasliderSettings, x => x.Newproductdropdown, model.Newproductdropdown_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingAsync(megasliderSettings);
            await _settingService.ClearCacheAsync();
            _notificationService.SuccessNotification(await _localizationService.GetResourceAsync("Admin.Plugins.Saved"));

            return await Configure();
        }
        #endregion

        #region Item Slider 
        public virtual IActionResult SliderList(int groupId)
        {
            var model = new SliderSearchModel
            {
                GroupId = groupId
            };
            model.SetGridPageSize();

            return View("~/Plugins/nop4all.megaslider/Views/SliderList.cshtml", model);
        }

        [HttpPost]
        public virtual async Task<IActionResult> SliderList(SliderSearchModel searchModel, int groupId)
        {
            searchModel.GroupId = groupId;

            var allcancelorder = await _megaService.GetAllSliderAsync(groupSliderId: searchModel.GroupId, pageIndex: searchModel.Page - 1, pageSize: searchModel.PageSize);

            var model = await new SliderListModel().PrepareToGridAsync(searchModel, allcancelorder, () =>
            {
                return allcancelorder.SelectAwait(async co =>
                {
                    var sliderModel = new SliderModel();

                    sliderModel.Id = co.Id;
                    sliderModel.Name = co.Name;
                    sliderModel.DisplayOrder = co.DisplayOrder;
                    sliderModel.Enable = co.Enable;

                    return sliderModel;
                });
            });
            searchModel.SetGridPageSize();

            return Json(model);
        }

        public virtual async Task<IActionResult> CreateSlider(int groupId)
        {
            var model = await _sliderFactories.PrepareSliderModelAsync(new SliderModel(), null);

            var groupdetails = await _megaService.GetSliderGroupByIdAsync(groupId);
            if (groupdetails != null)
            {
                model.Menu = groupdetails.Menu;
            }
            model.GroupId = groupId;

            return View("~/Plugins/nop4all.megaslider/Views/CreateMegaSlider/Create.cshtml", model);
        }

        [HttpPost, ParameterBasedOnFormName("save-continue", "continueEditing")]
        public virtual async Task<IActionResult> CreateSlider(SliderModel model, bool continueEditing)
        {
           //if (ModelState.IsValid)
            //{
               
             var slider = new MegaSlider();
             slider.DisplayOrder = model.DisplayOrder;
             slider.Name = model.Name;
             slider.Title = model.Title;
             slider.ShortDescription = model.ShortDescription;
             slider.Positioning = (int)model.Positioning;
             slider.HtmlContent = model.HtmlContent ?? "";
             slider.ContentType = model.ContentType;
             slider.ProductType = model.ProductType;
             //slider.WidgetZone = model.WidgetZone;
             slider.Enable = model.Enable;
             //slider.IncludeTop = model.IncludeTop;
             slider.NewProductseffect = model.NewProductseffect;
             slider.FeaturedProductEffect = model.FeaturedProductEffect;
             slider.SellProductModelEffect = model.SellProductModelEffect;
             slider.ProductSliderDots = model.ProductSliderDots;
             slider.ProductSliderArrows = model.ProductSliderArrows;
             slider.SliderDelay = model.SliderDelay;

             //CTA Button
             slider.CTAButton1IsVisible = model.CTAButton1IsVisible;
             slider.CTAButton1Text = model.CTAButton1Text;
             slider.CTAButton1StyleId = model.CTAButton1StyleId;
             slider.CTAButton1BackgroundColor = model.CTAButton1BackgroundColor;
             slider.CTAButton1TextColor = model.CTAButton1TextColor;
             slider.CTAButton1RedirectUrl = model.CTAButton1RedirectUrl;
             slider.CTAButton1FontSize = model.CTAButton1FontSize;

             slider.CTAButton2IsVisible = model.CTAButton2IsVisible;
             slider.CTAButton2Text = model.CTAButton2Text;
             slider.CTAButton2StyleId = model.CTAButton2StyleId;
             slider.CTAButton2BackgroundColor = model.CTAButton2BackgroundColor;
             slider.CTAButton2TextColor = model.CTAButton2TextColor;
             slider.CTAButton2RedirectUrl = model.CTAButton2RedirectUrl;
             slider.CTAButton2FontSize = model.CTAButton2FontSize;

             //Content model
             slider.BadgeText = model.BadgeText;
             slider.BadgeImageId = model.BadgeImageId;
             slider.PriceText = model.PriceText;
             slider.SlideAltDescription = model.SlideAltDescription;
             slider.Cta1OpenInNewTab = model.Cta1OpenInNewTab;
             slider.Cta2OpenInNewTab = model.Cta2OpenInNewTab;

             //Zone model
             slider.ZoneType = model.ZoneType;

             //Left Zone
             slider.LeftImageId = model.LeftImageId;
             slider.LeftImageLink = model.LeftImageLink;
             slider.LeftColor = model.LeftColor;
             slider.LeftEmpty = model.LeftEmpty;
             slider.LeftOpenInNewTab = model.LeftOpenInNewTab;
             slider.LeftHideOnDesktop = model.LeftHideOnDesktop;
             slider.LeftHideOnMobile = model.LeftHideOnMobile;
             slider.LeftImageAlt = model.LeftImageAlt;
             slider.LeftOverlay = model.LeftOverlay;
             slider.LeftColorpreset = model.LeftColorpreset;
             slider.LeftZoneType = model.LeftZoneType;

             //Right Zone
             slider.RightImageId  = model.RightImageId;
             slider.RightImageLink = model.RightImageLink;
             slider.RightColor = model.RightColor;
             slider.RightEmpty = model.RightEmpty;
             slider.RightOpenInNewTab = model.RightOpenInNewTab;
             slider.RightHideOnDesktop = model.RightHideOnDesktop;
             slider.RightHideOnMobile = model.RightHideOnMobile;
             slider.RightImageAlt = model.RightImageAlt;
             slider.RightOverlay = model.RightOverlay;
             slider.RightColorpreset = model.RightColorpreset;
             slider.RightZoneType = model.RightZoneType;

             // layout model
             slider.TextBlockOffset = model.TextBlockOffset;
             slider.Top = model.Top;
             slider.Right = model.Right;
             slider.Bottom = model.Bottom;
             slider.Left = model.Left;
             slider.TextBlockPosition = (int)model.TextBlockPosition;
             slider.ContentSpacing = (int)model.ContentSpacing;
             slider.BackgroundType = model.BackgroundType;
             slider.BackgroundColor = model.BackgroundColor;
             slider.BackgroundImageId = model.BackgroundImageId;
             slider.BackgroundSize = model.BackgroundSize;
             slider.BackgroundOverlay = model.BackgroundOverlay;
             slider.TextAlignment = model.TextAlignment;
             slider.BlockStyle = model.BlockStyle;
             slider.TextTheme = model.TextTheme;
             slider.TitleFontSize = model.TitleFontSize;
             slider.Cardtheme = (int)model.Cardtheme;
             slider.Cardbackgroundcolor = model.Cardbackgroundcolor;
             
             //new 
             slider.BackgroundVideoTypeId = model.BackgroundVideoTypeId;
             slider.BackgroundVideoUrl = model.BackgroundVideoUrl;
             slider.IsAutoPlay = model.IsAutoPlay;
             slider.UseNaturalVideoSizeOnMobile = model.UseNaturalVideoSizeOnMobile;

            //remove code 
            //slider.TitleFontSize = model.TitleFontSize;
            //slider.DescriptionFontSize = model.DescriptionFontSize;
            //slider.ContentLayerPositions = (int)model.ContentLayerPositions;
            //slider.ContentLayerPositionsSecond = (int)model.ContentLayerPositions;
            //slider.ContentLayerPositionsThird = (int)model.ContentLayerPositions;
            //slider.Content = model.Content;
            //slider.TitleFontSize = model.TitleFontSize;
            //slider.DescriptionFontSize = model.DescriptionFontSize;
            //slider.ContentLayer = model.ContentLayer;
            //slider.Texttransitions = model.Texttransitions;
            //slider.TransitionEffectDelay = model.TransitionEffectDelay;
            //slider.ContentLayer3 = model.ContentLayer3;
            //slider.AllowRepeatAnimation = model.AllowRepeatAnimation;



            await _megaService.InsertSliderAsync(slider);

            foreach (var localized in model.Locales)
            {
                await _localizedEntityService.SaveLocalizedValueAsync(
                    slider,
                    x => x.Title,
                    localized.Title,
                    localized.LanguageId);
                await _localizedEntityService.SaveLocalizedValueAsync(
                    slider,
                    x => x.ShortDescription,
                    localized.ShortDescription,
                    localized.LanguageId);
                await _localizedEntityService.SaveLocalizedValueAsync(
                    slider,
                    x => x.HtmlContent,
                    localized.HtmlContent,
                    localized.LanguageId);
                await _localizedEntityService.SaveLocalizedValueAsync(slider,
                    x => x.BadgeText,
                    localized.BadgeText,
                    localized.LanguageId);
                await _localizedEntityService.SaveLocalizedValueAsync(slider,
                    x => x.PriceText,
                    localized.PriceText,
                    localized.LanguageId);
                await _localizedEntityService.SaveLocalizedValueAsync(slider,
                    x => x.BackgroundVideoUrl,
                    localized.BackgroundVideoUrl,
                    localized.LanguageId);

                //remove code 
                //await _localizedEntityService.SaveLocalizedValueAsync(
                //    slider,
                //    x => x.Content,
                //    localized.Content,
                //    localized.LanguageId);

                //await _localizedEntityService.SaveLocalizedValueAsync(
                //    slider,
                //    x => x.ContentLayer,
                //    localized.ContentLayer,
                //    localized.LanguageId);
            }

            var sliderGroup = await _megaService.GetSliderGroupByIdAsync(model.GroupId);

            var existingStoreMappings = (await _storeMappingService.GetStoreMappingsAsync(sliderGroup))
                .Select(x => x.StoreId)
                .ToList();
            await _storeMappingService.SaveStoreMappingsAsync(slider, existingStoreMappings);
            await _megaService.InsertSliderMappingAsync(slider.Id, model.GroupId);
                await UpdateLocalesAsync(slider, model);

                _notificationService.SuccessNotification(await _localizationService.GetResourceAsync("Plugin.nop4all.megaslider.Save"));
                if (!continueEditing)
                    return RedirectToAction("EditGroupSlider", new { id = model.GroupId });

                return RedirectToAction("Edit", new { id = slider.Id });
            //}
            //    var models = await _sliderFactories.PrepareSliderModelAsync(model, null);
            //    return View("~/Plugins/nop4all.megaslider/Views/CreateMegaSlider/Create.cshtml", models);
        }

        public virtual async Task<IActionResult> Edit(int id)
        {
            var category = await _megaService.GetSliderByIdAsync(id);

            if (category == null)

                return RedirectToAction("GroupSliderList");

            var group = await _megaService.GetGroupBySliderIdAsync(id);

            var groupdetails = await _megaService.GetSliderGroupByIdAsync(group.GroupSliderId);

            if (category == null)
                return RedirectToAction("GroupSliderList");

            var slidermodel = new SliderModel();

            var model = await _sliderFactories.PrepareSliderModelAsync(slidermodel, category);

            model.GroupId = group.GroupSliderId;

            if(groupdetails !=null)
            {
                model.Menu = groupdetails.Menu;
            }
             
            //var widgetZones = new List<SelectListItem>
            //{
            //   new SelectListItem
            //   {
            //      Text = "Select Widget Zone",
            //      Value = "",
            //      Selected = string.IsNullOrEmpty(model.WidgetZone)
            //   }
            //};

            //var zones = await _megaService.GetAllWidgetZone();
            //widgetZones.AddRange(zones.Select(zone => new SelectListItem
            //{
            //    Text = zone,
            //    Value = zone,
            //    Selected = zone.Equals(model.WidgetZone, StringComparison.InvariantCultureIgnoreCase)
            //}));

            //model.Availablewidgetzone = widgetZones; 

            return View("~/Plugins/nop4all.megaslider/Views/CreateMegaSlider/Edit.cshtml", model);
        }

        [HttpPost, ParameterBasedOnFormName("save-continue", "continueEditing")]
        public virtual async Task<IActionResult> Edit(SliderModel model, bool continueEditing)
        {
            var slider = await _megaService.GetSliderByIdAsync(model.Id);
            if (slider == null)
                return RedirectToAction("Configure");
			 //if (ModelState.IsValid)
            //{
            
            slider.Enable = model.Enable;
            slider.Name = model.Name;
            slider.Title = model.Title;
            slider.ShortDescription = model.ShortDescription;
            slider.HtmlContent = model.HtmlContent ?? "";
            slider.DisplayOrder = model.DisplayOrder;
            slider.ContentType = model.ContentType;
            slider.ProductType = model.ProductType;
            slider.Positioning = (int)model.Positioning;
            
            //slider.WidgetZone = model.WidgetZone;
            //slider.IncludeTop = model.IncludeTop;
            slider.NewProductseffect = model.NewProductseffect;
            slider.FeaturedProductEffect = model.FeaturedProductEffect;
            slider.SellProductModelEffect = model.SellProductModelEffect;
            slider.ProductSliderDots = model.ProductSliderDots;
            slider.ProductSliderArrows = model.ProductSliderArrows;
            slider.SliderDelay = model.SliderDelay;

            //CTA Button 
            slider.CTAButton1IsVisible = model.CTAButton1IsVisible;
            slider.CTAButton1Text = model.CTAButton1Text;
            slider.CTAButton1StyleId = model.CTAButton1StyleId;
            slider.CTAButton1BackgroundColor = model.CTAButton1BackgroundColor;
            slider.CTAButton1TextColor = model.CTAButton1TextColor;
            slider.CTAButton1RedirectUrl = model.CTAButton1RedirectUrl;
            slider.CTAButton1FontSize = model.CTAButton1FontSize;

            slider.CTAButton2IsVisible = model.CTAButton2IsVisible;
            slider.CTAButton2Text = model.CTAButton2Text;
            slider.CTAButton2StyleId = model.CTAButton2StyleId;
            slider.CTAButton2BackgroundColor = model.CTAButton2BackgroundColor;
            slider.CTAButton2TextColor = model.CTAButton2TextColor;
            slider.CTAButton2RedirectUrl = model.CTAButton2RedirectUrl;
            slider.CTAButton2FontSize = model.CTAButton2FontSize;
            
            //new conten model
            slider.BadgeText = model.BadgeText;
            slider.BadgeImageId = model.BadgeImageId;
            slider.PriceText = model.PriceText;
            slider.SlideAltDescription = model.SlideAltDescription;
            slider.Cta1OpenInNewTab = model.Cta1OpenInNewTab;
            slider.Cta2OpenInNewTab = model.Cta2OpenInNewTab;

            //Zone model
            slider.ZoneType = model.ZoneType;

            //Left Zone
            slider.LeftImageId = model.LeftImageId;
            slider.LeftImageLink = model.LeftImageLink;
            slider.LeftColor = model.LeftColor;
            slider.LeftEmpty = model.LeftEmpty;
            slider.LeftOpenInNewTab = model.LeftOpenInNewTab;
            slider.LeftHideOnDesktop = model.LeftHideOnDesktop;
            slider.LeftHideOnMobile = model.LeftHideOnMobile;
            slider.LeftImageAlt = model.LeftImageAlt;
            slider.LeftOverlay = model.LeftOverlay;
            slider.LeftColorpreset = model.LeftColorpreset;
            slider.LeftZoneType = model.LeftZoneType;

            //Right Zone
            slider.RightImageId = model.RightImageId;
            slider.RightImageLink = model.RightImageLink;
            slider.RightColor = model.RightColor;
            slider.RightEmpty = model.RightEmpty;
            slider.RightOpenInNewTab = model.RightOpenInNewTab;
            slider.RightHideOnDesktop = model.RightHideOnDesktop;
            slider.RightHideOnMobile = model.RightHideOnMobile;
            slider.RightImageAlt = model.RightImageAlt;
            slider.RightOverlay = model.RightOverlay;
            slider.RightColorpreset = model.RightColorpreset;
            slider.RightZoneType = model.RightZoneType;

            // layout model
            slider.TextBlockOffset = model.TextBlockOffset;
            slider.Top = model.Top;
            slider.Right = model.Right;
            slider.Bottom = model.Bottom;
            slider.Left = model.Left;
            slider.TextBlockPosition = (int)model.TextBlockPosition;
            slider.ContentSpacing = (int)model.ContentSpacing;

            slider.BackgroundType = model.BackgroundType;
            slider.BackgroundColor = model.BackgroundColor;
            slider.BackgroundImageId = model.BackgroundImageId;
            slider.BackgroundSize = model.BackgroundSize;
            slider.BackgroundOverlay = model.BackgroundOverlay;
            slider.TextAlignment = model.TextAlignment;
            slider.BlockStyle = model.BlockStyle;
            slider.TextTheme = model.TextTheme;
            slider.TitleFontSize = model.TitleFontSize;
            slider.Cardtheme = (int)model.Cardtheme;
            slider.Cardbackgroundcolor = model.Cardbackgroundcolor;
            slider.BackgroundVideoUrl = model.BackgroundVideoUrl;
            slider.BackgroundVideoTypeId = model.BackgroundVideoTypeId;
            slider.IsAutoPlay = model.IsAutoPlay;
            slider.UseNaturalVideoSizeOnMobile = model.UseNaturalVideoSizeOnMobile;

            //Client remove code 
            //slider.Content = model.Content;
            //slider.DescriptionFontSize = model.DescriptionFontSize;
            //slider.ContentLayerPositions = (int)model.ContentLayerPositions;
            //slider.ContentLayerPositionsSecond = (int)model.ContentLayerPositionsSecond;
            //slider.ContentLayerPositionsThird = (int)model.ContentLayerPositionsThird;
            //slider.ContentLayer = model.ContentLayer;
            //slider.Texttransitions = model.Texttransitions;
            //slider.TransitionEffectDelay = model.TransitionEffectDelay;
            //slider.ContentLayer3 = model.ContentLayer3;
            //slider.AllowRepeatAnimation = model.AllowRepeatAnimation; 


            //Change 
            if (model.ContentType == 3)
            {
                //client remove code
			    //slider.Content = model.Content;
                //slider.ContentLayer = model.ContentLayer;
                //slider.ContentLayer3 = model.ContentLayer3;

                // ONLY HTML SAVE
                slider.HtmlContent = model.HtmlContent ?? "";
            }
            else
            {
                //Client remove code
			    //slider.ContentLayer = model.ContentLayer;

                slider.HtmlContent = "";
            }
            var sliderGroup = await _megaService.GetSliderGroupByIdAsync(model.GroupId);

            var existingStoreMappings = (await _storeMappingService.GetStoreMappingsAsync(sliderGroup))
                .Select(x => x.StoreId)
                .ToList();
            await _storeMappingService.SaveStoreMappingsAsync(slider, existingStoreMappings);
            await _megaService.UpdateSliderAsync(slider);

            await UpdateLocalesAsync(slider, model);

            _notificationService.SuccessNotification(
                await _localizationService.GetResourceAsync("Plugin.nop4all.megaslider.update")
            );

            if (continueEditing)
                return RedirectToAction("Edit", new { id = model.Id });

            var models = await _sliderFactories.PrepareSliderModelAsync(model, slider);
            return View("~/Plugins/nop4all.megaslider/Views/CreateMegaSlider/Edit.cshtml", models);
            //}
        }

        [HttpPost]
        public virtual async Task<IActionResult> MegasliderEdit(SliderModel model)
        {
            var slider = await _megasliderServices.GetSliderByIdAsync(model.Id);
            
            slider.Enable = model.Enable;
            await _megasliderServices.UpdateMegaSliderAsync(slider);

            return new NullJsonResult();
        }

        [HttpPost]
        public virtual async Task<IActionResult> Delete(int id)
        {
            //try to get a category with the specified id
            var category = await _megaService.GetSliderByIdAsync(id);
            if (category == null)
                return RedirectToAction("Configure");

            await _megaService.DeleteGroupSliderMappingAsync(id);

            await _megaService.DeleteSliderAsync(category);
            return new NullJsonResult();
        }

        [HttpPost]
        public async Task<IActionResult> UploadVideo(IFormFile videoFile)
        {
            // ── 1. Null check ──
            if (videoFile == null || videoFile.Length == 0)
                return Json(new { success = false, message = "No file uploaded." });

            // ── 2. MIME type server-side validation ──
            var allowedMimeTypes = new[] { "video/mp4", "video/webm" };
            if (!allowedMimeTypes.Contains(videoFile.ContentType?.ToLower()))
                return Json(new { success = false, message = "Only MP4 and WebM formats are supported." });

            // ── 3. Extension validation ──
            var extension = Path.GetExtension(videoFile.FileName)?.ToLower();
            if (extension != ".mp4" && extension != ".webm")
                return Json(new { success = false, message = "Only MP4 and WebM formats are supported." });

            // ── 4. Filename sanitization ──
            var originalName = Path.GetFileNameWithoutExtension(videoFile.FileName ?? "video");

            // Remove unsafe characters — replace with underscore
            var sanitized = System.Text.RegularExpressions.Regex
                .Replace(originalName, @"[<>\/\\:*?|""'\s\.]+", "_");

            // Remove path traversal sequences
            sanitized = sanitized.Replace("..", "_");

            // Max 100 chars total (filename + extension)
            var maxNameLength = 100 - extension.Length;
            if (sanitized.Length > maxNameLength)
                sanitized = sanitized.Substring(0, maxNameLength);

            // Use sanitized name + GUID suffix to avoid conflicts
            var safeFileName = sanitized + "_" + Guid.NewGuid().ToString("N").Substring(0, 8) + extension;

            // ── 5. Save file (existing logic unchanged) ──
            var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/videos");

            if (!Directory.Exists(folderPath))
                Directory.CreateDirectory(folderPath);

            var filePath = Path.Combine(folderPath, safeFileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await videoFile.CopyToAsync(stream);
            }

            var url = "/videos/" + safeFileName;

            return Json(new { success = true, url = url });
        }

        #endregion

        #region Group Slider 
        public IActionResult GroupSliderList()
        {
            var model = new GroupSliderSearchModel();
            model.SetGridPageSize();

            return View("~/Plugins/nop4all.megaslider/Views/GroupMegaSlider/GroupSliderList.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> GroupSliderList(GroupSliderSearchModel searchModel)
        {
            var model = await _sliderFactories.PrepareGroupSliderListModelAsync(searchModel);
            return Json(model);
        }

        public virtual async Task<IActionResult> CreateGroupSlider()
        {
            var model = await _sliderFactories.PrepareGroupSliderModelAsync(new GroupSliderModel(), null);
            return View("~/Plugins/nop4all.megaslider/Views/GroupMegaSlider/Create.cshtml", model);
        }

        [HttpPost, ParameterBasedOnFormName("save-continue", "continueEditing")]
        public virtual async Task<IActionResult> CreateGroupSlider(GroupSliderModel model, bool continueEditing)
        {
            if (ModelState.IsValid)
            {
                var groupslider = new GroupMegaSlider();
                groupslider.Enable = model.Enable;
                groupslider.Name = model.Name;
                groupslider.DisplayOrder = model.DisplayOrder;
                groupslider.Widgetzone = model.Widgetzone;
                groupslider.LimitedToStores = model.LimitedToStores;
                groupslider.Show = model.Show;
                groupslider.Hide = model.Hide;
                groupslider.RightSide = model.RightSide;
                groupslider.LeftSide = model.LeftSide;
                groupslider.Menu = model.Menu;
                groupslider.DotArrrow = model.DotArrrow; 
                groupslider.GroupSliderHeight = model.GroupSliderHeight;
                groupslider.AnimationEffectId = model.AnimationEffectId;
                groupslider.TransitionAnimationEffectId = model.TransitionAnimationEffectId;

                await _megaService.InsertGroupSliderAsync(groupslider);
                await _storeMappingService.SaveStoreMappingsAsync(groupslider, model.SelectedStoreIds);

                _notificationService.SuccessNotification(await _localizationService.GetResourceAsync("Plugin.nop4all.megaslider.Save"));
                if (!continueEditing)
                    return RedirectToAction("GroupSliderList");

                return RedirectToAction("EditGroupSlider", new { id = groupslider.Id });
            }
            var models = await _sliderFactories.PrepareGroupSliderModelAsync(model, null);
            return View("~/Plugins/nop4all.megaslider/Views/GroupMegaSlider/Create.cshtml", models);
        }

        public virtual async Task<IActionResult> EditGroupSlider(int id)
        {
            var category = await _megaService.GetSliderGroupByIdAsync(id);
            if (category == null)
                return RedirectToAction("GroupSliderList");

            var groupslidermodel = new GroupSliderModel();

            var model = await _sliderFactories.PrepareGroupSliderModelAsync(groupslidermodel, category);

            var widgetZones = new List<SelectListItem>
            {
               new SelectListItem
               {
                   Text = "Select Widget Zone",
                   Value = "",
                   Selected = string.IsNullOrEmpty(model.Widgetzone)
               }
            };
            var zones = await _megaService.GetAllWidgetZone();
            widgetZones.AddRange(zones.Select(zone => new SelectListItem
            {
                Text = zone,
                Value = zone,
                Selected = zone.Equals(model.Widgetzone, StringComparison.InvariantCultureIgnoreCase)
            }));

            model.Availablewidgetzone = widgetZones;

            return View("~/Plugins/nop4all.megaslider/Views/GroupMegaSlider/Edit.cshtml", model);
        }

        [HttpPost, ParameterBasedOnFormName("save-continue", "continueEditing")]
        public virtual async Task<IActionResult> EditGroupSlider(GroupSliderModel model, bool continueEditing)
        {
            var groupslider = await _megaService.GetSliderGroupByIdAsync(model.Id);
            if (groupslider == null)
                return RedirectToAction("GroupSliderList");

            if (ModelState.IsValid)
            {
                groupslider.Enable = model.Enable;
                groupslider.Name = model.Name;
                groupslider.DisplayOrder = model.DisplayOrder;
                groupslider.Widgetzone = model.Widgetzone;
                groupslider.LimitedToStores = model.LimitedToStores;
                groupslider.Show = model.Show;
                groupslider.Hide = model.Hide;
                groupslider.RightSide = model.RightSide;
                groupslider.LeftSide = model.LeftSide;
                groupslider.DotArrrow = model.DotArrrow;
                groupslider.Menu = model.Menu; 
                groupslider.GroupSliderHeight = model.GroupSliderHeight;
                groupslider.AnimationEffectId = model.AnimationEffectId;
                groupslider.TransitionAnimationEffectId = model.TransitionAnimationEffectId;


                var sliders = await _megaService.GetAllSliderByGroupIdAsync(model.Id, 0, int.MaxValue);

                var existingStoreMappings = (await _storeMappingService.GetStoreMappingsAsync(groupslider))
                    .Select(x => x.StoreId)
                    .ToList();
                // Save same mappings for all child sliders
                foreach (var slider in sliders)
                {
                    await _storeMappingService.SaveStoreMappingsAsync(
                        slider,
                        model.SelectedStoreIds);
                }
                await _storeMappingService.SaveStoreMappingsAsync(groupslider, model.SelectedStoreIds);
                await _megaService.UpdateGroupSliderAsync(groupslider);

                _notificationService.SuccessNotification(
                    await _localizationService.GetResourceAsync("Plugin.nop4all.megaslider.update")
                );

                if (!continueEditing)
                    return RedirectToAction("GroupSliderList");
            }

            var models = await _sliderFactories.PrepareGroupSliderModelAsync(model, groupslider);
            return View("~/Plugins/nop4all.megaslider/Views/GroupMegaSlider/Edit.cshtml", models);
        }

        [HttpPost]
        public virtual async Task<IActionResult> GroupMegasliderEdit(GroupSliderModel model)
        {
            var groupslider = await _megasliderServices.GetSliderGroupByIdAsync(model.Id);
            groupslider.Enable = model.Enable;
            groupslider.DisplayOrder = model.DisplayOrder;
            await _megasliderServices.UpdateGroupSliderAsync(groupslider);

            return new NullJsonResult();
        }

        [HttpPost]
        public virtual async Task<IActionResult> DeleteGroupSlider(int id)
        {
            var group = await _megaService.GetSliderGroupByIdAsync(id);
            if (group == null)
                return new NullJsonResult();

            var sliders = await _megaService.GetAllSliderAsync(groupSliderId: id);

            foreach (var slider in sliders)
            {
                await _megaService.DeleteGroupSliderMappingAsync(slider.Id);

                await _megaService.DeleteSliderAsync(slider);
            }

            await _megaService.DeleteGroupSliderAsync(group);

            return new NullJsonResult();
        }
        #endregion

        #region Featured Product

        [HttpPost]
        public virtual async Task<IActionResult> FeatureProductList(FeatureProductSearchModel searchModel)
        {
            //try to get a category with the specified id
            var category = await _megaService.GetSliderByIdAsync(searchModel.MegaSliderId)
                ?? throw new ArgumentException("No slider found with the specified id");

            //prepare model
            var model = await _sliderFactories.PrepareCategoryProductListModelAsync(searchModel, category);

            return Json(model);
        }

        public virtual async Task<IActionResult> FeatureProductUpdate(FeatureProductModel model)
        {
            //try to get a product category with the specified id
            var productCategory = await _megaService.GetFeatureproductSliderByIdAsync(model.Id)
                ?? throw new ArgumentException("No product  mapping found with the specified id");

            //fill entity from product
            productCategory.DisplayOrder = model.DisplayOrder;
            await _megaService.UpdateMegaSliderFeatureProductAsync(productCategory);

            return new NullJsonResult();
        }

        public virtual async Task<IActionResult> FeatureProductDelete(int id)
        {
            //try to get a product category with the specified id
            var productCategory = await _megaService.GetFeatureproductSliderByIdAsync(id)
                ?? throw new ArgumentException("No product category mapping found with the specified id", nameof(id));

            await _megaService.DeleteMegaSliderFeatureProductAsync(productCategory);

            return new NullJsonResult();
        }

        public virtual async Task<IActionResult> FeatureProductAddPopup(int megaSliderId)
        {
            //prepare model
            var model = await _sliderFactories.PrepareAddProductToFeatureSearchModelAsync(new AddProductToFeatureSearchModel());
            model.AddFeatureProductToSliderModel.MegaSliderId = megaSliderId;

            return View("~/Plugins/nop4all.megaslider/Views/CreateMegaSlider/FeatureProductAddPopup.cshtml", model);
        }

        [HttpPost]
        public virtual async Task<IActionResult> FeatureProductAddPopupList(AddProductToFeatureSearchModel searchModel)
        {
            //prepare model
            var model = await _sliderFactories.PrepareAddFeatureProductToSliderListModelAsync(searchModel);

            return Json(model);
        }

        [HttpPost]
        [FormValueRequired("save")]
        public virtual async Task<IActionResult> FeatureProductAddPopup(AddFeatureProductToSliderModel model)
        {
            //get selected products
            var selectedProducts = await _productService.GetProductsByIdsAsync(model.SelectedProductIds.ToArray());
            if (selectedProducts.Any())
            {
                var existingProductCategories = await _megaService.GetFeatureProductBySliderAsync(model.MegaSliderId, showHidden: true);
                foreach (var product in selectedProducts)
                {
                    //whether product category with such parameters already exists
                    if (_megaService.FindFeatureProduct(existingProductCategories, product.Id, model.MegaSliderId) != null)
                        continue;

                    //insert the new product category mapping
                    await _megaService.InsertMegaSliderFeatureProductAsync(new MegaSliderFeaturedProducts
                    {
                        SliderId = model.MegaSliderId,
                        ProductId = product.Id,
                        DisplayOrder = 1
                    });
                }
            }

            ViewBag.RefreshPage = true;

            return View("~/Plugins/nop4all.megaslider/Views/CreateMegaSlider/FeatureProductAddPopup.cshtml", new AddProductToFeatureSearchModel());
        }
        #endregion

        #region New Product
        [HttpPost]
        public virtual async Task<IActionResult> NewProductList(NewProductSearchModel searchModel)
        {
            //try to get a category with the specified id
            var category = await _megaService.GetSliderByIdAsync(searchModel.MegaSliderId);

            //prepare model
            var model = await _sliderFactories.PrepareNewProductListModelAsync(searchModel, category);

            return Json(model);
        }

        public virtual async Task<IActionResult> NewProductUpdate(NewProductModel model)
        {
            //try to get a product category with the specified id
            var productCategory = await _megaService.GetNewproductSliderByIdAsync(model.Id)
                ?? throw new ArgumentException("No product  mapping found with the specified id");

            //fill entity from product
            productCategory.DisplayOrder = model.DisplayOrder;
            await _megaService.UpdateMegaSliderNewProductAsync(productCategory);

            return new NullJsonResult();
        }

        public virtual async Task<IActionResult> NewProductDelete(int id)
        {
            //try to get a product category with the specified id
            var productCategory = await _megaService.GetNewproductSliderByIdAsync(id)
                ?? throw new ArgumentException("No product category mapping found with the specified id", nameof(id));

            await _megaService.DeleteMegaSliderNewProductAsync(productCategory);

            return new NullJsonResult();
        }

        public virtual async Task<IActionResult> NewProductAddPopup(int megaSliderId)
        {
            //prepare model
            var model = await _sliderFactories.PrepareAddProductToNewSearchModelAsync(new AddProductToNewSearchModel());
            model.AddNewProductToSliderModel.MegaSliderId = megaSliderId;

            return View("~/Plugins/nop4all.megaslider/Views/CreateMegaSlider/NewProductAddPopup.cshtml", model);
        }

        [HttpPost]
        public virtual async Task<IActionResult> NewProductAddPopupList(AddProductToNewSearchModel searchModel)
        {
            //prepare model
            var model = await _sliderFactories.PrepareAddNewProductToSliderListModelAsync(searchModel);

            return Json(model);
        }

        [HttpPost]
        [FormValueRequired("save")]
        public virtual async Task<IActionResult> NewProductAddPopup(AddNewProductToSliderModel model)
        {
            //get selected products
            var selectedProducts = await _productService.GetProductsByIdsAsync(model.SelectedProductIds.ToArray());
            if (selectedProducts.Any())
            {
                var existingProductCategories = await _megaService.GetNewProductBySliderAsync(model.MegaSliderId, showHidden: true);
                foreach (var product in selectedProducts)
                {
                    //whether product category with such parameters already exists
                    if (_megaService.FindNewProduct(existingProductCategories, product.Id, model.MegaSliderId) != null)
                        continue;

                    //insert the new product category mapping
                    await _megaService.InserMegaSliderNewProductAsync(new MegaSliderNewProducts
                    {
                        SliderId = model.MegaSliderId,
                        ProductId = product.Id,
                        DisplayOrder = 1
                    });
                }
            }

            ViewBag.RefreshPage = true;

            return View("~/Plugins/nop4all.megaslider/Views/CreateMegaSlider/NewProductAddPopup.cshtml", new AddProductToNewSearchModel());
        }

        #endregion

        #region Sale Prdouct
        [HttpPost]
        public virtual async Task<IActionResult> SellProductList(SellProductSearchModel searchModel)
        {
            //try to get a category with the specified id
            var category = await _megaService.GetSliderByIdAsync(searchModel.MegaSliderId)
                ?? throw new ArgumentException("No slider found with the specified id");

            //prepare model
            var model = await _sliderFactories.PrepareSellProductListModelAsync(searchModel, category);

            return Json(model);
        }

        public virtual async Task<IActionResult> SaleProductUpdate(SellProductModel model)
        {
            //try to get a product category with the specified id
            var productCategory = await _megaService.GetSellproductSliderByIdAsync(model.Id)
                ?? throw new ArgumentException("No product  mapping found with the specified id");

            //fill entity from product
            productCategory.DisplayOrder = model.DisplayOrder;
            await _megaService.UpdateMegaSliderSellProductAsync(productCategory);

            return new NullJsonResult();
        }

        public virtual async Task<IActionResult> SellProductDelete(int id)
        {
            //try to get a product category with the specified id
            var productCategory = await _megaService.GetSellproductSliderByIdAsync(id)
                ?? throw new ArgumentException("No product category mapping found with the specified id", nameof(id));

            await _megaService.DeleteMegaSliderSellProductAsync(productCategory);

            return new NullJsonResult();
        }

        public virtual async Task<IActionResult> SaleProductAddPopup(int megaSliderId)
        {
            //prepare model
            var model = await _sliderFactories.PrepareAddProductToSellSearchModelAsync(new AddProductToSellSearchModel());
            model.AddSellProductToSliderModel.MegaSliderId = megaSliderId;

            return View("~/Plugins/nop4all.megaslider/Views/CreateMegaSlider/SaleProductAddPopup.cshtml", model);
        }

        [HttpPost]
        public virtual async Task<IActionResult> SellProductAddPopupList(AddProductToSellSearchModel searchModel)
        {
            //prepare model
            var model = await _sliderFactories.PrepareAddSellProductToSliderListModelAsync(searchModel);

            return Json(model);
        }

        [HttpPost]
        [FormValueRequired("save")]
        public virtual async Task<IActionResult> SellProductAddPopup(AddSellProductToSliderModel model)
        {
            //get selected products
            var selectedProducts = await _productService.GetProductsByIdsAsync(model.SelectedProductIds.ToArray());
            if (selectedProducts.Any())
            {
                var existingProductCategories = await _megaService.GetSellProductBySliderAsync(model.MegaSliderId, showHidden: true);
                foreach (var product in selectedProducts)
                {
                    //whether product category with such parameters already exists
                    if (_megaService.FindSellProduct(existingProductCategories, product.Id, model.MegaSliderId) != null)
                        continue;

                    //insert the new product category mapping
                    await _megaService.InserMegaSliderSellProductAsync(new MegaSliderSellProducts
                    {
                        SliderId = model.MegaSliderId,
                        ProductId = product.Id,
                        DisplayOrder = 1
                    });
                }
            }

            ViewBag.RefreshPage = true;

            return View("~/Plugins/nop4all.megaslider/Views/CreateMegaSlider/SaleProductAddPopup.cshtml", new AddProductToSellSearchModel());
        }

        [HttpGet]
        public async Task<IActionResult> SellProductEditPopup(int id, string btnId, string formId)
        {
            var entity = await _megaService.GetSellProductByIdAsync(id);
            if (entity == null)
                return NotFound();

            var model = new SellProductModel
            {
                Id = entity.Id,
                SliderId = entity.SliderId,
                ProductId = entity.ProductId,
                DisplayOrder = entity.DisplayOrder,
                PictureId = entity.PictureId
            };

            return View("~/Plugins/nop4all.megaslider/Views/CreateMegaSlider/SellProductEditPopup.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> SellProductEditPopup(SellProductModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var entity = await _megaService.GetSellProductByIdAsync(model.Id);
            if (entity == null)
                return NotFound();

            entity.PictureId = model.PictureId;
            entity.DisplayOrder = model.DisplayOrder;

            await _megaService.UpdateSellProductAsync(entity);

            ViewBag.RefreshPage = true;
            ViewBag.btnId = "btnRefreshProducts";
            ViewBag.formId = "category-form";

            return View("~/Plugins/nop4all.megaslider/Views/CreateMegaSlider/SellProductEditPopup.cshtml", model);
        }
        #endregion
        #region Language Resource

        [CheckPermission(StandardPermission.Configuration.MANAGE_PLUGINS)]
        public async Task<IActionResult> List(int language)
        {
            //prepare model
            var mSLanguageResourceSearchModel = new MSLanguageResourceSearchModel
            {
                SelectedLanguage = language
            };
            var model = await _sliderFactories.PrepareMSLanguageResourceSearchModelAsync(mSLanguageResourceSearchModel);

            return View("~/Plugins/nop4all.megaslider/Views/MSLanguageResource/List.cshtml", model);
        }

        [HttpPost]

        [CheckPermission(StandardPermission.Configuration.MANAGE_PLUGINS)]
        public virtual async Task<IActionResult> LanguageResourceList(MSLanguageResourceSearchModel searchmodel)
        {
            //prepare model
            var model = await _sliderFactories.PrepareMSLanguageResourceListModelAsync((searchmodel));

            return Json(model);
        }

        [HttpPost]
        public async Task<IActionResult> LanguageResourceUpdate(MSLanguageResourceModel model)
        {
            if (model.Id == 0)
                return new NullJsonResult();

            var languageresource = await _localizationService.GetLocaleStringResourceByIdAsync(model.Id);

            if (languageresource != null)
            {
                languageresource.ResourceName = model.ResourceName;
                languageresource.ResourceValue = model.Value;
                await _localizationService.UpdateLocaleStringResourceAsync(languageresource);
            }
            return new NullJsonResult();
        }
        #endregion

        #endregion

        #region Product
        [HttpGet]
        public async Task<IActionResult> NewProductEditPopup(int id, string btnId, string formId)
        {
            var entity = await _megaService.GetNewProductByIdAsync(id);
            if (entity == null)
                return NotFound();

            var model = new NewProductModel
            {
                Id = entity.Id,
                SliderId = entity.SliderId,
                ProductId = entity.ProductId,
                DisplayOrder = entity.DisplayOrder,
                PictureId = entity.PictureId
            };

            return View("~/Plugins/nop4all.megaslider/Views/CreateMegaSlider/NewProductEditPopup.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> NewProductEditPopup(NewProductModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var entity = await _megaService.GetNewProductByIdAsync(model.Id);
            if (entity == null)
                return NotFound();

            entity.PictureId = model.PictureId;
            entity.DisplayOrder = model.DisplayOrder;

            await _megaService.UpdateNewProductAsync(entity);

            ViewBag.RefreshPage = true;
            ViewBag.btnId = "btnRefreshProducts";
            ViewBag.formId = "category-form";

            return View("~/Plugins/nop4all.megaslider/Views/CreateMegaSlider/NewProductEditPopup.cshtml", model);
        }

        [HttpGet]
        public async Task<IActionResult> FeatureProductEditPopup(int id, string btnId, string formId)
        {
            var entity = await _megaService.GetFeatureproductSliderByIdAsync(id);
            if (entity == null)
                return NotFound();

            var model = new FeatureProductModel
            {
                Id = entity.Id,
                SliderId = entity.SliderId,
                ProductId = entity.ProductId,
                DisplayOrder = entity.DisplayOrder,
                PictureId = entity.PictureId
            };

            return View("~/Plugins/nop4all.megaslider/Views/CreateMegaSlider/FeatureProductEditPopup.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> FeatureProductEditPopup(FeatureProductModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var entity = await _megaService.GetFeatureproductSliderByIdAsync(model.Id);
            if (entity == null)
                return NotFound();

            entity.PictureId = model.PictureId;
            entity.DisplayOrder = model.DisplayOrder;

            await _megaService.UpdateMegaSliderFeatureProductAsync(entity);

            ViewBag.RefreshPage = true;
            ViewBag.btnId = "btnRefreshProducts";
            ViewBag.formId = "category-form";

            return View("~/Plugins/nop4all.megaslider/Views/CreateMegaSlider/FeatureProductEditPopup.cshtml", model);
        }
        #endregion
    }
}
