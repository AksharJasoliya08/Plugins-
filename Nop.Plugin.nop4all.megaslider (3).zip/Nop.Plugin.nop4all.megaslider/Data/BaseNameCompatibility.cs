﻿using Nop.Data.Mapping;
using Nop.Plugin.nop4all.megaslider.Domain;

namespace Nop.Plugin.nop4all.megaslider.Data
{
    /// <summary>
    /// Base instance of backward compatibility of table naming
    /// </summary>
    public partial class BaseNameCompatibility : INameCompatibility
    {
        public Dictionary<Type, string> TableNames => new()
        {
            { typeof(MegaSlider), "n4a.megaslider.Megaslider" },
            { typeof(SliderMapping), "n4a.megaslider.SliderMapping" },
            { typeof(GroupMegaSlider), "n4a.megaslider.GroupMegaSlider" },
            { typeof(MegaSliderFeaturedProducts), "n4a.megaslider.MegaSliderFeaturedproducts" },
            { typeof(MegaSliderNewProducts), "n4a.megaslider.MegaSliderNewproducts" },
            { typeof(MegaSliderGroupCondition), "n4a.megaslider.MegaSliderGroupCondition" },
            { typeof(MegaSliderSellProducts), "n4a.megaslider.MegaSliderSellproducts" },
            { typeof(CaseStudy), "n4a_references4all_casestudy" },
        };

        public Dictionary<(Type, string), string> ColumnName => new()
        {
        };
    }
}