﻿//using FluentMigrator;
//using Nop.Data.Mapping;
//using Nop.Data.Migrations;
//using Nop.Plugin.nop4all.megaslider.Domain;
//using Nop.Services.Localization;
//using Nop.Web.Framework.Extensions;

//namespace Nop.Plugin.nop4all.megaslider.Data
//{
//    [NopMigration("2026-05-16 03:04:10", "nop4all.megaslider add new fields", MigrationProcessType.Update)]
//    public class DataMigration : Migration
//    {
//        private readonly ILocalizationService _localizationService;

//        public DataMigration(ILocalizationService localizationService)
//        {
//            _localizationService = localizationService;
//        }

//        /// <summary>
//        /// Collect the UP migration expressions
//        /// </summary>
//        /// 
//        public override void Up()
//        {
//            //  Alter.Table(NameCompatibilityManager.GetTableName(typeof(MegaSlider)))

//            var tableName = NameCompatibilityManager.GetTableName(typeof(MegaSlider));

//            if (Schema.Table(tableName).Exists())
//            {
//                //if (!Schema.Table(tableName).Column("BadgeText").Exists())
//                //    Alter.Table(tableName).AddColumn("BadgeText").AsString(500).Nullable();

//                //if (!Schema.Table(tableName).Column("BadgeImageId").Exists())
//                //    Alter.Table(tableName).AddColumn("BadgeImageId").AsInt32().Nullable();

//                //if (!Schema.Table(tableName).Column("PriceText").Exists())
//                //    Alter.Table(tableName).AddColumn("PriceText").AsString(200).Nullable();

//                //if (!Schema.Table(tableName).Column("SlideAltDescription").Exists())
//                //    Alter.Table(tableName).AddColumn("SlideAltDescription").AsString(1000).Nullable();

//                //if (!Schema.Table(tableName).Column("Cta1OpenInNewTab").Exists())
//                //    Alter.Table(tableName).AddColumn("Cta1OpenInNewTab").AsBoolean().NotNullable().WithDefaultValue(false);

//                //if (!Schema.Table(tableName).Column("Cta2OpenInNewTab").Exists())
//                //    Alter.Table(tableName).AddColumn("Cta2OpenInNewTab").AsBoolean().NotNullable().WithDefaultValue(false);

//                if (!Schema.Table(tableName).Column("TextBlockOffset").Exists())
//                    Alter.Table(tableName).AddColumn("TextBlockOffset").AsBoolean().Nullable().WithDefaultValue(false);

//                if (!Schema.Table(tableName).Column("Top").Exists())
//                    Alter.Table(tableName).AddColumn("Top").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("Right").Exists())
//                    Alter.Table(tableName).AddColumn("Right").AsInt32().Nullable();


//                if (!Schema.Table(tableName).Column("Bottom").Exists())
//                    Alter.Table(tableName).AddColumn("Bottom").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("Left").Exists())
//                    Alter.Table(tableName).AddColumn("Left").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("TextBlockPosition").Exists())
//                    Alter.Table(tableName).AddColumn("TextBlockPosition").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("ContentSpacing").Exists())
//                    Alter.Table(tableName).AddColumn("ContentSpacing").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("ZoneType").Exists())
//                    Alter.Table(tableName).AddColumn("ZoneType").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("LeftImageId").Exists())
//                    Alter.Table(tableName).AddColumn("LeftImageId").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("LeftImageLink").Exists())
//                    Alter.Table(tableName).AddColumn("LeftImageLink").AsString(1000).Nullable();

//                if (!Schema.Table(tableName).Column("LeftColor").Exists())
//                    Alter.Table(tableName).AddColumn("LeftColor").AsString(50).Nullable();

//                if (!Schema.Table(tableName).Column("LeftEmpty").Exists())
//                    Alter.Table(tableName).AddColumn("LeftEmpty").AsString(1000).Nullable();

//                if (!Schema.Table(tableName).Column("LeftOpenInNewTab").Exists())
//                    Alter.Table(tableName).AddColumn("LeftOpenInNewTab").AsBoolean().NotNullable().WithDefaultValue(false);

//                if (!Schema.Table(tableName).Column("LeftHideOnDesktop").Exists())
//                    Alter.Table(tableName).AddColumn("LeftHideOnDesktop").AsBoolean().NotNullable().WithDefaultValue(false);

//                if (!Schema.Table(tableName).Column("LeftHideOnMobile").Exists())
//                    Alter.Table(tableName).AddColumn("LeftHideOnMobile").AsBoolean().NotNullable().WithDefaultValue(false);

//                if (!Schema.Table(tableName).Column("LeftImageAlt").Exists())
//                    Alter.Table(tableName).AddColumn("LeftImageAlt").AsString(1000).Nullable();

//                if (!Schema.Table(tableName).Column("LeftOverlay").Exists())
//                    Alter.Table(tableName).AddColumn("LeftOverlay").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("LeftColorpreset").Exists())
//                    Alter.Table(tableName).AddColumn("LeftColorpreset").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("LeftZoneType").Exists())
//                    Alter.Table(tableName).AddColumn("LeftZoneType").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("RightImageId").Exists())
//                    Alter.Table(tableName).AddColumn("RightImageId").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("RightImageLink").Exists())
//                    Alter.Table(tableName).AddColumn("RightImageLink").AsString(1000).Nullable();

//                if (!Schema.Table(tableName).Column("RightColor").Exists())
//                    Alter.Table(tableName).AddColumn("RightColor").AsString(50).Nullable();

//                if (!Schema.Table(tableName).Column("RightEmpty").Exists())
//                    Alter.Table(tableName).AddColumn("RightEmpty").AsString(1000).Nullable();

//                if (!Schema.Table(tableName).Column("RightOpenInNewTab").Exists())
//                    Alter.Table(tableName).AddColumn("RightOpenInNewTab").AsBoolean().NotNullable().WithDefaultValue(false);

//                if (!Schema.Table(tableName).Column("RightHideOnDesktop").Exists())
//                    Alter.Table(tableName).AddColumn("RightHideOnDesktop").AsBoolean().NotNullable().WithDefaultValue(false);

//                if (!Schema.Table(tableName).Column("RightHideOnMobile").Exists())
//                    Alter.Table(tableName).AddColumn("RightHideOnMobile").AsBoolean().NotNullable().WithDefaultValue(false);

//                if (!Schema.Table(tableName).Column("RightImageAlt").Exists())
//                    Alter.Table(tableName).AddColumn("RightImageAlt").AsString(1000).Nullable();

//                if (!Schema.Table(tableName).Column("RightOverlay").Exists())
//                    Alter.Table(tableName).AddColumn("RightOverlay").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("RightColorpreset").Exists())
//                    Alter.Table(tableName).AddColumn("RightColorpreset").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("RightZoneType").Exists())
//                    Alter.Table(tableName).AddColumn("RightZoneType").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("BackgroundType").Exists())
//                    Alter.Table(tableName).AddColumn("BackgroundType").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("BackgroundColor").Exists())
//                    Alter.Table(tableName).AddColumn("BackgroundColor").AsString(1000).Nullable();

//                if (!Schema.Table(tableName).Column("BackgroundImageId").Exists())
//                    Alter.Table(tableName).AddColumn("BackgroundImageId").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("BackgroundSize").Exists())
//                    Alter.Table(tableName).AddColumn("BackgroundSize").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("BackgroundOverlay").Exists())
//                    Alter.Table(tableName).AddColumn("BackgroundOverlay").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("TextAlignment").Exists())
//                    Alter.Table(tableName).AddColumn("TextAlignment").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("BlockStyle").Exists())
//                    Alter.Table(tableName).AddColumn("BlockStyle").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("TextTheme").Exists())
//                    Alter.Table(tableName).AddColumn("TextTheme").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("Cardtheme").Exists())
//                    Alter.Table(tableName).AddColumn("Cardtheme").AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column("Cardbackgroundcolor").Exists())
//                    Alter.Table(tableName).AddColumn("Cardbackgroundcolor").AsString(50).Nullable();

//                if (!Schema.Table(tableName).Column(nameof(MegaSlider.BackgroundVideoUrl)).Exists())
//                    Alter.Table(tableName).AddColumn(nameof(MegaSlider.BackgroundVideoUrl)).AsString(1000).Nullable();

//                if (!Schema.Table(tableName).Column(nameof(MegaSlider.BackgroundVideoTypeId)).Exists())
//                    Alter.Table(tableName).AddColumn(nameof(MegaSlider.BackgroundVideoTypeId)).AsInt32().Nullable();

//                if (!Schema.Table(tableName).Column(nameof(MegaSlider.IsAutoPlay)).Exists())
//                Alter.Table(tableName) .AddColumn(nameof(MegaSlider.IsAutoPlay)) .AsBoolean() .WithDefaultValue(false);

//                if (!Schema.Table(tableName).Column(nameof(MegaSlider.UseNaturalVideoSizeOnMobile)).Exists())
//                    Alter.Table(tableName).AddColumn(nameof(MegaSlider.UseNaturalVideoSizeOnMobile)).AsBoolean().WithDefaultValue(false);
//            }

//            if (Schema.Table(tableName).Column("OpenInNewTab").Exists())
//            {
//                Delete.Column("OpenInNewTab").FromTable(tableName);
//            }

//            var groupMegaSlider = NameCompatibilityManager.GetTableName(typeof(GroupMegaSlider));

//            if (Schema.Table(groupMegaSlider).Exists())
//            {
//                if (!Schema.Table(groupMegaSlider).Column(nameof(GroupMegaSlider.AnimationEffectId)).Exists())
//                    Alter.Table(groupMegaSlider).AddColumn(nameof(GroupMegaSlider.AnimationEffectId)).AsInt32().Nullable();
//            }
//            if (Schema.Table(groupMegaSlider).Exists())
//            {
//                if (!Schema.Table(groupMegaSlider).Column(nameof(GroupMegaSlider.TransitionAnimationEffectId)).Exists())
//                    Alter.Table(groupMegaSlider).AddColumn(nameof(GroupMegaSlider.TransitionAnimationEffectId)).AsInt32().Nullable();
//            }

//                //Delete.Column("Content").FromTable(tableName);
//                //Delete.Column("ContentLayer").FromTable(tableName);
//                //Delete.Column("ContentLayer3").FromTable(tableName);
//                //Delete.Column("ContentLayerPositions").FromTable(tableName);
//                //Delete.Column("ContentLayerPositionsSecond").FromTable(tableName);
//                //Delete.Column("ContentLayerPositionsThird").FromTable(tableName);
//                //Delete.Column("TitleFontSize").FromTable(tableName);
//                //Delete.Column("DescriptionFontSize").FromTable(tableName);
//                //Delete.Column("Texttransitions").FromTable(tableName);
//                //Delete.Column("TransitionEffectDelay").FromTable(tableName);
//                //Delete.Column("AllowRepeatAnimation").FromTable(tableName);


//                var (languageId, languages) = this.GetLanguageData();

//            ////add, update and delete localization resources
//            _localizationService.AddOrUpdateLocaleResource(new Dictionary<string, string>
//            {

//                //    ["Plugin.nop4all.megaslider.Fields.BadgeText"] = "Badge Text",
//                //    ["Plugin.nop4all.megaslider.Fields.BadgeText.Hint"] = "Enter the text to display as a badge on the slide (e.g., New, Sale).",

//                //    ["Plugin.nop4all.megaslider.Fields.BadgeImageId"] = "Badge Image",
//                //    ["Plugin.nop4all.megaslider.Fields.BadgeImageId.Hint"] = "Upload or select an image to use as a badge for the slide.",

//                //    ["Plugin.nop4all.megaslider.Fields.PriceText"] = "Price Text",
//                //    ["Plugin.nop4all.megaslider.Fields.PriceText.Hint"] = "Enter the price or promotional text to display on the slide.",

//                //    ["Plugin.nop4all.megaslider.Fields.SlideAltDescription"] = "Slide Alt Description",
//                //    ["Plugin.nop4all.megaslider.Fields.SlideAltDescription.Hint"] = "Provide alternative text for the slide image for SEO and accessibility.",

//                //    ["Plugin.nop4all.megaslider.Fields.Cta1OpenInNewTab"] = "CTA 1 Open in New Tab",
//                //    ["Plugin.nop4all.megaslider.Fields.Cta1OpenInNewTab.Hint"] = "Check this option to open the first call-to-action link in a new browser tab.",

//                //    ["Plugin.nop4all.megaslider.Fields.Cta2OpenInNewTab"] = "CTA 2 Open in New Tab",
//                //    ["Plugin.nop4all.megaslider.Fields.Cta2OpenInNewTab.Hint"] = "Check this option to open the second call-to-action link in a new browser tab.",

//                //    ["plugin.nop4all.megaslider.Title"] = "HeroTitle",
//                //    ["plugin.nop4all.megaslider.Title.Hint"] = "Enter the hero title text for the slider.",
//                //    ["plugin.nop4all.megaslider.Shortdescription"] = "HeroDescription",
//                //    ["plugin.nop4all.megaslider.Shortdescription.Hint"] = "Enter a hero description to display on the slider.",
//                //    ["Plugin.nop4all.megaslider.Fields.OpenInNewTab"] = "Open in New Tab",
//                //    ["Plugin.nop4all.megaslider.Fields.OpenInNewTab.Hint"] = "Enable this option to open the link in a new browser tab instead of the current tab.",

//                //    ["Plugin.nop4all.megaslider.Fields.TextBlockOffset"] = "Text Block Off set",
//                //    ["Plugin.nop4all.megaslider.Fields.TextBlockOffset.Hint"] = "Enable this option to manually adjust the position of the text block using top, right, bottom, and left values.",

//                //    ["Plugin.nop4all.megaslider.Fields.Top"] = "Top Offset",
//                //    ["Plugin.nop4all.megaslider.Fields.Top.Hint"] = "Set the distance from the top of the slide (in pixels).",

//                //    ["Plugin.nop4all.megaslider.Fields.Right"] = "Right Offset",
//                //    ["Plugin.nop4all.megaslider.Fields.Right.Hint"] = "Set the distance from the right side of the slide (in pixels).",

//                //    ["Plugin.nop4all.megaslider.Fields.Bottom"] = "Bottom Offset",
//                //    ["Plugin.nop4all.megaslider.Fields.Bottom.Hint"] = "Set the distance from the bottom of the slide (in pixels).",

//                //    ["Plugin.nop4all.megaslider.Fields.Left"] = "Left Offset",
//                //    ["Plugin.nop4all.megaslider.Fields.Left.Hint"] = "Set the distance from the left side of the slide (in pixels).",

//                //    ["Plugin.nop4all.megaslider.Fields.TextBlockPosition"] = "Text Block Position",
//                //    ["Plugin.nop4all.megaslider.Fields.TextBlockPosition.Hint"] = "Select the predefined position of the text block (e.g., Top Left, Center, Bottom Right).",

//                //    ["Plugin.nop4all.megaslider.Fields.ContentSpacing"] = "Content Spacing",
//                //    ["Plugin.nop4all.megaslider.Fields.ContentSpacing.Hint"] = "Set the spacing between elements inside the text block (in pixels).",



//                //    ["Plugin.nop4all.megaslider.Fields.ZoneType"] = "Zone Type",
//                //    ["Plugin.nop4all.megaslider.Fields.ZoneType.Hint"] = "Select the type of content for this zone (e.g., Text, Image, Button, HTML).",

//                //    // LEFT
//                //    ["Plugin.nop4all.megaslider.Fields.LeftImageId"] = "Left Image",
//                //    ["Plugin.nop4all.megaslider.Fields.LeftImageId.Hint"] = "Upload or select an image to display in the left zone.",

//                //    ["Plugin.nop4all.megaslider.Fields.LeftImageLink"] = "Left Image Link",
//                //    ["Plugin.nop4all.megaslider.Fields.LeftImageLink.Hint"] = "Enter the URL to navigate when the left image is clicked.",

//                //    ["Plugin.nop4all.megaslider.Fields.LeftColor"] = "Left Background Color",
//                //    ["Plugin.nop4all.megaslider.Fields.LeftColor.Hint"] = "Select a background color for the left zone.",

//                //    ["Plugin.nop4all.megaslider.Fields.LeftEmpty"] = "Left Empty",
//                //    ["Plugin.nop4all.megaslider.Fields.LeftEmpty.Hint"] = "No content will be displayed in the left zone.",

//                //    ["Plugin.nop4all.megaslider.Fields.LeftOpenInNewTab"] = "Left Open in New Tab",
//                //    ["Plugin.nop4all.megaslider.Fields.LeftOpenInNewTab.Hint"] = "Enable this option to open the left zone link in a new browser tab.",

//                //    ["Plugin.nop4all.megaslider.Fields.LeftHideOnDesktop"] = "Left Hide on Desktop",
//                //    ["Plugin.nop4all.megaslider.Fields.LeftHideOnDesktop.Hint"] = "Enable this option to hide the left zone on desktop devices.",

//                //    ["Plugin.nop4all.megaslider.Fields.LeftHideOnMobile"] = "Left Hide on Mobile",
//                //    ["Plugin.nop4all.megaslider.Fields.LeftHideOnMobile.Hint"] = "Enable this option to hide the left zone on mobile devices.",

//                //    ["Plugin.nop4all.megaslider.Fields.LeftImageAlt"] = "Left Image Alt Text",
//                //    ["Plugin.nop4all.megaslider.Fields.LeftImageAlt.Hint"] = "Enter alternative text for the left image (used for SEO and accessibility).",

//                //    ["Plugin.nop4all.megaslider.Fields.LeftOverlay"] = "Left Overlay",
//                //    ["Plugin.nop4all.megaslider.Fields.LeftOverlay.Hint"] = "Enable or configure an overlay on the left zone (e.g., dark/light overlay over image or color).",

//                //    ["Plugin.nop4all.megaslider.Fields.LeftColorpreset"] = "Left Color Preset",
//                //    ["Plugin.nop4all.megaslider.Fields.LeftColorpreset.Hint"] = "Select a predefined color preset for the left zone background.",

//                //    ["Plugin.nop4all.megaslider.Fields.LeftZoneType"] = "Left Zone Type",
//                //    ["Plugin.nop4all.megaslider.Fields.LeftZoneType.Hint"] = "Select the content type for the left zone (e.g., Image, Color, or Empty).",

//                //    // RIGHT
//                //    ["Plugin.nop4all.megaslider.Fields.RightImageId"] = "Right Image",
//                //    ["Plugin.nop4all.megaslider.Fields.RightImageId.Hint"] = "Upload or select an image to display in the right zone.",

//                //    ["Plugin.nop4all.megaslider.Fields.RightImageLink"] = "Right Image Link",
//                //    ["Plugin.nop4all.megaslider.Fields.RightImageLink.Hint"] = "Enter the URL to navigate when the right image is clicked.",

//                //    ["Plugin.nop4all.megaslider.Fields.RightColor"] = "Right Background Color",
//                //    ["Plugin.nop4all.megaslider.Fields.RightColor.Hint"] = "Select a background color for the right zone.",

//                //    ["Plugin.nop4all.megaslider.Fields.RightEmpty"] = "Right Empty",
//                //    ["Plugin.nop4all.megaslider.Fields.RightEmpty.Hint"] = "No content will be displayed in the right zone.",

//                //    ["Plugin.nop4all.megaslider.Fields.RightOpenInNewTab"] = "Right Open in New Tab",
//                //    ["Plugin.nop4all.megaslider.Fields.RightOpenInNewTab.Hint"] = "Enable this option to open the right zone link in a new browser tab.",

//                //    ["Plugin.nop4all.megaslider.Fields.RightHideOnDesktop"] = "Right Hide on Desktop",
//                //    ["Plugin.nop4all.megaslider.Fields.RightHideOnDesktop.Hint"] = "Enable this option to hide the right zone on desktop devices.",

//                //    ["Plugin.nop4all.megaslider.Fields.RightHideOnMobile"] = "Right Hide on Mobile",
//                //    ["Plugin.nop4all.megaslider.Fields.RightHideOnMobile.Hint"] = "Enable this option to hide the right zone on mobile devices.",

//                //    ["Plugin.nop4all.megaslider.Fields.RightImageAlt"] = "Right Image Alt Text",
//                //    ["Plugin.nop4all.megaslider.Fields.RightImageAlt.Hint"] = "Enter alternative text for the right image (used for SEO and accessibility).",

//                //    ["Plugin.nop4all.megaslider.Fields.RightOverlay"] = "Right Overlay",
//                //    ["Plugin.nop4all.megaslider.Fields.RightOverlay.Hint"] = "Enable or configure an overlay on the right zone (e.g., dark/light overlay over image or color).",

//                //    ["Plugin.nop4all.megaslider.Fields.RightColorpreset"] = "Right Color Preset",
//                //    ["Plugin.nop4all.megaslider.Fields.RightColorpreset.Hint"] = "Select a predefined color preset for the right zone background.",

//                //    ["Plugin.nop4all.megaslider.Fields.RightZoneType"] = "Right Zone Type",
//                //    ["Plugin.nop4all.megaslider.Fields.RightZoneType.Hint"] = "Select the content type for the right zone (e.g., Image, Color, or Empty).",

//                //    //Validators

//                //    //Content
//                //    ["Plugin.nop4all.megamenu4all.Fields.BadgeImageIdErrorMsg"] = "Please select a badge image.",

//                //    ["Plugin.nop4all.megaslider.Fields.LeftHideErrorMsg"] = "Left zone cannot be hidden on both mobile and desktop. It will not be visible on any device.",

//                //    ["Plugin.nop4all.megaslider.Fields.RightHideErrorMsg"] = "Right zone cannot be hidden on both mobile and desktop. It will not be visible on any device.",

//                //    ["Plugin.nop4all.megamenu4all.Fields.ContentErrorMsg"] = "At least one content (Content / Layer 1 / Layer 2) is required.",

//                //    ["Plugin.nop4all.megamenu4all.Fields.CTAButton1TextErrorMsg"] = "CTA Button 1 text is required.",
//                //    ["Plugin.nop4all.megamenu4all.Fields.CTAButton2TextErrorMsg"] = "CTA Button 2 text is required.",

//                //    ["Plugin.nop4all.megamenu4all.Fields.CTAButton1RedirectUrlErrorMsg"] = "CTA Button 1 redirect URL is required.",
//                //    ["Plugin.nop4all.megamenu4all.Fields.CTAButton2RedirectUrlErrorMsg"] = "CTA Button 2 redirect URL is required.",

//                //    //LEFT
//                //    ["Plugin.nop4all.megaslider.Fields.LeftImageIdErrorMsg"] = "Please select a left image.",
//                //    ["Plugin.nop4all.megaslider.Fields.LeftImageLinkErrorMsg"] = "Please enter a valid left image link.",
//                //    ["Plugin.nop4all.megaslider.Fields.LeftColorErrorMsg"] = "Please select a left background color.",
//                //    ["Plugin.nop4all.megaslider.Fields.LeftEmptyErrorMsg"] = "No input is required for the left empty zone.",

//                //    // RIGHT
//                //    ["Plugin.nop4all.megaslider.Fields.RightImageIdErrorMsg"] = "Please select a right image.",
//                //    ["Plugin.nop4all.megaslider.Fields.RightImageLinkErrorMsg"] = "Please enter a valid right image link.",
//                //    ["Plugin.nop4all.megaslider.Fields.RightColorErrorMsg"] = "Please select a right background color.",
//                //    ["Plugin.nop4all.megaslider.Fields.RightEmptyErrorMsg"] = "No input is required for the right empty zone.",

//                //    //Layout & Style
//                //    ["Plugin.nop4all.megaslider.Fields.BackgroundType"] = "Background type",
//                //    ["Plugin.nop4all.megaslider.Fields.BackgroundType.Hint"] = "select back ground type",
//                //    ["Plugin.nop4all.megaslider.Fields.TextAlignment"] = "Alignment",
//                //    ["Plugin.nop4all.megaslider.Fields.TextAlignment.Hint"] = "select alignment",
//                //    ["Plugin.nop4all.megaslider.Fields.BlockStyle"] = "Block style",
//                //    ["Plugin.nop4all.megaslider.Fields.BlockStyle.Hint"] = "select block style",
//                //    ["Plugin.nop4all.megaslider.Fields.TextTheme"] = "Text theme",
//                //    ["Plugin.nop4all.megaslider.Fields.TextTheme.Hint"] = "select text theme",
//                //    ["Plugin.nop4all.megaslider.Fields.BackgroundColor"] = "Background color",
//                //    ["Plugin.nop4all.megaslider.Fields.BackgroundColor.Hint"] = "selct back ground color",
//                //    ["Plugin.nop4all.megaslider.Fields.BackgroundImageId"] = "Background image",
//                //    ["Plugin.nop4all.megaslider.Fields.BackgroundImageId.Hint"] = "select back ground image",
//                //    ["Plugin.nop4all.megaslider.Fields.BackgroundSize"] = "Background size",
//                //    ["Plugin.nop4all.megaslider.Fields.BackgroundSize.Hint"] = "select back ground size",
//                //    ["Plugin.nop4all.megaslider.Fields.BackgroundOverlay"] = "Background overlay",
//                //    ["Plugin.nop4all.megaslider.Fields.BackgroundOverlay.Hint"] = "select back ground overlay",
//                //    ["Plugin.nop4all.megaslider.Fields.Cardtheme"] = "Card Theme",
//                //    ["Plugin.nop4all.megaslider.Fields.Cardtheme.Hint"] = "Select a predefined theme for the card (e.g., White, Dark).",
//                //    ["Plugin.nop4all.megaslider.Fields.Cardbackgroundcolor"] = "Card Background Color",
//                //    ["Plugin.nop4all.megaslider.Fields.Cardbackgroundcolor.Hint"] = "Select a background color for the card.",

//                ["Plugin.nop4all.megaslider.Fields.BackgroundVideoUrl"] = "Background Video URL",
//                ["Plugin.nop4all.megaslider.Fields.BackgroundVideoUrl.Hint"] = "Enter the URL of the background video to display in the slider (e.g., MP4 or YouTube link).",

//                ["Plugin.nop4all.megaslider.Fields.BackgroundVideoTypeId"] = "Background Video Type",
//                ["Plugin.nop4all.megaslider.Fields.BackgroundVideoTypeId.Hint"] = "Select the type of background video (e.g., uploaded video file or YouTube link).",
//                ["Plugins.Widgets.MegaSlider.Fields.IsAutoPlay"] = "IsAutoPlay",
//                ["Plugins.Widgets.MegaSlider.Fields.IsAutoPlay.Hint"] = "Enabled the check box youtube and uploaded video is auto play.",
//                ["Plugins.Widgets.MegaSlider.Fields.UseNaturalVideoSizeOnMobile"] = "Use natural video size on mobile",
//                ["Plugins.Widgets.MegaSlider.Fields.UseNaturalVideoSizeOnMobile.Hint"] = "Enabled the check box youtube and uploaded video is natural video size on mobile.",
//                ["Plugin.nop4all.megaslider.AnimationEffect"] = "Slider Effect",
//                ["Plugin.nop4all.megaslider.AnimationEffect.Hint"] = "Select slider effect",
//                ["Plugin.nop4all.megaslider.TransitionAnimationEffect"] = "TransitionAnimationEffect",
//                ["Plugin.nop4all.megaslider.TransitionAnimationEffect.Hint"] = "Select transition animation effect",


//            }, languageId);

//        }

//        /// <summary>
//        /// Collect the Down migration expressions
//        /// </summary>
//        public override void Down()
//        {
//        }
//    }
//}
