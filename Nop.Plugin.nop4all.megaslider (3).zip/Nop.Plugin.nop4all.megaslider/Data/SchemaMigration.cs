﻿using FluentMigrator;
using Nop.Data.Extensions;
using Nop.Data.Mapping;
using Nop.Data.Migrations;
using Nop.Plugin.nop4all.megaslider.Domain;

namespace Nop.Plugin.nop4all.megaslider.Data
{
    [NopMigration("2026-03-03 02:03:04", "nop4all.megaslider base schema", MigrationProcessType.Installation)]
    public class SchemaMigration : Migration
    {
        /// <summary>
        /// Collect the UP migration expressions
        /// <remarks>
        /// We use an explicit table creation order instead of an automatic one
        /// due to problems creating relationships between tables
        /// </remarks>
        /// </summary>
        public override void Up()
        {
            var megaSliderNewproductsTable = NameCompatibilityManager.GetTableName(typeof(MegaSliderNewProducts));
            if (!Schema.Table(megaSliderNewproductsTable).Exists())
            {
                Create.TableFor<MegaSliderNewProducts>();
            }

            var megasliderTable = NameCompatibilityManager.GetTableName(typeof(MegaSlider));
            if (!Schema.Table(megasliderTable).Exists())
            {
                Create.TableFor<MegaSlider>();
            }
            var groupmegasliderTable = NameCompatibilityManager.GetTableName(typeof(GroupMegaSlider));
            if (!Schema.Table(groupmegasliderTable).Exists())
            {
                Create.TableFor<GroupMegaSlider>();
            }
            var slidermappingTable = NameCompatibilityManager.GetTableName(typeof(SliderMapping));
            if (!Schema.Table(slidermappingTable).Exists())
            {
                Create.TableFor<SliderMapping>();
            }
            var megaSliderFeaturedproductsTable = NameCompatibilityManager.GetTableName(typeof(MegaSliderFeaturedProducts));
            if (!Schema.Table(megaSliderFeaturedproductsTable).Exists())
            {
                Create.TableFor<MegaSliderFeaturedProducts>();
            }
            //new 
            var conditionTable = NameCompatibilityManager.GetTableName(typeof(MegaSliderGroupCondition));
            if (!Schema.Table(conditionTable).Exists())
            {
                Create.TableFor<MegaSliderGroupCondition>();
            }

            //if (Schema.Table(megasliderTable).Column("CTAButton1FontSize").Exists() == false)
            //{
            //    Alter.Table(megasliderTable)
            //        .AddColumn("CTAButton1FontSize").AsInt32().NotNullable().WithDefaultValue(0);
            //}

            //if (Schema.Table(megasliderTable).Column("CTAButton2FontSize").Exists() == false)
            //{
            //    Alter.Table(megasliderTable)
            //        .AddColumn("CTAButton2FontSize").AsInt32().NotNullable().WithDefaultValue(0);
            //}

            //if (!Schema.Table(megasliderTable).Column("TextBlockOffset").Exists())
            //    Alter.Table(megasliderTable).AddColumn("TextBlockOffset").AsBoolean().Nullable().WithDefaultValue(false);

            //if (!Schema.Table(megasliderTable).Column("Top").Exists())
            //    Alter.Table(megasliderTable).AddColumn("Top").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("Right").Exists())
            //    Alter.Table(megasliderTable).AddColumn("Right").AsInt32().Nullable();


            //if (!Schema.Table(megasliderTable).Column("Bottom").Exists())
            //    Alter.Table(megasliderTable).AddColumn("Bottom").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("Left").Exists())
            //    Alter.Table(megasliderTable).AddColumn("Left").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("TextBlockPosition").Exists())
            //    Alter.Table(megasliderTable).AddColumn("TextBlockPosition").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("ContentSpacing").Exists())
            //    Alter.Table(megasliderTable).AddColumn("ContentSpacing").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("ZoneType").Exists())
            //    Alter.Table(megasliderTable).AddColumn("ZoneType").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("LeftImageId").Exists())
            //    Alter.Table(megasliderTable).AddColumn("LeftImageId").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("LeftImageLink").Exists())
            //    Alter.Table(megasliderTable).AddColumn("LeftImageLink").AsString(1000).Nullable();

            //if (!Schema.Table(megasliderTable).Column("LeftColor").Exists())
            //    Alter.Table(megasliderTable).AddColumn("LeftColor").AsString(50).Nullable();

            //if (!Schema.Table(megasliderTable).Column("LeftEmpty").Exists())
            //    Alter.Table(megasliderTable).AddColumn("LeftEmpty").AsString(1000).Nullable();

            //if (!Schema.Table(megasliderTable).Column("LeftOpenInNewTab").Exists())
            //    Alter.Table(megasliderTable).AddColumn("LeftOpenInNewTab").AsBoolean().NotNullable().WithDefaultValue(false);

            //if (!Schema.Table(megasliderTable).Column("LeftHideOnDesktop").Exists())
            //    Alter.Table(megasliderTable).AddColumn("LeftHideOnDesktop").AsBoolean().NotNullable().WithDefaultValue(false);

            //if (!Schema.Table(megasliderTable).Column("LeftHideOnMobile").Exists())
            //    Alter.Table(megasliderTable).AddColumn("LeftHideOnMobile").AsBoolean().NotNullable().WithDefaultValue(false);

            //if (!Schema.Table(megasliderTable).Column("LeftImageAlt").Exists())
            //    Alter.Table(megasliderTable).AddColumn("LeftImageAlt").AsString(1000).Nullable();

            //if (!Schema.Table(megasliderTable).Column("LeftOverlay").Exists())
            //    Alter.Table(megasliderTable).AddColumn("LeftOverlay").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("LeftColorpreset").Exists())
            //    Alter.Table(megasliderTable).AddColumn("LeftColorpreset").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("LeftZoneType").Exists())
            //    Alter.Table(megasliderTable).AddColumn("LeftZoneType").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("RightImageId").Exists())
            //    Alter.Table(megasliderTable).AddColumn("RightImageId").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("RightImageLink").Exists())
            //    Alter.Table(megasliderTable).AddColumn("RightImageLink").AsString(1000).Nullable();

            //if (!Schema.Table(megasliderTable).Column("RightColor").Exists())
            //    Alter.Table(megasliderTable).AddColumn("RightColor").AsString(50).Nullable();

            //if (!Schema.Table(megasliderTable).Column("RightEmpty").Exists())
            //    Alter.Table(megasliderTable).AddColumn("RightEmpty").AsString(1000).Nullable();

            //if (!Schema.Table(megasliderTable).Column("RightOpenInNewTab").Exists())
            //    Alter.Table(megasliderTable).AddColumn("RightOpenInNewTab").AsBoolean().NotNullable().WithDefaultValue(false);

            //if (!Schema.Table(megasliderTable).Column("RightHideOnDesktop").Exists())
            //    Alter.Table(megasliderTable).AddColumn("RightHideOnDesktop").AsBoolean().NotNullable().WithDefaultValue(false);

            //if (!Schema.Table(megasliderTable).Column("RightHideOnMobile").Exists())
            //    Alter.Table(megasliderTable).AddColumn("RightHideOnMobile").AsBoolean().NotNullable().WithDefaultValue(false);

            //if (!Schema.Table(megasliderTable).Column("RightImageAlt").Exists())
            //    Alter.Table(megasliderTable).AddColumn("RightImageAlt").AsString(1000).Nullable();

            //if (!Schema.Table(megasliderTable).Column("RightOverlay").Exists())
            //    Alter.Table(megasliderTable).AddColumn("RightOverlay").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("RightColorpreset").Exists())
            //    Alter.Table(megasliderTable).AddColumn("RightColorpreset").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("RightZoneType").Exists())
            //    Alter.Table(megasliderTable).AddColumn("RightZoneType").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("BackgroundType").Exists())
            //    Alter.Table(megasliderTable).AddColumn("BackgroundType").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("BackgroundColor").Exists())
            //    Alter.Table(megasliderTable).AddColumn("BackgroundColor").AsString(1000).Nullable();

            //if (!Schema.Table(megasliderTable).Column("BackgroundImageId").Exists())
            //    Alter.Table(megasliderTable).AddColumn("BackgroundImageId").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("BackgroundSize").Exists())
            //    Alter.Table(megasliderTable).AddColumn("BackgroundSize").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("BackgroundOverlay").Exists())
            //    Alter.Table(megasliderTable).AddColumn("BackgroundOverlay").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("TextAlignment").Exists())
            //    Alter.Table(megasliderTable).AddColumn("TextAlignment").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("BlockStyle").Exists())
            //    Alter.Table(megasliderTable).AddColumn("BlockStyle").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("TextTheme").Exists())
            //    Alter.Table(megasliderTable).AddColumn("TextTheme").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("Cardtheme").Exists())
            //    Alter.Table(megasliderTable).AddColumn("Cardtheme").AsInt32().Nullable();

            //if (!Schema.Table(megasliderTable).Column("Cardbackgroundcolor").Exists())
            //    Alter.Table(megasliderTable).AddColumn("Cardbackgroundcolor").AsString(50).Nullable();

            //if (!Schema.Table(megasliderTable).Column("BackgroundVideoUrl").Exists())
            //    Alter.Table(megasliderTable).AddColumn("BackgroundVideoUrl").AsString(1000).Nullable();

            //if (!Schema.Table(megasliderTable).Column("BackgroundVideoTypeId ").Exists())
            //    Alter.Table(megasliderTable).AddColumn("BackgroundVideoTypeId ").AsInt32().Nullable();

            //if (Schema.Table(megasliderTable).Column("OpenInNewTab").Exists())
            //{
            //    Delete.Column("OpenInNewTab").FromTable(megasliderTable);
            //}
        }

        /// <summary>
        /// Collect the Down migration expressions
        /// </summary>
        public override void Down()
        {

            var megasliderTable = NameCompatibilityManager.GetTableName(typeof(MegaSlider));
            if (Schema.Table(megasliderTable).Exists())
            {
                Delete.Table(megasliderTable);
            }

            var slidermappingTable = NameCompatibilityManager.GetTableName(typeof(SliderMapping));
            if (Schema.Table(slidermappingTable).Exists())
            {
                Delete.Table(slidermappingTable);
            }

            var megaSliderFeaturedproductsTable = NameCompatibilityManager.GetTableName(typeof(MegaSliderFeaturedProducts));
            if (Schema.Table(megaSliderFeaturedproductsTable).Exists())
            {
                Delete.Table(megaSliderFeaturedproductsTable);
            }
            var megaSliderNewproductsTable = NameCompatibilityManager.GetTableName(typeof(MegaSliderNewProducts));
            if (Schema.Table(megaSliderNewproductsTable).Exists())
            {
                Delete.Table(megaSliderNewproductsTable);
            }

            var conditionTable = NameCompatibilityManager.GetTableName(typeof(MegaSliderGroupCondition));
            if (Schema.Table(conditionTable).Exists())
            {
                Delete.Table(conditionTable);
            }

            var groupmegasliderTable = NameCompatibilityManager.GetTableName(typeof(GroupMegaSlider));
            if (Schema.Table(groupmegasliderTable).Exists())
            {
                Delete.Table(groupmegasliderTable);
            }
        }
    }
}